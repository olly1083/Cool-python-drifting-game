"""
server.py  –  Drift Master Multiplayer Server
Run:  python server.py [--port 7777] [--levels ./levels] [--config server_config.json]

On first run a default server_config.json is created automatically.

════════════════════════════════════════════════════════
 OPERATOR CONSOLE  (type commands while server is running)
════════════════════════════════════════════════════════
  list                     – list all connected players
  kick  <pid|name>         – kick a player
  ban   <pid|name>         – ban a player's IP
  unban <ip>               – remove an IP ban
  bans                     – show all banned IPs
  mute  <pid|name>         – silence a player's chat
  unmute <pid|name>        – restore chat
  msg   <text>             – broadcast server announcement
  skip                     – force-end the current game / skip voting
  reload                   – reload levels from disk
  config                   – print current config
  set   <key> <value>      – change a config value live
  status                   – show server state
  help                     – show this list
  quit / exit              – shut down the server
════════════════════════════════════════════════════════
"""
import argparse, json, math, os, random, socket
import sys, threading, time, traceback
sys.path.insert(0, os.path.dirname(__file__))

from network import (
    DEFAULT_PORT, MAX_PLAYERS, TICK_RATE,
    VOTE_DURATION, COUNTDOWN_SECS, BUMPER_DURATION, RACE_TIMEOUT,
    MODE_RACE, MODE_BUMPER, MODES, MODE_LABELS, MODE_DESCS,
    S_WELCOME, S_LEVEL_DATA, S_PLAYER_JOIN, S_PLAYER_LEAVE,
    S_LOBBY, S_VOTE_START, S_VOTE_UPDATE, S_COUNTDOWN,
    S_GAME_START, S_STATE, S_LAP, S_FINISH, S_GAME_OVER,
    S_CHAT, S_PING,
    C_JOIN, C_READY, C_VOTE, C_INPUT, C_CHAT, C_PONG,
    MsgBuffer,
)

import pygame
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
pygame.init()

from carcontroller import CarController
import pygame.locals as _pl

LEVELS_DIR   = "levels"
CONFIG_FILE  = "server_config.json"

# ── State machine ─────────────────────────────────────────────────────────────
ST_LOBBY     = "lobby"
ST_VOTING    = "voting"
ST_COUNTDOWN = "countdown"
ST_RACING    = "racing"
ST_RESULTS   = "results"

# ── Default config ────────────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    # ── Server basics ──────────────────────────────────────────────────────────
    "server_name":          "Drift Master Server",
    "motd":                 "Welcome! Have fun drifting.",   # shown on join
    "max_players":          16,
    "port":                 DEFAULT_PORT,
    "levels_dir":           LEVELS_DIR,

    # ── Lobby / game flow ─────────────────────────────────────────────────────
    "min_players_to_start": 1,    # how many must be ready before voting starts
    "vote_duration":        20.0, # seconds
    "countdown_secs":       5.0,
    "results_display_secs": 15.0, # lobby reset delay after game over
    "allow_join_mid_vote":  True,  # let players join during voting
    "allow_join_mid_game":  False, # let players join while a race is running

    # ── Race rules ────────────────────────────────────────────────────────────
    "race_timeout":         300.0, # seconds before race force-ends
    "bumper_duration":      120.0, # bumper cars time limit
    "triggers_enabled":     True,  # enable/disable level trigger zones

    # ── Chat ──────────────────────────────────────────────────────────────────
    "chat_enabled":         True,
    "chat_max_length":      200,
    "chat_rate_limit":      1.5,   # minimum seconds between messages per player

    # ── Anti-cheat / safety ───────────────────────────────────────────────────
    "name_max_length":      20,
    "kick_on_input_flood":  True,  # kick if >60 inputs/sec
    "input_flood_threshold":60,

    # ── Operator ──────────────────────────────────────────────────────────────
    "operator_password":    "",    # if non-empty, /op <password> grants operator
    "log_file":             "",    # path to write logs, empty = stdout only
    "banned_ips":           [],    # persisted ban list
}

CONFIG_HELP = {
    "server_name":          "Display name shown to players",
    "motd":                 "Message of the day sent on join",
    "max_players":          "Maximum simultaneous players (1-16)",
    "min_players_to_start": "Ready players needed before voting begins",
    "vote_duration":        "Seconds players have to vote (float)",
    "countdown_secs":       "Pre-race countdown seconds (float)",
    "results_display_secs": "Seconds to show results before lobby reset",
    "allow_join_mid_vote":  "Allow new players during voting (true/false)",
    "allow_join_mid_game":  "Allow new players during a race (true/false)",
    "race_timeout":         "Force-end race after this many seconds",
    "bumper_duration":      "Bumper cars time limit in seconds",
    "triggers_enabled":     "Enable/disable level trigger zones (true/false)",
    "chat_enabled":         "Enable/disable all player chat (true/false)",
    "chat_max_length":      "Max characters per chat message",
    "chat_rate_limit":      "Min seconds between player messages",
    "name_max_length":      "Max player name length",
    "kick_on_input_flood":  "Kick players spamming inputs (true/false)",
    "input_flood_threshold":"Inputs/sec that triggers flood detection",
    "operator_password":    "Password for /op command (empty = disabled)",
    "log_file":             "Log file path (empty = stdout only)",
    "banned_ips":           "(read-only via console — use ban/unban commands)",
}


# ── Config loader / saver ─────────────────────────────────────────────────────

def load_config(path):
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(path):
        try:
            with open(path) as f:
                user = json.load(f)
            for k, v in user.items():
                if k in cfg:
                    cfg[k] = v
            _log(f"[CFG]  Loaded config from {path}")
        except Exception as e:
            _log(f"[WARN] Could not load config {path}: {e}  — using defaults")
    else:
        _log(f"[CFG]  {path} not found — creating with defaults")
        save_config(cfg, path)
    return cfg

def save_config(cfg, path):
    try:
        with open(path, "w") as f:
            json.dump(cfg, f, indent=2)
    except Exception as e:
        _log(f"[WARN] Could not save config: {e}")

# ── Logging ───────────────────────────────────────────────────────────────────

_log_lock = threading.Lock()
_log_file_handle = None

def _log(msg):
    ts = time.strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    with _log_lock:
        print(line, flush=True)
        if _log_file_handle:
            try:
                _log_file_handle.write(line + "\n")
                _log_file_handle.flush()
            except Exception:
                pass

def _set_log_file(path):
    global _log_file_handle
    if _log_file_handle:
        _log_file_handle.close()
        _log_file_handle = None
    if path:
        try:
            _log_file_handle = open(path, "a", encoding="utf-8")
            _log(f"[CFG]  Logging to {path}")
        except Exception as e:
            _log(f"[WARN] Cannot open log file {path}: {e}")


# ── Helpers ───────────────────────────────────────────────────────────────────

def load_levels(directory):
    levels = {}
    if not os.path.isdir(directory):
        _log(f"[WARN] Levels directory '{directory}' not found.")
        return levels
    for fn in sorted(os.listdir(directory)):
        if fn.endswith(".lev"):
            path = os.path.join(directory, fn)
            try:
                with open(path) as f:
                    data = json.load(f)
                levels[fn] = data
                _log(f"[LEV]  Loaded: {fn}  ({data.get('name', fn)})")
            except Exception as e:
                _log(f"[WARN] Could not load {fn}: {e}")
    return levels


class _FakeKeys:
    def __init__(self, inp):
        self._d = {
            _pl.K_UP:    inp.get("gas",   False),
            _pl.K_w:     inp.get("gas",   False),
            _pl.K_DOWN:  inp.get("brake", False),
            _pl.K_s:     inp.get("brake", False),
            _pl.K_LEFT:  inp.get("left",  False),
            _pl.K_a:     inp.get("left",  False),
            _pl.K_RIGHT: inp.get("right", False),
            _pl.K_d:     inp.get("right", False),
            _pl.K_SPACE: inp.get("hb",    False),
        }
    def __getitem__(self, k):
        return self._d.get(k, False)

def dict_to_keys(inp):
    return _FakeKeys(inp)

def _spawn_grid(sx, sy, angle, n):
    rad = math.radians(angle)
    fwd = (math.sin(rad), -math.cos(rad))
    rgt = (math.cos(rad),  math.sin(rad))
    positions = []
    cols = 2; spacing_side = 45; spacing_back = 60
    for i in range(n):
        row = i // cols; col = i % cols
        side_off = (col - (cols-1)/2.0) * spacing_side
        back_off = (row + 1) * spacing_back
        positions.append((
            sx - fwd[0]*back_off + rgt[0]*side_off,
            sy - fwd[1]*back_off + rgt[1]*side_off,
        ))
    return positions


# ── ServerTriggerZone ─────────────────────────────────────────────────────────
# Standalone copy — does NOT import from main.py, safe for headless server use.

TRIGGER_DEFAULTS_SRV = {"speed": 1.5, "accel": 1.5, "steer": 1.5, "drift": 0.3}

class ServerTriggerZone:
    """
    Physics-only trigger zone for server-side simulation.
    Toggle on first car entry, toggle off on second entry.
    apply_to_car() must be called BEFORE CarController.update() each frame.
    """

    def __init__(self, d):
        self.rect   = pygame.Rect(int(d["x"]), int(d["y"]),
                                   int(d["w"]), int(d["h"]))
        self.kind   = d.get("kind", "speed")
        raw         = float(d.get("value", TRIGGER_DEFAULTS_SRV.get(self.kind, 1.0)))
        self.value  = self._clamp(self.kind, raw)
        self.active = False
        self._was_touching = False   # per-zone, not per-player on server

    @staticmethod
    def _clamp(kind, v):
        """Match the same sanitise logic used in main.py TriggerZone."""
        if kind == "speed":
            return 1.0 if v > 10.0 else max(0.1, min(10.0, v))
        elif kind in ("accel", "steer"):
            return max(0.1, min(10.0, v))
        elif kind == "drift":
            return max(0.05, min(10.0, v))
        return v

    def update(self, car):
        touching = self.rect.collidepoint(car.x, car.y)
        if not touching:
            for cx, cy in car.get_corners():
                if self.rect.collidepoint(cx, cy):
                    touching = True; break
        if touching and not self._was_touching:
            self.active = not self.active
        self._was_touching = touching

    def apply_to_car(self, car):
        if not self.active:
            return
        if self.kind == "speed":
            car.trig_speed_mult *= self.value
            car._trig_active = f"SPEED ×{self.value:.1f}"
        elif self.kind == "accel":
            car.trig_accel_mult *= self.value
            car._trig_active = f"ACCEL ×{self.value:.1f}"
        elif self.kind == "steer":
            car.trig_steer_mult *= self.value
            car._trig_active = f"TURN ×{self.value:.1f}"
        elif self.kind == "drift":
            car.trig_grip_mult *= self.value
            car._trig_active = f"DRIFT ×{self.value:.1f}"


# ── Player ────────────────────────────────────────────────────────────────────

class Player:
    _next_pid = 1

    def __init__(self, conn, addr):
        self.pid   = Player._next_pid;  Player._next_pid += 1
        self.conn  = conn
        self.addr  = addr
        self.ip    = addr[0]
        self.buf   = MsgBuffer(conn)
        self.name  = f"Player{self.pid}"
        self.color = random.choice([
            [220,55,55],[55,120,220],[55,195,75],[215,178,38],
            [175,55,215],[235,135,28],[240,240,240],[28,195,195],
            [255,80,160],[80,220,255],[120,255,120],[255,160,80],
        ])
        self.ready      = False
        self.muted      = False
        self.is_op      = False   # operator status
        self.vote_level = None
        self.vote_mode  = None

        # Anti-flood
        self.input_times  = []   # timestamps of recent inputs
        self.chat_last_t  = 0.0

        # Per-player trigger state (keyed by trigger index "tz_N")
        self.trig_touch   = {}   # tz_N → bool: was car touching last frame
        self.trig_active  = {}   # tz_N → bool: is trigger toggled on for this player

        # In-game
        self.car          = None
        self.inputs       = {"gas":False,"brake":False,"left":False,"right":False,"hb":False}
        self.last_seq     = -1
        self.lap          = 0
        self.next_cp      = 0
        self.lap_times    = []
        self.best_lap     = None
        self.lap_start    = 0.0
        self.finished     = False
        self.finish_time  = None
        self.hits         = 0
        self.hit_cd       = {}
        self.drift_score  = 0

    def send(self, msg):  return self.buf.send(msg)
    def recv(self):       return self.buf.recv_all()


# ── Server ────────────────────────────────────────────────────────────────────

class Server:

    def __init__(self, cfg, config_path):
        self.cfg         = cfg
        self.config_path = config_path
        self.levels      = load_levels(cfg["levels_dir"])
        self.players     = {}          # pid → Player
        self.lock        = threading.Lock()
        self.state       = ST_LOBBY

        self.vote_end    = 0.0
        self.level_key   = None
        self.level_data  = None
        self.mode        = None
        self.walls       = []
        self.checkpoints = []
        self.trigger_zones = []
        self.max_laps    = 3
        self.game_start_t= 0.0
        self.game_timer  = 0.0
        self._tick_t     = 0.0
        self._running    = True

    # ── Run ───────────────────────────────────────────────────────────────────

    def run(self):
        # Log file
        if self.cfg.get("log_file"):
            _set_log_file(self.cfg["log_file"])

        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("0.0.0.0", self.cfg["port"]))
        sock.listen(MAX_PLAYERS)
        sock.setblocking(False)
        _log(f"[SRV]  \"{self.cfg['server_name']}\" listening on port {self.cfg['port']}")
        _log(f"[SRV]  {len(self.levels)} level(s) loaded")
        _log("[SRV]  Type 'help' for operator commands")

        # Console thread
        threading.Thread(target=self._console_loop, daemon=True).start()

        last = time.time()
        while self._running:
            try:
                conn, addr = sock.accept()
                conn.setblocking(False)
                threading.Thread(target=self._handle_join,
                                  args=(conn, addr), daemon=True).start()
            except BlockingIOError:
                pass
            except Exception as e:
                _log(f"[ERR]  Accept: {e}")

            now = time.time()
            dt  = min(now - last, 0.05)
            last = now
            try:
                self._tick(dt)
            except Exception:
                _log("[ERR]  Tick exception:\n" + traceback.format_exc())

            time.sleep(1.0 / (TICK_RATE * 4))

        _log("[SRV]  Shutdown complete.")

    # ── Join handshake ────────────────────────────────────────────────────────

    def _handle_join(self, conn, addr):
        ip = addr[0]
        buf = MsgBuffer(conn)

        # IP ban check
        if ip in self.cfg.get("banned_ips", []):
            buf.send({"type": "error", "msg": "You are banned from this server."})
            conn.close()
            _log(f"[BAN]  Rejected banned IP {ip}")
            return

        _log(f"[NET]  Connection from {addr}")

        conn.settimeout(10.0)
        raw = b""
        try:
            while b"\n" not in raw:
                chunk = conn.recv(4096)
                if not chunk:
                    conn.close(); return
                raw += chunk
        except Exception:
            conn.close(); return
        conn.settimeout(None)
        conn.setblocking(False)

        try:
            msg = json.loads(raw.split(b"\n")[0])
        except Exception:
            conn.close(); return

        if msg.get("type") != C_JOIN:
            conn.close(); return

        with self.lock:
            max_p = int(self.cfg.get("max_players", MAX_PLAYERS))
            allow_mid_vote = self.cfg.get("allow_join_mid_vote", True)
            allow_mid_game = self.cfg.get("allow_join_mid_game", False)

            if len(self.players) >= max_p:
                buf.send({"type": "error", "msg": "Server is full."})
                conn.close(); return
            if self.state == ST_RACING and not allow_mid_game:
                buf.send({"type": "error", "msg": "Game in progress."})
                conn.close(); return
            if self.state == ST_VOTING and not allow_mid_vote:
                buf.send({"type": "error", "msg": "Game in progress."})
                conn.close(); return
            if self.state in (ST_COUNTDOWN, ST_RESULTS) and not allow_mid_game:
                buf.send({"type": "error", "msg": "Game in progress."})
                conn.close(); return

            p = Player(conn, addr)
            raw_name = str(msg.get("name", p.name))
            max_nl   = int(self.cfg.get("name_max_length", 20))
            p.name   = raw_name[:max_nl].strip() or p.name
            if msg.get("color"):
                p.color = list(msg["color"])[:3]
            self.players[p.pid] = p

        # Welcome packet
        level_list = [{"key": k, "name": v.get("name", k),
                        "laps": v.get("lap_count", 3)}
                       for k, v in self.levels.items()]
        p.send({"type": S_WELCOME, "pid": p.pid,
                 "server_name": self.cfg["server_name"],
                 "level_list":  level_list})

        # MOTD
        motd = self.cfg.get("motd", "").strip()
        if motd:
            p.send({"type": S_CHAT, "pid": 0, "name": "[Server]", "text": motd})

        # Send all level data
        for key, data in self.levels.items():
            p.send({"type": S_LEVEL_DATA, "key": key, "data": data})

        self._broadcast({"type": S_PLAYER_JOIN,
                          "pid": p.pid, "name": p.name, "color": p.color},
                          exclude=p.pid)
        self._send_lobby()

        if self.state == ST_VOTING:
            remaining = max(0.0, self.vote_end - time.time())
            p.send({"type": S_VOTE_START,
                     "levels":   level_list,
                     "modes":    [{"id": m, "label": MODE_LABELS[m],
                                    "desc": MODE_DESCS[m]} for m in MODES],
                     "duration": remaining})
            self._send_vote_update()

        _log(f"[JOIN] {p.name} (pid={p.pid}) joined from {addr}")

    # ── Main tick ─────────────────────────────────────────────────────────────

    def _tick(self, dt):
        with self.lock:
            dead = []
            for pid, p in self.players.items():
                msgs = p.recv()
                if msgs is None:
                    dead.append(pid); continue
                for m in msgs:
                    self._handle_msg(p, m)
            for pid in dead:
                self._disconnect(pid)

            if   self.state == ST_LOBBY:     self._tick_lobby()
            elif self.state == ST_VOTING:    self._tick_voting(dt)
            elif self.state == ST_COUNTDOWN: self._tick_countdown(dt)
            elif self.state == ST_RACING:    self._tick_racing(dt)

            if self.state == ST_RACING:
                self._tick_t += dt
                if self._tick_t >= 1.0 / TICK_RATE:
                    self._tick_t = 0.0
                    self._broadcast_state()

    # ── Message handler ───────────────────────────────────────────────────────

    def _handle_msg(self, p, m):
        t = m.get("type")

        if t == C_READY:
            p.ready = True
            self._send_lobby()

        elif t == C_VOTE:
            if self.state == ST_VOTING:
                lk = m.get("level_key")
                md = m.get("mode")
                if lk in self.levels: p.vote_level = lk
                if md in MODES:       p.vote_mode  = md
                self._send_vote_update()

        elif t == C_INPUT:
            if self.state == ST_RACING and p.car and not p.finished:
                # Anti-flood
                now = time.time()
                if self.cfg.get("kick_on_input_flood", True):
                    threshold = int(self.cfg.get("input_flood_threshold", 60))
                    p.input_times = [x for x in p.input_times if now - x < 1.0]
                    p.input_times.append(now)
                    if len(p.input_times) > threshold:
                        _log(f"[KICK] {p.name} kicked for input flood")
                        self._kick_pid(p.pid, "Input flood detected")
                        return

                seq = m.get("seq", 0)
                if seq > p.last_seq:
                    p.last_seq = seq
                    p.inputs = {
                        "gas":   bool(m.get("gas")),
                        "brake": bool(m.get("brake")),
                        "left":  bool(m.get("left")),
                        "right": bool(m.get("right")),
                        "hb":    bool(m.get("hb")),
                    }

        elif t == C_CHAT:
            if not self.cfg.get("chat_enabled", True):
                return
            if p.muted:
                p.send({"type": S_CHAT, "pid": 0, "name": "[Server]",
                         "text": "You are muted."})
                return
            now = time.time()
            rate = float(self.cfg.get("chat_rate_limit", 1.5))
            if now - p.chat_last_t < rate:
                return   # silently rate-limit
            p.chat_last_t = now
            max_len = int(self.cfg.get("chat_max_length", 200))
            text    = str(m.get("text", ""))[:max_len]
            if not text.strip():
                return
            _log(f"[CHAT] {p.name}: {text}")
            self._broadcast({"type": S_CHAT, "pid": p.pid,
                              "name": p.name, "text": text})

        elif t == C_PONG:
            pass

    # ── State ticks ───────────────────────────────────────────────────────────

    def _tick_lobby(self):
        if not self.players: return
        min_p = int(self.cfg.get("min_players_to_start", 1))
        ready  = [p for p in self.players.values() if p.ready]
        if len(ready) >= min_p and len(ready) == len(self.players):
            self._start_voting()

    def _tick_voting(self, dt):
        if time.time() >= self.vote_end:
            self._resolve_vote()

    def _tick_countdown(self, dt):
        self.game_timer -= dt
        if self.game_timer <= 0:
            self._start_game()

    def _tick_racing(self, dt):
        self.game_timer += dt
        for pid, p in self.players.items():
            if not p.car or p.finished: continue
            # Apply trigger zones before physics.
            # Each trigger tracks active/inactive state globally (toggle on entry).
            # We use per-player _was_touching stored on the player object so
            # one player entering a zone doesn't affect another player's toggle.
            for i, tz in enumerate(self.trigger_zones):
                key = f"tz_{i}"
                was = p.trig_touch.get(key, False)
                touching = tz.rect.collidepoint(p.car.x, p.car.y)
                if not touching:
                    for cx, cy in p.car.get_corners():
                        if tz.rect.collidepoint(cx, cy):
                            touching = True; break
                if touching and not was:
                    # Toggle this trigger for this player only
                    p.trig_active[key] = not p.trig_active.get(key, False)
                p.trig_touch[key] = touching
                # Apply if active for this player
                if p.trig_active.get(key, False):
                    tz.apply_to_car(p.car)
            p.car.update(dict_to_keys(p.inputs), dt)
            p.drift_score = p.car.drift_score
            for wr in self.walls:
                p.car.push_out_of_rect(wr, True)
            self._check_checkpoints(p)

        if self.mode == MODE_BUMPER:
            self._detect_bumper_hits()

        if self.mode == MODE_RACE:
            timeout  = self.game_timer > float(self.cfg.get("race_timeout", RACE_TIMEOUT))
            all_done = all(p.finished for p in self.players.values() if p.car)
            if (all_done and self.players) or timeout:
                self._end_game()
        elif self.mode == MODE_BUMPER:
            if self.game_timer >= float(self.cfg.get("bumper_duration", BUMPER_DURATION)):
                self._end_game()

    # ── Voting ────────────────────────────────────────────────────────────────

    def _start_voting(self):
        self.state    = ST_VOTING
        dur           = float(self.cfg.get("vote_duration", VOTE_DURATION))
        self.vote_end = time.time() + dur
        level_list    = [{"key": k, "name": v.get("name", k)}
                          for k, v in self.levels.items()]
        self._broadcast({
            "type":     S_VOTE_START,
            "levels":   level_list,
            "modes":    [{"id": m, "label": MODE_LABELS[m],
                           "desc": MODE_DESCS[m]} for m in MODES],
            "duration": dur,
        })
        _log("[VOTE] Voting started")

    def _send_vote_update(self):
        lv = {};  mv = {}
        for p in self.players.values():
            if p.vote_level: lv[p.vote_level] = lv.get(p.vote_level, 0) + 1
            if p.vote_mode:  mv[p.vote_mode]  = mv.get(p.vote_mode,  0) + 1
        self._broadcast({"type": S_VOTE_UPDATE,
                          "level_votes": lv, "mode_votes": mv})

    def _resolve_vote(self):
        if not self.levels:
            _log("[WARN] No levels — cannot start."); return
        lv = {};  mv = {}
        for p in self.players.values():
            if p.vote_level: lv[p.vote_level] = lv.get(p.vote_level, 0) + 1
            if p.vote_mode:  mv[p.vote_mode]  = mv.get(p.vote_mode,  0) + 1

        self.level_key  = max(lv, key=lv.get) if lv else random.choice(list(self.levels.keys()))
        self.mode       = max(mv, key=mv.get) if mv else MODE_RACE
        self.level_data = self.levels[self.level_key]
        _log(f"[VOTE] Result: {self.level_key}  /  {self.mode}")
        self._start_countdown()

    def _start_countdown(self):
        self.state      = ST_COUNTDOWN
        secs            = float(self.cfg.get("countdown_secs", COUNTDOWN_SECS))
        self.game_timer = secs
        lname           = self.level_data.get("name", self.level_key)
        self._broadcast({"type": S_COUNTDOWN, "seconds": secs,
                          "level_key": self.level_key, "level_name": lname,
                          "mode": self.mode})
        _log(f"[SRV]  Countdown: {lname} / {MODE_LABELS.get(self.mode, self.mode)}")

    # ── Game ──────────────────────────────────────────────────────────────────

    def _start_game(self):
        ld  = self.level_data
        sx  = float(ld.get("start_x", 500))
        sy  = float(ld.get("start_y", 500))
        sa  = float(ld.get("start_angle", 0))

        self.walls = [pygame.Rect(int(w["x"]), int(w["y"]),
                                   int(w["w"]), int(w["h"]))
                      for w in ld.get("walls", [])]
        self.checkpoints = []
        for cp in ld.get("checkpoints", []):
            if len(cp) == 2:
                self.checkpoints.append(pygame.Rect(int(cp[0])-60, int(cp[1])-60, 120, 120))
            else:
                self.checkpoints.append(pygame.Rect(int(cp[0]), int(cp[1]),
                                                     int(cp[2]), int(cp[3])))
        self.max_laps = ld.get("lap_count", 3)

        # Build server-side trigger zones (honoured only if triggers_enabled)
        self.trigger_zones = []
        if self.cfg.get("triggers_enabled", True):
            for td in ld.get("triggers", []):
                try:
                    self.trigger_zones.append(ServerTriggerZone(td))
                except Exception as e:
                    _log(f"[WARN] Could not load trigger: {e}")

        spawns     = _spawn_grid(sx, sy, sa, len(self.players))
        player_list= []
        for i, (pid, p) in enumerate(self.players.items()):
            spx, spy = spawns[i]
            p.car    = CarController(spx, spy, sa, p.color)
            p.car.particle_quality = "Off"
            p.car.skidmarks_on     = False
            p.lap = p.next_cp = 0
            p.lap_times  = [];  p.best_lap   = None
            p.finished   = False; p.finish_time = None
            p.hits       = 0;    p.hit_cd      = {}
            p.drift_score= 0;    p.lap_start   = time.time()
            p.trig_touch  = {};  p.trig_active  = {}
            player_list.append({"pid": pid, "name": p.name, "color": p.color,
                                  "x": spx, "y": spy, "angle": sa})

        self.state        = ST_RACING
        self.game_timer   = 0.0
        self.game_start_t = time.time()
        self._broadcast({"type": S_GAME_START, "level_key": self.level_key,
                          "mode": self.mode, "players": player_list})
        _log(f"[GAME] Started: {self.level_key} / {self.mode} "
             f"({len(self.players)} players)")

    def _check_checkpoints(self, p):
        if not self.checkpoints or p.next_cp >= len(self.checkpoints): return
        cp  = self.checkpoints[p.next_cp]
        car = p.car
        hit = cp.collidepoint(car.x, car.y)
        if not hit:
            for cx, cy in car.get_corners():
                if cp.collidepoint(cx, cy): hit = True; break
        if not hit: return

        p.next_cp += 1
        if p.next_cp >= len(self.checkpoints):
            p.lap += 1
            now = time.time();  lt = now - p.lap_start
            p.lap_times.append(lt)
            if p.best_lap is None or lt < p.best_lap: p.best_lap = lt
            p.lap_start = now;  p.next_cp = 0
            self._broadcast({"type": S_LAP, "pid": p.pid,
                              "lap": p.lap, "lap_time": round(lt, 3)})
            _log(f"[LAP]  {p.name} — Lap {p.lap}  {lt:.2f}s")
            if self.mode == MODE_RACE and p.lap >= self.max_laps:
                p.finished    = True
                p.finish_time = time.time() - self.game_start_t
                self._broadcast({"type": S_FINISH, "pid": p.pid,
                                  "total_time": round(p.finish_time, 3)})
                _log(f"[FIN]  {p.name} finished in {p.finish_time:.2f}s")

    def _detect_bumper_hits(self):
        pids = list(self.players.keys());  now = time.time()
        for i in range(len(pids)):
            for j in range(i+1, len(pids)):
                a = self.players[pids[i]];  b = self.players[pids[j]]
                if not a.car or not b.car: continue
                dist = math.hypot(a.car.x - b.car.x, a.car.y - b.car.y)
                if dist > 38: continue
                if dist > 0:
                    nx = (b.car.x - a.car.x)/dist;  ny = (b.car.y - a.car.y)/dist
                    push = max(0, 38 - dist) * 0.5
                    b.car.vx += nx*push*8;  b.car.vy += ny*push*8
                    a.car.vx -= nx*push*8;  a.car.vy -= ny*push*8
                    b.car.x  += nx*push;    b.car.y  += ny*push
                    a.car.x  -= nx*push;    a.car.y  -= ny*push
                cd_key = f"{min(pids[i],pids[j])}_{max(pids[i],pids[j])}"
                if now - a.hit_cd.get(cd_key, 0) > 1.5:
                    a.hit_cd[cd_key] = b.hit_cd[cd_key] = now
                    scorer = a if a.car.speed >= b.car.speed else b
                    scorer.hits += 1

    def _end_game(self):
        self.state = ST_RESULTS
        results = []
        for pid, p in self.players.items():
            results.append({
                "pid":         pid,
                "name":        p.name,
                "color":       p.color,
                "laps":        p.lap,
                "best_lap":    round(p.best_lap,   3) if p.best_lap   else None,
                "total_time":  round(p.finish_time, 3) if p.finish_time else None,
                "hits":        p.hits,
                "drift_score": p.drift_score,
            })
        if self.mode == MODE_RACE:
            results.sort(key=lambda r: (r["total_time"] is None,
                                         r["total_time"] or 9999, -r["laps"]))
        else:
            results.sort(key=lambda r: -r["hits"])

        self._broadcast({"type": S_GAME_OVER, "results": results})
        delay = float(self.cfg.get("results_display_secs", 15.0))
        _log(f"[GAME] Over — lobby reset in {delay:.0f}s")

        def _back():
            time.sleep(delay)
            with self.lock:
                if self.state == ST_RESULTS:
                    self._reset_lobby()
        threading.Thread(target=_back, daemon=True).start()

    def _reset_lobby(self):
        self.state = ST_LOBBY
        self.level_key = self.level_data = self.mode = None
        self.walls = [];  self.checkpoints = [];  self.trigger_zones = []
        for p in self.players.values():
            p.ready = p.finished = False
            p.vote_level = p.vote_mode = p.car = None
        self._send_lobby()
        _log("[SRV]  Lobby reset")

    # ── Broadcast helpers ─────────────────────────────────────────────────────

    def _send_lobby(self):
        snap = [{"pid": p.pid, "name": p.name,
                  "color": p.color, "ready": p.ready}
                 for p in self.players.values()]
        self._broadcast({"type": S_LOBBY, "players": snap})

    def _broadcast_state(self):
        st = {}
        for pid, p in self.players.items():
            if p.car:
                st[str(pid)] = {
                    "x":          round(p.car.x, 1),
                    "y":          round(p.car.y, 1),
                    "angle":      round(p.car.angle, 1),
                    "speed":      round(p.car.speed, 1),
                    "lat":        round(p.car.lat_speed, 1),
                    "drifting":   p.car.is_drifting,
                    "boost":      round(p.car.boost, 2),
                    "hits":       p.hits,
                    "lap":        p.lap,
                    "next_cp":    p.next_cp,
                    "finished":   p.finished,
                    "drift_score":p.drift_score,
                }
        self._broadcast({"type": S_STATE, "players": st})

    def _broadcast(self, msg, exclude=None):
        dead = []
        for pid, p in self.players.items():
            if pid == exclude: continue
            if not p.send(msg): dead.append(pid)
        for pid in dead:
            self._disconnect(pid)

    def _disconnect(self, pid):
        p = self.players.pop(pid, None)
        if p:
            try: p.conn.close()
            except: pass
            _log(f"[DISC] {p.name} (pid={pid}) disconnected")
            self._broadcast({"type": S_PLAYER_LEAVE, "pid": pid})
            self._send_lobby()
            if self.state == ST_RACING and not self.players:
                self._reset_lobby()

    # ── Operator actions (called from console, already hold lock if needed) ───

    def _kick_pid(self, pid, reason="Kicked by operator"):
        """Disconnect a player and notify them. Must be called with lock held."""
        p = self.players.get(pid)
        if p:
            p.send({"type": "error", "msg": f"You were kicked: {reason}"})
            time.sleep(0.05)
            self._disconnect(pid)

    def _find_player(self, token):
        """Find a player by pid (int) or name prefix (case-insensitive)."""
        try:
            pid = int(token)
            return self.players.get(pid)
        except ValueError:
            token_lower = token.lower()
            for p in self.players.values():
                if p.name.lower().startswith(token_lower):
                    return p
        return None

    # ── Operator console ──────────────────────────────────────────────────────

    def _console_loop(self):
        """Runs in a daemon thread — reads stdin for operator commands."""
        while self._running:
            try:
                line = input().strip()
            except EOFError:
                break
            except Exception:
                continue
            if not line:
                continue
            try:
                self._console_cmd(line)
            except Exception:
                print(f"[CMD]  Error:\n{traceback.format_exc()}")

    def _console_cmd(self, line):
        parts = line.split(None, 2)
        cmd   = parts[0].lower()

        # ── help ──────────────────────────────────────────────────────────────
        if cmd == "help":
            print("""
  list                     list connected players
  kick  <pid|name>         kick a player
  ban   <pid|name>         ban a player's IP and kick them
  unban <ip>               remove an IP from the ban list
  bans                     show all banned IPs
  mute  <pid|name>         silence a player's chat
  unmute <pid|name>        restore a player's chat
  msg   <text>             send a server announcement to all players
  skip                     skip voting or force-end the current game
  reload                   reload all .lev files from disk
  config                   print all config values
  set   <key> <value>      change a config value (takes effect immediately)
  help  <key>              describe a config key
  status                   show server state and player count
  quit / exit              shut down the server gracefully
""")

        # ── list ──────────────────────────────────────────────────────────────
        elif cmd == "list":
            with self.lock:
                if not self.players:
                    print("  (no players connected)")
                    return
                print(f"  {'PID':<5} {'Name':<20} {'IP':<16} {'State':<10}")
                print("  " + "-"*55)
                for p in self.players.values():
                    tags = []
                    if p.ready:   tags.append("ready")
                    if p.muted:   tags.append("muted")
                    if p.is_op:   tags.append("OP")
                    if p.finished:tags.append("finished")
                    st = ",".join(tags) if tags else "-"
                    print(f"  {p.pid:<5} {p.name:<20} {p.ip:<16} {st}")

        # ── kick ──────────────────────────────────────────────────────────────
        elif cmd == "kick":
            if len(parts) < 2:
                print("  Usage: kick <pid|name>"); return
            with self.lock:
                p = self._find_player(parts[1])
                if not p:
                    print(f"  Player '{parts[1]}' not found."); return
                reason = parts[2] if len(parts) > 2 else "Kicked by operator"
                _log(f"[KICK] {p.name} (pid={p.pid}) — {reason}")
                self._kick_pid(p.pid, reason)

        # ── ban ───────────────────────────────────────────────────────────────
        elif cmd == "ban":
            if len(parts) < 2:
                print("  Usage: ban <pid|name>"); return
            with self.lock:
                p = self._find_player(parts[1])
                if not p:
                    print(f"  Player '{parts[1]}' not found."); return
                ip = p.ip
                if ip not in self.cfg.setdefault("banned_ips", []):
                    self.cfg["banned_ips"].append(ip)
                    save_config(self.cfg, self.config_path)
                reason = parts[2] if len(parts) > 2 else "Banned by operator"
                _log(f"[BAN]  {p.name} (pid={p.pid}) IP={ip} — {reason}")
                self._kick_pid(p.pid, reason)
                print(f"  Banned {ip}")

        # ── unban ─────────────────────────────────────────────────────────────
        elif cmd == "unban":
            if len(parts) < 2:
                print("  Usage: unban <ip>"); return
            ip = parts[1]
            bans = self.cfg.setdefault("banned_ips", [])
            if ip in bans:
                bans.remove(ip)
                save_config(self.cfg, self.config_path)
                _log(f"[BAN]  Removed ban for {ip}")
                print(f"  Unbanned {ip}")
            else:
                print(f"  {ip} is not banned.")

        # ── bans ──────────────────────────────────────────────────────────────
        elif cmd == "bans":
            bans = self.cfg.get("banned_ips", [])
            if bans:
                print("  Banned IPs:")
                for ip in bans:
                    print(f"    {ip}")
            else:
                print("  No banned IPs.")

        # ── mute ──────────────────────────────────────────────────────────────
        elif cmd == "mute":
            if len(parts) < 2:
                print("  Usage: mute <pid|name>"); return
            with self.lock:
                p = self._find_player(parts[1])
                if not p:
                    print(f"  Player '{parts[1]}' not found."); return
                p.muted = True
                p.send({"type": S_CHAT, "pid": 0, "name": "[Server]",
                         "text": "You have been muted by the operator."})
                _log(f"[MUTE] {p.name} muted")
                print(f"  Muted {p.name}")

        # ── unmute ────────────────────────────────────────────────────────────
        elif cmd == "unmute":
            if len(parts) < 2:
                print("  Usage: unmute <pid|name>"); return
            with self.lock:
                p = self._find_player(parts[1])
                if not p:
                    print(f"  Player '{parts[1]}' not found."); return
                p.muted = False
                p.send({"type": S_CHAT, "pid": 0, "name": "[Server]",
                         "text": "You have been unmuted."})
                _log(f"[MUTE] {p.name} unmuted")
                print(f"  Unmuted {p.name}")

        # ── msg ───────────────────────────────────────────────────────────────
        elif cmd == "msg":
            if len(parts) < 2:
                print("  Usage: msg <text>"); return
            text = line[len(cmd):].strip()
            _log(f"[MSG]  Broadcast: {text}")
            with self.lock:
                self._broadcast({"type": S_CHAT, "pid": 0,
                                  "name": "[Server]", "text": text})

        # ── skip ──────────────────────────────────────────────────────────────
        elif cmd == "skip":
            with self.lock:
                if self.state == ST_VOTING:
                    _log("[SKIP] Operator skipped voting — resolving now")
                    self.vote_end = 0.0   # will resolve next tick
                    print("  Voting skipped — resolving now.")
                elif self.state == ST_RACING:
                    _log("[SKIP] Operator force-ended the game")
                    self._end_game()
                    print("  Game force-ended.")
                elif self.state == ST_LOBBY:
                    _log("[SKIP] Operator force-started voting")
                    self._start_voting()
                    print("  Voting started.")
                else:
                    print(f"  Nothing to skip in state: {self.state}")

        # ── reload ────────────────────────────────────────────────────────────
        elif cmd == "reload":
            with self.lock:
                old_count = len(self.levels)
                self.levels = load_levels(self.cfg["levels_dir"])
                _log(f"[LEV]  Reloaded: {old_count} → {len(self.levels)} levels")
                print(f"  Loaded {len(self.levels)} level(s).")

        # ── status ────────────────────────────────────────────────────────────
        elif cmd == "status":
            with self.lock:
                print(f"  State:   {self.state}")
                print(f"  Players: {len(self.players)} / {self.cfg.get('max_players', MAX_PLAYERS)}")
                if self.level_key:
                    print(f"  Level:   {self.level_key}")
                if self.mode:
                    print(f"  Mode:    {self.mode}")
                if self.state == ST_VOTING:
                    print(f"  Vote ends in: {max(0.0, self.vote_end - time.time()):.1f}s")
                if self.state == ST_RACING:
                    print(f"  Game time: {self.game_timer:.1f}s")

        # ── config ────────────────────────────────────────────────────────────
        elif cmd == "config":
            if len(parts) >= 2:
                # help for a specific key
                key = parts[1]
                if key in CONFIG_HELP:
                    print(f"  {key}: {CONFIG_HELP[key]}")
                    print(f"  Current value: {self.cfg.get(key)}")
                else:
                    print(f"  Unknown config key: {key}")
                return
            print(f"\n  {'Key':<30} {'Value'}")
            print("  " + "-"*60)
            for k, v in self.cfg.items():
                if k == "banned_ips":
                    print(f"  {'banned_ips':<30} [{len(v)} IP(s) — use 'bans' to list]")
                else:
                    print(f"  {k:<30} {v}")
            print()

        # ── set ───────────────────────────────────────────────────────────────
        elif cmd == "set":
            if len(parts) < 3:
                print("  Usage: set <key> <value>"); return
            key   = parts[1]
            value = parts[2]
            if key not in DEFAULT_CONFIG:
                print(f"  Unknown key '{key}'. Type 'config' to see all keys."); return
            if key == "banned_ips":
                print("  Use 'ban' / 'unban' commands instead."); return

            # Type coerce to match default type
            default = DEFAULT_CONFIG[key]
            try:
                if isinstance(default, bool):
                    coerced = value.lower() in ("true","1","yes","on")
                elif isinstance(default, int):
                    coerced = int(value)
                elif isinstance(default, float):
                    coerced = float(value)
                else:
                    coerced = value
            except ValueError:
                print(f"  Bad value — expected {type(default).__name__}"); return

            self.cfg[key] = coerced
            save_config(self.cfg, self.config_path)
            _log(f"[CFG]  Set {key} = {coerced!r}")
            print(f"  {key} = {coerced!r}  (saved)")

            # Side effects for certain keys
            if key == "log_file":
                _set_log_file(coerced)

        # ── quit ──────────────────────────────────────────────────────────────
        elif cmd in ("quit", "exit"):
            _log("[SRV]  Operator initiated shutdown")
            with self.lock:
                self._broadcast({"type": S_CHAT, "pid": 0, "name": "[Server]",
                                  "text": "Server is shutting down."})
            self._running = False
            sys.exit(0)

        else:
            print(f"  Unknown command '{cmd}'. Type 'help' for a list.")


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__ == "__main__":
    ap = argparse.ArgumentParser(description="Drift Master Multiplayer Server")
    ap.add_argument("--port",   type=int, default=None,
                    help="Override port from config")
    ap.add_argument("--levels", type=str, default=None,
                    help="Override levels directory from config")
    ap.add_argument("--config", type=str, default=CONFIG_FILE,
                    help=f"Config file path (default: {CONFIG_FILE})")
    args = ap.parse_args()

    cfg = load_config(args.config)

    # CLI overrides
    if args.port   is not None: cfg["port"]       = args.port
    if args.levels is not None: cfg["levels_dir"] = args.levels

    Server(cfg, args.config).run()