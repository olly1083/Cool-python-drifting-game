"""
main.py  –  Da Drifting Game  (Pygbag / Browser build)

HOW TO RUN IN BROWSER:
  pip install pygbag pygame-ce
  python -m pygbag .
  Open http://localhost:8000 in Chrome / Edge / Brave

HOW TO BUILD FOR DEPLOYMENT:
  python -m pygbag --build .
  Upload the contents of build/web/ to itch.io, GitHub Pages, Netlify etc.

DESKTOP VERSION:
  Rename your original main.py → main_desktop.py
  Use THIS file as main.py for the browser build
  Run desktop:  python main_desktop.py
"""
# /// script
# dependencies = ["pygame-ce"]
# ///

import asyncio, sys, json, math, os, random
import pygame

IS_WEB = sys.platform == "emscripten"

# ── Browser save-data shim ────────────────────────────────────────────────────
# Intercept SaveData._load / .save to use localStorage on web.

from settings import SaveData

_orig_load = SaveData._load
_orig_save = SaveData.save

def _web_load(self):
    if IS_WEB:
        try:
            import platform
            raw = platform.window.localStorage.getItem("drift_master_save")
            if raw:
                data = json.loads(raw)
                for k, v in data.get("settings", {}).items():
                    if k in self.settings: self.settings[k] = v
                for k, v in data.get("prefs", {}).items():
                    if k in self.prefs: self.prefs[k] = v
                self.stats["levels"] = data.get("stats", {}).get("levels", {})
                return
        except Exception:
            pass
    _orig_load(self)

def _web_save(self):
    if IS_WEB:
        try:
            import platform
            platform.window.localStorage.setItem(
                "drift_master_save",
                json.dumps({"settings": self.settings,
                             "prefs":    self.prefs,
                             "stats":    self.stats}, indent=2))
            return
        except Exception:
            pass
    _orig_save(self)

SaveData._load = _web_load
SaveData.save  = _web_save


# ── Imports ───────────────────────────────────────────────────────────────────
import os.path
from settings import SaveData, RESOLUTIONS, PARTICLE_QUALITIES, FPS_OPTIONS

LEVELS_DIR = "levels"

def load_level(path):
    with open(path) as f:
        return json.load(f)

def list_levels():
    out = []
    if not os.path.isdir(LEVELS_DIR):
        return out
    for fn in sorted(os.listdir(LEVELS_DIR)):
        if fn.endswith(".lev"):
            p = os.path.join(LEVELS_DIR, fn)
            try:
                d = load_level(p)
                out.append({"path": p, "key": fn,
                             "name": d.get("name", fn),
                             "laps": d.get("lap_count", 3),
                             "target": d.get("target_score", 0)})
            except Exception:
                pass
    return out


def make_screen(sd: SaveData):
    if IS_WEB:
        # Fixed canvas size on web — browser CSS handles scaling
        screen = pygame.display.set_mode((1100, 700))
    else:
        flags = pygame.FULLSCREEN if sd.settings["fullscreen"] else 0
        vsync = 1 if sd.settings["vsync"] else 0
        w, h  = sd.settings["resolution"]
        screen = pygame.display.set_mode((w, h), flags, vsync=vsync)
    pygame.display.set_caption("Da Drifting Game")
    return screen


# ── tick() patches ────────────────────────────────────────────────────────────
# Pygbag cannot have blocking while-loops inside functions.
# We monkey-patch a tick() method onto each class so the async main loop
# can call it one frame at a time and yield back to the browser between frames.

def _add_ticks():
    from main_desktop import GameSession, SettingsScreen
    from mainmenu import MainMenu
    from level_creator import LevelCreator
    from controller import pump_controller_events, nav_input, ControllerKeys

    # ── GameSession.tick() ────────────────────────────────────────────────────
    def gs_tick(self):
        dt  = min(self.clock.tick(60) / 1000.0, 0.05)
        inp = pump_controller_events(dt)
        res = self._ctrl_events(inp)
        if res: return res
        if not self.paused and not self.finished:
            ck = ControllerKeys(inp)
            for tz in self.triggers:
                tz.update(self.car)
                tz.apply_to_car(self.car)
            self.car.update(ck, dt)
            for w in self.walls:
                if w.collide(self.car):
                    if self.sd.settings["camera_shake"]:
                        self.shake = max(self.shake, 6.0)
            self._checkpoints()
            self._camera(dt)
            for bp in self.boost_pads:
                bp.update(self.car, dt)
            self.popups = [p for p in self.popups if p.update(dt)]
            if self.shake > 0:
                self.shake = max(0.0, self.shake - dt * 55)
        if self.finished:
            self.fin_t += dt
            if self.fin_t > 5.0:
                return "menu"
        self._draw()
        return None
    GameSession.tick = gs_tick

    def _ctrl_events(self, inp):
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT: pygame.quit(); sys.exit()
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE: return "menu"
                if ev.key == pygame.K_p:      self.paused = not self.paused
                if ev.key == pygame.K_r:      self._reset()
        if inp.pause and not getattr(self, "_pp", False):
            self.paused = not self.paused
        if inp.reset and not getattr(self, "_pr", False):
            self._reset()
        self._pp = inp.pause
        self._pr = inp.reset
        return None
    GameSession._ctrl_events = _ctrl_events

    # ── SettingsScreen.tick() ─────────────────────────────────────────────────
    def ss_tick(self):
        dt  = self.clock.tick(60) / 1000.0
        inp = pump_controller_events(dt)
        nav = nav_input(dt)
        evs = pygame.event.get()
        mouse = pygame.mouse.get_pos()
        click = any(e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 for e in evs)
        for ev in evs:
            if ev.type == pygame.QUIT: pygame.quit(); sys.exit()
            if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                return self.screen, None
        if nav.menu_back:
            return self.screen, None
        if click:
            if self.apply_r.collidepoint(mouse):
                self.sd.settings.update(self.work)
                self.sd.save()
                return make_screen(self.sd), self.sd
            if self.cancel_r.collidepoint(mouse):
                return self.screen, None
            for i, (_, key, typ, opts) in enumerate(self.rows):
                la, ra, tog = self.rects[i]
                if typ == "bool" and tog and tog.collidepoint(mouse):
                    self.work[key] = not self.work[key]
                elif typ != "bool":
                    if la and la.collidepoint(mouse): self._cycle(key, opts, -1)
                    if ra and ra.collidepoint(mouse): self._cycle(key, opts, +1)
        self._draw(mouse)
        return None
    SettingsScreen.tick = ss_tick

    # ── MainMenu.tick() ───────────────────────────────────────────────────────
    def mm_tick(self):
        dt  = self.clock.tick(60) / 1000.0
        self.t += dt
        inp = pump_controller_events(dt)
        nav = nav_input(dt)
        evs = pygame.event.get()
        mouse = pygame.mouse.get_pos()

        # Initialise controller menu navigator on first use
        if not hasattr(self, "_ctrl_nav"):
            from controller import MenuNavigator
            self._ctrl_nav = MenuNavigator(len(self.mbtns))

        for ev in evs:
            if ev.type == pygame.QUIT: pygame.quit(); sys.exit()
            if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                if self.state != "main": self.state = "main"
        if nav.menu_back and self.state != "main":
            self.state = "main"; return None

        self.bg.update()

        # Controller navigation — synthesise fake click on confirm
        ctrl_click_evs = list(evs)
        if nav.controller_active and self.state == "main":
            result = self._ctrl_nav.update(nav)
            if result == "confirm" and 0 <= self._ctrl_nav.index < len(self.mbtns):
                # Simulate a mouse click on the selected button
                btn_rect = self.mbtns[self._ctrl_nav.index].r
                fake_ev  = pygame.event.Event(pygame.MOUSEBUTTONDOWN,
                                               {"button": 1, "pos": btn_rect.center})
                ctrl_click_evs.append(fake_ev)
                mouse = btn_rect.center
            if result == "back" and self.state != "main":
                self.state = "main"; return None
        elif not nav.controller_active:
            # Reset nav index when mouse takes over so highlight stays sensible
            if hasattr(self, "_ctrl_nav"):
                # Track which button mouse is hovering
                for i, b in enumerate(self.mbtns):
                    if b.r.collidepoint(mouse):
                        self._ctrl_nav.index = i

        if   self.state == "main":     return self._main(mouse, ctrl_click_evs)
        elif self.state == "levels":   return self._levels(mouse, ctrl_click_evs)
        elif self.state == "cars":     return self._cars(mouse, ctrl_click_evs)
        elif self.state == "controls": return self._controls(mouse, ctrl_click_evs)
        return None
    MainMenu.tick = mm_tick

    # Patch MainMenu._main to draw the controller cursor
    _orig_main = MainMenu._main
    def _main_patched(self, mouse, evs, **kw):
        result = _orig_main(self, mouse, evs, **kw)
        # Draw controller selection cursor if controller is active
        if hasattr(self, "_ctrl_nav") and _state.controller_active:
            from controller import _state as _cs
            self._ctrl_nav.num_items = len(self.mbtns)
            if self.mbtns:
                first = self.mbtns[0].r
                self._ctrl_nav.draw_cursor(
                    self.screen,
                    x=first.left,
                    y=first.top,
                    item_height=first.height + 13,  # bh+gap from _mk_btns
                )
        return result
    MainMenu._main = _main_patched

    # ── LevelCreator.tick() ───────────────────────────────────────────────────
    def lc_tick(self):
        dt = self.clock.tick(60) / 1000.0
        pump_controller_events(dt)
        if self.notif_t > 0: self.notif_t -= dt

        # Show/hide on-screen keyboard based on text editing state
        from controller import show_keyboard, hide_keyboard
        if self.editing_name or self.editing_text:
            show_keyboard()
        else:
            hide_keyboard()

        evs   = pygame.event.get()
        mouse = pygame.mouse.get_pos()
        res   = self._events(evs, mouse, dt)
        if res is not None: return res
        self._draw(mouse)
        return None
    LevelCreator.tick = lc_tick

    return GameSession, SettingsScreen, MainMenu, LevelCreator


# ── Async main ────────────────────────────────────────────────────────────────

async def main():
    pygame.init()
    pygame.joystick.init()   # required for controller detection

    # Patch tick() onto all game classes
    GameSession, SettingsScreen, MainMenu, LevelCreator = _add_ticks()

    # Import remaining classes needed at runtime
    from main_desktop import build_bg, Wall, BoostPad, TriggerZone, \
                              LevelText, Checkpoint, Popup

    sd     = SaveData()
    screen = make_screen(sd)

    while True:

        # ── Main menu ─────────────────────────────────────────────────────────
        menu   = MainMenu(screen, sd)
        result = None
        while result is None:
            result = menu.tick()
            pygame.display.flip()
            await asyncio.sleep(0)

        action = result[0]

        # ── Settings ──────────────────────────────────────────────────────────
        if action == "settings":
            ss = SettingsScreen(screen, sd, make_screen)
            r2 = None
            while r2 is None:
                r2 = ss.tick()
                pygame.display.flip()
                await asyncio.sleep(0)
            screen, new_sd = r2
            if new_sd: sd = new_sd
            continue

        # ── Solo race ─────────────────────────────────────────────────────────
        if action == "race":
            _, level_path, level_key, car_color = result
            gs     = GameSession(screen, level_path, level_key, car_color, sd)
            gs_res = None
            while gs_res is None:
                gs_res = gs.tick()
                pygame.display.flip()
                await asyncio.sleep(0)

        # ── Level creator ─────────────────────────────────────────────────────
        elif action == "creator":
            lc     = LevelCreator(screen)
            lc_res = None
            while lc_res is None:
                lc_res = lc.tick()
                pygame.display.flip()
                await asyncio.sleep(0)

        # ── Multiplayer (WebSocket on browser, TCP on desktop) ────────────────
        elif action == "multiplayer":
            from multiplayer_client import run_multiplayer_async
            await run_multiplayer_async(screen, sd)


asyncio.run(main())