"""
main.py  –  Da Drifting Game  (Pygbag / Browser build)

HOW TO RUN IN BROWSER:
  pip install pygbag pygame-ce
  python -m pygbag .
  Open http://localhost:8000 in Chrome / Edge / Brave

HOW TO BUILD FOR DEPLOYMENT:
  python -m pygbag --build .
  Upload build/web/ to itch.io, GitHub Pages, Netlify etc.

DESKTOP:
  python main_desktop.py
"""
# /// script
# dependencies = ["pygame-ce"]
# ///

# ── Only the bare minimum at module level ─────────────────────────────────────
# Pygbag silently shows a black screen if ANY top-level import crashes.
# Keep module-level code to an absolute minimum.
import asyncio
import sys
import os

IS_WEB = sys.platform == "emscripten"

# ── Entry point ───────────────────────────────────────────────────────────────

async def main():
    # All imports happen here so any crash shows in the browser console
    # and we can display a user-friendly error rather than a black screen.
    import pygame
    import json
    import math
    import random

    pygame.init()
    pygame.joystick.init()

    # ── Show a loading screen immediately so the user sees something ──────────
    screen = pygame.display.set_mode((1100, 700))
    pygame.display.set_caption("Da Drifting Game")
    font = pygame.font.SysFont("consolas", 22, bold=True)
    small = pygame.font.SysFont("consolas", 14)

    def show_loading(msg="Loading…", detail=""):
        screen.fill((13, 16, 26))
        t = font.render(msg, True, (205, 192, 92))
        screen.blit(t, (screen.get_width()//2 - t.get_width()//2, 300))
        if detail:
            d = small.render(detail, True, (120, 124, 148))
            screen.blit(d, (screen.get_width()//2 - d.get_width()//2, 340))
        pygame.display.flip()

    show_loading("Da Drifting Game", "Starting up…")
    await asyncio.sleep(0)

    # ── localStorage save-data shim (web only) ────────────────────────────────
    show_loading("Da Drifting Game", "Loading settings…")
    await asyncio.sleep(0)

    from settings import SaveData

    _orig_load = SaveData._load
    _orig_save = SaveData.save

    def _web_load(self):
        if IS_WEB:
            try:
                import platform
                raw = platform.window.localStorage.getItem("drift_master_save")
                if raw:
                    data = json.loads(raw)
                    for k, v in data.get("settings", {}).items():
                        if k in self.settings: self.settings[k] = v
                    for k, v in data.get("prefs", {}).items():
                        if k in self.prefs: self.prefs[k] = v
                    self.stats["levels"] = data.get("stats", {}).get("levels", {})
                    return
            except Exception:
                pass
        _orig_load(self)

    def _web_save(self):
        if IS_WEB:
            try:
                import platform
                platform.window.localStorage.setItem(
                    "drift_master_save",
                    json.dumps({"settings": self.settings,
                                 "prefs":    self.prefs,
                                 "stats":    self.stats}, indent=2))
                return
            except Exception:
                pass
        _orig_save(self)

    SaveData._load = _web_load
    SaveData.save  = _web_save

    # ── Import game modules (each on its own await so loading is visible) ─────
    show_loading("Da Drifting Game", "Loading game modules…")
    await asyncio.sleep(0)

    try:
        from settings import RESOLUTIONS, PARTICLE_QUALITIES, FPS_OPTIONS
        from carcontroller import CarController
    except Exception as e:
        show_loading("Import Error", str(e)[:80])
        await asyncio.sleep(5)
        return

    await asyncio.sleep(0)

    try:
        from main_desktop import (
            Wall, BoostPad, TriggerZone, LevelText,
            Checkpoint, Popup, build_bg,
            GameSession, SettingsScreen,
            load_level, list_levels,
        )
    except Exception as e:
        show_loading("Import Error (main_desktop)", str(e)[:80])
        await asyncio.sleep(5)
        return

    await asyncio.sleep(0)

    try:
        from mainmenu import MainMenu
        from level_creator import LevelCreator
        from controller import pump_controller_events, nav_input, ControllerKeys, MenuNavigator
    except Exception as e:
        show_loading("Import Error (menu/controller)", str(e)[:80])
        await asyncio.sleep(5)
        return

    show_loading("Da Drifting Game", "Almost ready…")
    await asyncio.sleep(0)

    # ── Screen setup ──────────────────────────────────────────────────────────
    sd = SaveData()

    def make_screen(sd):
        if IS_WEB:
            s = pygame.display.set_mode((1100, 700))
        else:
            flags = pygame.FULLSCREEN if sd.settings["fullscreen"] else 0
            vsync = 1 if sd.settings["vsync"] else 0
            w, h  = sd.settings["resolution"]
            s = pygame.display.set_mode((w, h), flags, vsync=vsync)
        pygame.display.set_caption("Da Drifting Game")
        return s

    screen = make_screen(sd)

    # ── Patch tick() onto all game classes ────────────────────────────────────

    # GameSession.tick()
    def gs_tick(self):
        dt  = min(self.clock.tick(60) / 1000.0, 0.05)
        inp = pump_controller_events(dt)
        res = self._ctrl_events(inp)
        if res: return res
        if not self.paused and not self.finished:
            ck = ControllerKeys(inp)
            for tz in self.triggers:
                tz.update(self.car)
                tz.apply_to_car(self.car)
            self.car.update(ck, dt)
            for w in self.walls:
                if w.collide(self.car):
                    if self.sd.settings["camera_shake"]:
                        self.shake = max(self.shake, 6.0)
            self._checkpoints()
            self._camera(dt)
            for bp in self.boost_pads:
                bp.update(self.car, dt)
            self.popups = [p for p in self.popups if p.update(dt)]
            if self.shake > 0:
                self.shake = max(0.0, self.shake - dt * 55)
        if self.finished:
            self.fin_t += dt
            if self.fin_t > 5.0:
                return "menu"
        self._draw()
        return None
    GameSession.tick = gs_tick

    def _ctrl_events(self, inp):
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT: pygame.quit(); sys.exit()
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE: return "menu"
                if ev.key == pygame.K_p:      self.paused = not self.paused
                if ev.key == pygame.K_r:      self._reset()
        if inp.pause and not getattr(self, "_pp", False):
            self.paused = not self.paused
        if inp.reset and not getattr(self, "_pr", False):
            self._reset()
        self._pp = inp.pause
        self._pr = inp.reset
        return None
    GameSession._ctrl_events = _ctrl_events

    # SettingsScreen.tick()
    def ss_tick(self):
        dt    = self.clock.tick(60) / 1000.0
        inp   = pump_controller_events(dt)
        nav   = nav_input(dt)
        evs   = pygame.event.get()
        mouse = pygame.mouse.get_pos()
        click = any(e.type == pygame.MOUSEBUTTONDOWN and e.button == 1 for e in evs)
        for ev in evs:
            if ev.type == pygame.QUIT: pygame.quit(); sys.exit()
            if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                return self.screen, None
        if nav.menu_back:
            return self.screen, None
        if nav.menu_confirm:
            self.sd.settings.update(self.work)
            self.sd.save()
            return make_screen(self.sd), self.sd
        if click:
            if self.apply_r.collidepoint(mouse):
                self.sd.settings.update(self.work)
                self.sd.save()
                return make_screen(self.sd), self.sd
            if self.cancel_r.collidepoint(mouse):
                return self.screen, None
            for i, (_, key, typ, opts) in enumerate(self.rows):
                la, ra, tog = self.rects[i]
                if typ == "bool" and tog and tog.collidepoint(mouse):
                    self.work[key] = not self.work[key]
                elif typ != "bool":
                    if la and la.collidepoint(mouse): self._cycle(key, opts, -1)
                    if ra and ra.collidepoint(mouse): self._cycle(key, opts, +1)
        # Controller left/right on list items
        if nav.menu_left or nav.menu_right:
            if 0 <= getattr(self, "_ctrl_row", 0) < len(self.rows):
                _, key, typ, opts = self.rows[self._ctrl_row]
                if typ != "bool":
                    self._cycle(key, opts, 1 if nav.menu_right else -1)
                elif nav.menu_confirm or nav.menu_right or nav.menu_left:
                    self.work[key] = not self.work[key]
        if nav.menu_up:
            self._ctrl_row = max(0, getattr(self, "_ctrl_row", 0) - 1)
        if nav.menu_down:
            self._ctrl_row = min(len(self.rows)-1, getattr(self, "_ctrl_row", 0) + 1)
        self._draw(mouse)
        return None
    SettingsScreen.tick = ss_tick

    # MainMenu.tick() — reuse mainmenu.py's run() which already has controller support
    # We wrap it to be async-compatible
    def mm_tick(self):
        dt  = self.clock.tick(60) / 1000.0
        self.t += dt
        inp = pump_controller_events(dt)
        nav = nav_input(dt)
        evs = pygame.event.get()
        mouse = pygame.mouse.get_pos()

        if not hasattr(self, "_ctrl_nav"):
            self._ctrl_nav = MenuNavigator(len(self.mbtns))

        for ev in evs:
            if ev.type == pygame.QUIT: pygame.quit(); sys.exit()
            if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                if self.state != "main": self.state = "main"

        if nav.menu_back and self.state != "main":
            self.state = "main"; return None

        self.bg.update()

        fake_evs = list(evs)
        if self.state == "main" and inp.controller_active:
            self._ctrl_nav.num_items = len(self.mbtns)
            action = self._ctrl_nav.update(nav)
            if action == "confirm" and 0 <= self._ctrl_nav.index < len(self.mbtns):
                btn_rect = self.mbtns[self._ctrl_nav.index].r
                fake_ev = pygame.event.Event(pygame.MOUSEBUTTONDOWN,
                                              {"button": 1, "pos": btn_rect.center})
                fake_evs.append(fake_ev)
                mouse = btn_rect.center
        elif not inp.controller_active:
            for i, b in enumerate(self.mbtns):
                if b.r.collidepoint(mouse):
                    self._ctrl_nav.index = i

        if   self.state == "main":     return self._main(mouse, fake_evs, ctrl_nav=self._ctrl_nav, ctrl_active=inp.controller_active)
        elif self.state == "levels":   return self._levels(mouse, fake_evs)
        elif self.state == "cars":     return self._cars(mouse, fake_evs)
        elif self.state == "controls": return self._controls(mouse, fake_evs)
        return None
    MainMenu.tick = mm_tick

    # LevelCreator.tick()
    def lc_tick(self):
        dt = self.clock.tick(60) / 1000.0
        pump_controller_events(dt)
        if self.notif_t > 0: self.notif_t -= dt
        try:
            from controller import show_keyboard, hide_keyboard
            if self.editing_name or self.editing_text:
                show_keyboard()
            else:
                hide_keyboard()
        except Exception:
            pass
        evs   = pygame.event.get()
        mouse = pygame.mouse.get_pos()
        res   = self._events(evs, mouse, dt)
        if res is not None: return res
        self._draw(mouse)
        return None
    LevelCreator.tick = lc_tick

    # ── Main game loop ────────────────────────────────────────────────────────

    while True:

        # Main menu
        menu   = MainMenu(screen, sd)
        result = None
        while result is None:
            result = menu.tick()
            pygame.display.flip()
            await asyncio.sleep(0)

        action = result[0]

        # Settings
        if action == "settings":
            ss = SettingsScreen(screen, sd, make_screen)
            r2 = None
            while r2 is None:
                r2 = ss.tick()
                pygame.display.flip()
                await asyncio.sleep(0)
            screen, new_sd = r2
            if new_sd: sd = new_sd
            continue

        # Solo race
        if action == "race":
            _, level_path, level_key, car_color = result
            gs     = GameSession(screen, level_path, level_key, car_color, sd)
            gs_res = None
            while gs_res is None:
                gs_res = gs.tick()
                pygame.display.flip()
                await asyncio.sleep(0)

        # Level creator
        elif action == "creator":
            lc     = LevelCreator(screen)
            lc_res = None
            while lc_res is None:
                lc_res = lc.tick()
                pygame.display.flip()
                await asyncio.sleep(0)

        # Multiplayer (WebSocket on browser, TCP on desktop)
        elif action == "multiplayer":
            try:
                from multiplayer_client import run_multiplayer_async
                await run_multiplayer_async(screen, sd)
            except Exception as e:
                # Show error briefly then return to menu
                err_font = pygame.font.SysFont("consolas", 18, bold=True)
                screen.fill((13, 16, 26))
                t = err_font.render("Multiplayer error: " + str(e)[:60], True, (215, 80, 80))
                screen.blit(t, (screen.get_width()//2 - t.get_width()//2,
                                screen.get_height()//2))
                h = err_font.render("Press ESC", True, (120, 124, 148))
                screen.blit(h, (screen.get_width()//2 - h.get_width()//2,
                                screen.get_height()//2 + 40))
                pygame.display.flip()
                await asyncio.sleep(3)


asyncio.run(main())