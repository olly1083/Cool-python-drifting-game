"""
settings.py  –  all persistent data for Drift Master
Saves to save_data.json automatically.
"""
import json, os

SAVE_FILE = "save_data.json"

# ── defaults ──────────────────────────────────────────────────────────────────

DEFAULT_SETTINGS = {
    "fullscreen":       False,
    "resolution":       [1100, 700],
    "fps_limit":        60,
    "vsync":            False,
    "particle_quality": "High",    # High / Medium / Low / Off
    "skidmarks":        True,
    "camera_shake":     True,
    "show_fps":         False,
}

DEFAULT_PREFS = {
    "selected_car":   0,    # index into CAR_COLORS
    "selected_level": 0,    # index into level list
}

DEFAULT_STATS = {
    # Per-level stats, keyed by level filename  e.g. "1.lev"
    # Each entry: { "best_lap": null, "best_total": null, "best_score": 0, "races": 0 }
    "levels": {}
}

RESOLUTIONS = [
    (800,  500,  "800 × 500"),
    (1100, 700,  "1100 × 700"),
    (1280, 720,  "1280 × 720"),
    (1600, 900,  "1600 × 900"),
    (1920, 1080, "1920 × 1080"),
]
PARTICLE_QUALITIES = ["Off", "Low", "Medium", "High"]
FPS_OPTIONS        = [30, 60, 120, 144, 0]    # 0 = unlimited


# ── save data container ───────────────────────────────────────────────────────

class SaveData:
    """Single object that owns settings, prefs, and stats. Call save() any time."""

    def __init__(self):
        self.settings = dict(DEFAULT_SETTINGS)
        self.prefs    = dict(DEFAULT_PREFS)
        self.stats    = {"levels": {}}
        self._load()

    # ── persistence ───────────────────────────────────────────────────────────

    def _load(self):
        if not os.path.exists(SAVE_FILE):
            return
        try:
            raw = json.load(open(SAVE_FILE))
            # Merge each section so new keys always get their default
            for k, v in raw.get("settings", {}).items():
                if k in self.settings:
                    self.settings[k] = v
            for k, v in raw.get("prefs", {}).items():
                if k in self.prefs:
                    self.prefs[k] = v
            lvls = raw.get("stats", {}).get("levels", {})
            self.stats["levels"] = lvls
        except Exception:
            pass   # corrupt file → use defaults silently

    def save(self):
        try:
            json.dump(
                {"settings": self.settings,
                 "prefs":    self.prefs,
                 "stats":    self.stats},
                open(SAVE_FILE, "w"), indent=2
            )
        except Exception:
            pass

    # ── stats helpers ─────────────────────────────────────────────────────────

    def _ensure_level(self, level_key):
        if level_key not in self.stats["levels"]:
            self.stats["levels"][level_key] = {
                "best_lap":   None,
                "best_total": None,
                "best_score": 0,
                "races":      0,
            }
        return self.stats["levels"][level_key]

    def record_race(self, level_key, lap_times, drift_score):
        """Call after each completed race. Updates bests and increments race count."""
        entry = self._ensure_level(level_key)
        entry["races"] += 1

        if lap_times:
            best_lap = min(lap_times)
            total    = sum(lap_times)
            if entry["best_lap"] is None or best_lap < entry["best_lap"]:
                entry["best_lap"] = best_lap
            if entry["best_total"] is None or total < entry["best_total"]:
                entry["best_total"] = total

        if drift_score > entry["best_score"]:
            entry["best_score"] = drift_score

        self.save()

    def get_level_stats(self, level_key):
        return self._ensure_level(level_key)