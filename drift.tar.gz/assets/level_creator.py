"""
level_creator.py  –  Drift Master Level Editor

Features:
  • Grid-snapping (toggle G, size adjustable)
  • Draw walls by click-drag rectangle
  • Place checkpoints, boost pads, start point, decorations
  • Select & delete any object by clicking on it
  • Undo / Redo  (Ctrl+Z / Ctrl+Y)
  • Load existing .lev file to edit
  • Save with auto-numbered filename
  • Appearance presets: BG, grass, track, curbs
  • Mini-map overview in sidebar
  • Zoom with scroll wheel, pan with RMB or middle-mouse
  • Keyboard shortcuts shown in-editor
"""
import pygame, sys, json, os, math

LEVELS_DIR = "levels"

# ── colours ───────────────────────────────────────────────────────────────────
BG_PRESETS    = [([22,26,32],"Dark"),([35,25,18],"Sunset"),([18,30,45],"Ocean"),([8,10,18],"Night")]
GRASS_PRESETS = [([32,72,38],"Grass"),([105,75,28],"Desert"),([15,55,105],"Water"),([12,14,26],"Concrete")]
TRACK_PRESETS = [([68,72,78],"Asphalt"),([78,70,58],"Dirt"),([60,70,85],"Slate"),([90,85,70],"Gravel")]
CURB_PRESETS  = [([220,45,45],"Red"),([235,180,0],"Yellow"),([45,160,255],"Blue"),([180,80,255],"Purple")]

TOOLS = ["WALL_OUT","WALL_IN","BOOST","CHECKPOINT","TRIGGER","TEXT","START","DECO","SELECT"]
TOOL_LABEL = {
    "WALL_OUT":"Outer Wall","WALL_IN":"Inner Wall","BOOST":"Boost Pad",
    "CHECKPOINT":"Checkpoint","TRIGGER":"Trigger Zone","TEXT":"Text Label",
    "START":"Start Point","DECO":"Decoration","SELECT":"Select/Delete"
}
TOOL_COL = {
    "WALL_OUT":(215,55,55),"WALL_IN":(55,195,55),"BOOST":(255,210,0),
    "CHECKPOINT":(80,165,255),"TRIGGER":(255,140,80),"TEXT":(220,220,100),
    "START":(255,85,235),"DECO":(80,210,170),"SELECT":(180,180,180)
}
TOOL_KEYS = {
    pygame.K_1:"WALL_OUT",pygame.K_2:"WALL_IN",pygame.K_3:"BOOST",
    pygame.K_4:"CHECKPOINT",pygame.K_5:"TRIGGER",pygame.K_6:"TEXT",
    pygame.K_7:"START",pygame.K_8:"DECO",pygame.K_9:"SELECT"
}

TRIGGER_KINDS   = ["speed","accel","steer","drift"]
TRIGGER_LABELS  = {"speed":"SPEED","accel":"ACCEL","steer":"TURN","drift":"DRIFT"}
TRIGGER_COLORS  = {"speed":(80,220,255),"accel":(120,255,120),"steer":(220,160,255),"drift":(255,80,160)}
TRIGGER_DESC    = {
    "speed": ("Speed Multiplier", "1.0=normal, 2.0=double, 0.5=half", 1.0, 0.1, 10.0),
    "accel": ("Accel Multiplier", "1.0=normal, 2.0=double",           1.0, 0.1, 10.0),
    "steer": ("Steer Multiplier", "1.0=normal, 2.0=double",           1.0, 0.1, 10.0),
    "drift": ("Grip Multiplier",  "0.1=drift, 3.0=grippy",            1.0, 0.05, 10.0),
}
# Convert display km/h to internal px/s for speed triggers
KMH_TO_PX = 300.0 / 300.0   # internal SPEED_MAX=300 px/s ≈ 300 km/h display

SIDE_W = 240   # sidebar width


def w2s(wx, wy, cx, cy, zoom, sw, sh):
    return (wx-cx)*zoom + sw*0.5, (wy-cy)*zoom + sh*0.5

def s2w(sx, sy, cx, cy, zoom, sw, sh):
    return (sx-sw*0.5)/zoom + cx, (sy-sh*0.5)/zoom + cy

def snap(v, grid):
    return round(v / grid) * grid if grid > 0 else v


# ── LevelCreator ──────────────────────────────────────────────────────────────

class LevelCreator:
    def __init__(self, screen):
        self.screen = screen
        self.clock  = pygame.time.Clock()
        self.sw, self.sh = screen.get_size()

        self.fT = pygame.font.SysFont("consolas", 20, bold=True)
        self.fB = pygame.font.SysFont("consolas", 15, bold=True)
        self.fm = pygame.font.SysFont("consolas", 13, bold=True)
        self.ft = pygame.font.SysFont("consolas", 12)

        self._new_level()

        # Camera
        self.cx   = 500.0
        self.cy   = 500.0
        self.zoom = 0.85
        self.pan  = False
        self.pan0 = None
        self.pcam = None

        # Grid
        self.grid_on   = True
        self.grid_size = 20

        # Draw state
        self.tool    = "WALL_OUT"
        self.drawing = False
        self.drag_s  = None          # world-space drag start

        # Selection
        self.sel_type = None         # "wall","boost","cp","deco"
        self.sel_idx  = -1
        self.hover_type = None
        self.hover_idx  = -1

        # Undo / redo
        self.history = []
        self.future  = []

        # Notifications
        self.notif   = ""
        self.notif_t = 0.0

        # Sidebar click rects (rebuilt each frame)
        self._sr = {}
        # Trigger popup state
        self.trigger_popup     = False
        self.trigger_popup_idx = -1
        self._tpop_rects       = {}
        self._tpop_input       = ""       # text input for value
        self._tpop_input_focus = False    # is input box focused
        self._tpop_kind_sel    = "speed"  # which kind is highlighted in popup
        # Toolbar (top-left floating bar)
        self._tb_rects         = {}

    # ── new / load ────────────────────────────────────────────────────────────

    def _new_level(self):
        self.walls       = []
        self.boosts      = []
        self.checkpoints = []
        self.decos       = []
        self.triggers    = []
        self.texts       = []
        self.start       = [500, 500]
        self.start_angle = 0
        self.level_name  = "My Level"
        self.lap_count   = 3
        self.target      = 5000
        self.bg_i = self.gr_i = self.tr_i = self.cu_i = 0
        self.editing_name    = False
        self.editing_text    = False
        self.edit_text_idx   = -1
        self.sel_trigger_kind= "speed_up"
        self._clear_sel()

    def _load(self, path):
        try:
            d = json.load(open(path))
            self._new_level()
            self.level_name  = d.get("name","My Level")
            self.lap_count   = d.get("lap_count",3)
            self.target      = d.get("target_score",5000)
            self.start       = [d.get("start_x",500), d.get("start_y",500)]
            self.start_angle = d.get("start_angle",0)
            self.walls       = d.get("walls",[])
            self.boosts      = d.get("boost_pads",[])
            self.checkpoints = d.get("checkpoints",[])
            self.decos       = d.get("decorations",[])
            self.triggers    = d.get("triggers",[])
            self.texts       = d.get("texts",[])
            # Match colour presets by value
            bgc = d.get("bg_color",[22,26,32])
            for i,(c,_) in enumerate(BG_PRESETS):
                if c==bgc: self.bg_i=i; break
            grc = d.get("grass_color",[32,72,38])
            for i,(c,_) in enumerate(GRASS_PRESETS):
                if c==grc: self.gr_i=i; break
            trc = d.get("track_color",[68,72,78])
            for i,(c,_) in enumerate(TRACK_PRESETS):
                if c==trc: self.tr_i=i; break
            cuc = d.get("curb_color",[220,45,45])
            for i,(c,_) in enumerate(CURB_PRESETS):
                if c==cuc: self.cu_i=i; break
            self.notify(f"Loaded: {os.path.basename(path)}")
        except Exception as e:
            self.notify(f"Load error: {e}")

    # ── undo / redo ───────────────────────────────────────────────────────────

    def _snapshot(self):
        import copy
        s = {"walls":copy.deepcopy(self.walls),"boosts":copy.deepcopy(self.boosts),
             "checkpoints":copy.deepcopy(self.checkpoints),"decos":copy.deepcopy(self.decos),
             "triggers":copy.deepcopy(self.triggers),"texts":copy.deepcopy(self.texts),
             "start":self.start[:],"start_angle":self.start_angle}
        self.history.append(s)
        if len(self.history)>60: self.history.pop(0)
        self.future.clear()

    def _undo(self):
        if not self.history: return
        import copy
        cur = {"walls":copy.deepcopy(self.walls),"boosts":copy.deepcopy(self.boosts),
               "checkpoints":copy.deepcopy(self.checkpoints),"decos":copy.deepcopy(self.decos),
               "start":self.start[:],"start_angle":self.start_angle}
        self.future.append(cur)
        s = self.history.pop()
        self.walls=s["walls"]; self.boosts=s["boosts"]
        self.checkpoints=s["checkpoints"]; self.decos=s["decos"]
        self.triggers=s.get("triggers",[]); self.texts=s.get("texts",[])
        self.start=s["start"]; self.start_angle=s["start_angle"]
        self._clear_sel(); self.notify("Undo")

    def _redo(self):
        if not self.future: return
        import copy
        cur = {"walls":copy.deepcopy(self.walls),"boosts":copy.deepcopy(self.boosts),
               "checkpoints":copy.deepcopy(self.checkpoints),"decos":copy.deepcopy(self.decos),
               "start":self.start[:],"start_angle":self.start_angle}
        self.history.append(cur)
        s = self.future.pop()
        self.walls=s["walls"]; self.boosts=s["boosts"]
        self.checkpoints=s["checkpoints"]; self.decos=s["decos"]
        self.triggers=s.get("triggers",[]); self.texts=s.get("texts",[])
        self.start=s["start"]; self.start_angle=s["start_angle"]
        self._clear_sel(); self.notify("Redo")

    # ── helpers ───────────────────────────────────────────────────────────────

    def _clear_sel(self):
        self.sel_type=None; self.sel_idx=-1

    def notify(self, msg):
        self.notif=msg; self.notif_t=2.5

    def _on_canvas(self, pos):
        return pos[0] < self.sw - SIDE_W

    def _snap(self, v):
        return snap(v, self.grid_size if self.grid_on else 0)

    def _smouse(self, pos):
        """Return snapped world position for mouse."""
        wx, wy = s2w(pos[0], pos[1], self.cx, self.cy, self.zoom, self.sw-SIDE_W, self.sh)
        return self._snap(wx), self._snap(wy)

    # ── save ──────────────────────────────────────────────────────────────────

    def _save(self):
        os.makedirs(LEVELS_DIR, exist_ok=True)
        nums = []
        for fn in os.listdir(LEVELS_DIR):
            base = os.path.splitext(fn)[0]
            if base.isdigit(): nums.append(int(base))
        # If currently editing one, overwrite it; otherwise use next number
        num = max(nums)+1 if nums else 1
        fn  = f"{num}.lev"
        # Check if name matches an existing file to overwrite
        for f in os.listdir(LEVELS_DIR):
            p = os.path.join(LEVELS_DIR, f)
            try:
                d = json.load(open(p))
                if d.get("name") == self.level_name:
                    fn = f; break
            except: pass

        data = {
            "name":         self.level_name,
            "bg_color":     BG_PRESETS[self.bg_i][0],
            "track_color":  TRACK_PRESETS[self.tr_i][0],
            "grass_color":  GRASS_PRESETS[self.gr_i][0],
            "curb_color":   CURB_PRESETS[self.cu_i][0],
            "start_x":      self.start[0],
            "start_y":      self.start[1],
            "start_angle":  self.start_angle,
            "lap_count":    self.lap_count,
            "target_score": self.target,
            "walls":        self.walls,
            "boost_pads":   self.boosts,
            "checkpoints":  self.checkpoints,
            "decorations":  self.decos,
            "triggers":     self.triggers,
            "texts":        self.texts,
        }
        path = os.path.join(LEVELS_DIR, fn)
        json.dump(data, open(path,"w"), indent=2)
        self.notify(f"Saved → {fn}")

    # ── hit testing ───────────────────────────────────────────────────────────

    def _hit_test(self, wx, wy):
        """Return (type, idx) of object under cursor, or (None,-1)."""
        # Checkpoints (rects)
        for i, cp in enumerate(self.checkpoints):
            # Support both [x,y] legacy and [x,y,w,h]
            if len(cp) == 2:
                cx2, cy2 = cp[0], cp[1]
                if math.hypot(wx-cx2, wy-cy2) < 65:
                    return "cp", i
            else:
                if cp[0]<=wx<=cp[0]+cp[2] and cp[1]<=wy<=cp[1]+cp[3]:
                    return "cp", i
        # Start
        if math.hypot(wx-self.start[0], wy-self.start[1]) < 20:
            return "start", 0
        # Triggers
        for i, tr in enumerate(self.triggers):
            if tr["x"]<=wx<=tr["x"]+tr["w"] and tr["y"]<=wy<=tr["y"]+tr["h"]:
                return "trigger", i
        # Texts
        for i, tx in enumerate(self.texts):
            if math.hypot(wx-tx["x"], wy-tx["y"]) < 30:
                return "text", i
        # Boost pads
        for i, b in enumerate(self.boosts):
            if b["x"]<=wx<=b["x"]+b["w"] and b["y"]<=wy<=b["y"]+b["h"]:
                return "boost", i
        # Decorations
        for i, d in enumerate(self.decos):
            if math.hypot(wx-d["x"], wy-d["y"]) < d.get("r",30)+5:
                return "deco", i
        # Walls (check with small margin)
        for i, w in enumerate(self.walls):
            if w["x"]-3<=wx<=w["x"]+w["w"]+3 and w["y"]-3<=wy<=w["y"]+w["h"]+3:
                return "wall", i
        return None, -1

    def _delete_sel(self):
        if self.sel_type=="wall"    and self.sel_idx>=0: self.walls.pop(self.sel_idx)
        elif self.sel_type=="boost"   and self.sel_idx>=0: self.boosts.pop(self.sel_idx)
        elif self.sel_type=="cp"      and self.sel_idx>=0: self.checkpoints.pop(self.sel_idx)
        elif self.sel_type=="deco"    and self.sel_idx>=0: self.decos.pop(self.sel_idx)
        elif self.sel_type=="trigger" and self.sel_idx>=0: self.triggers.pop(self.sel_idx)
        elif self.sel_type=="text"    and self.sel_idx>=0: self.texts.pop(self.sel_idx)
        self._clear_sel()

    # ── main loop ─────────────────────────────────────────────────────────────

    def run(self):
        while True:
            dt = self.clock.tick(60) / 1000.0
            if self.notif_t > 0: self.notif_t -= dt
            evs  = pygame.event.get()
            mouse= pygame.mouse.get_pos()
            res  = self._events(evs, mouse, dt)
            if res is not None: return res
            self._draw(mouse)
            pygame.display.flip()

    # ── events ────────────────────────────────────────────────────────────────

    def _events(self, evs, mouse, dt):
        for ev in evs:
            if ev.type == pygame.QUIT:
                pygame.quit(); sys.exit()

            # ── keyboard ──────────────────────────────────────────────────────
            if ev.type == pygame.KEYDOWN:
                # Popup value box input (highest priority when focused)
                if self._tpop_input_focus and self.trigger_popup:
                    if ev.key == pygame.K_RETURN:
                        # Apply the typed value
                        if self.trigger_popup_idx < len(self.triggers):
                            try:
                                v = float(self._tpop_input)
                                kind = self.triggers[self.trigger_popup_idx].get("kind","speed")
                                _, _, default, vmin, vmax = TRIGGER_DESC.get(kind,("","",1.0,0.1,99))
                                v = max(vmin, min(vmax, v))
                                self.triggers[self.trigger_popup_idx]["value"] = v
                                self.notify(f"Set {TRIGGER_LABELS.get(kind,kind)} = {v:.2f}")
                            except ValueError:
                                pass
                        self._tpop_input_focus = False
                    elif ev.key == pygame.K_ESCAPE:
                        self._tpop_input_focus = False
                    elif ev.key == pygame.K_BACKSPACE:
                        self._tpop_input = self._tpop_input[:-1]
                    elif ev.unicode in "0123456789.":
                        if len(self._tpop_input) < 8:
                            self._tpop_input += ev.unicode
                    continue

                if self.editing_text and self.edit_text_idx >= 0 and self.edit_text_idx < len(self.texts):
                    tx = self.texts[self.edit_text_idx]
                    if ev.key in (pygame.K_RETURN, pygame.K_ESCAPE):
                        self.editing_text = False
                    elif ev.key == pygame.K_BACKSPACE:
                        tx["text"] = tx["text"][:-1]
                    elif ev.unicode.isprintable():
                        tx["text"] += ev.unicode
                    continue
                if self.editing_name:
                    if ev.key in (pygame.K_RETURN, pygame.K_ESCAPE):
                        self.editing_name = False
                    elif ev.key == pygame.K_BACKSPACE:
                        self.level_name = self.level_name[:-1]
                    elif len(self.level_name) < 30 and ev.unicode.isprintable():
                        self.level_name += ev.unicode
                    continue

                mods = pygame.key.get_mods()
                if ev.key == pygame.K_ESCAPE:
                    if self.trigger_popup:
                        self.trigger_popup = False
                        self.trigger_popup_idx = -1
                    else:
                        return "menu"
                if ev.key == pygame.K_s and mods & pygame.KMOD_CTRL:
                    self._save()
                if ev.key == pygame.K_z and mods & pygame.KMOD_CTRL:
                    self._undo()
                if ev.key == pygame.K_y and mods & pygame.KMOD_CTRL:
                    self._redo()
                if ev.key == pygame.K_g:
                    self.grid_on = not self.grid_on
                    self.notify("Grid " + ("ON" if self.grid_on else "OFF"))
                if ev.key == pygame.K_DELETE or ev.key == pygame.K_BACKSPACE:
                    if self.sel_type:
                        self._snapshot(); self._delete_sel()
                if ev.key == pygame.K_t:
                    # Cycle trigger kind on selected trigger, or change default
                    if self.sel_type=="trigger" and self.sel_idx>=0:
                        kinds=TRIGGER_KINDS
                        cur=self.triggers[self.sel_idx].get("kind","speed_up")
                        nxt=kinds[(kinds.index(cur)+1)%len(kinds)] if cur in kinds else kinds[0]
                        self.triggers[self.sel_idx]["kind"]=nxt
                        self.notify(f"Trigger: {TRIGGER_LABELS.get(nxt,nxt)}")
                    else:
                        kinds=TRIGGER_KINDS
                        cur=self.sel_trigger_kind
                        self.sel_trigger_kind=kinds[(kinds.index(cur)+1)%len(kinds)] if cur in kinds else kinds[0]
                        self.notify(f"Next trigger: {TRIGGER_LABELS.get(self.sel_trigger_kind,self.sel_trigger_kind)}")
                if ev.key == pygame.K_RETURN and self.sel_type=="text" and self.sel_idx>=0:
                    self.editing_text=True; self.edit_text_idx=self.sel_idx
                if ev.key in TOOL_KEYS:
                    self.tool = TOOL_KEYS[ev.key]; self._clear_sel()
                # Rotate start angle
                if ev.key == pygame.K_r and self.sel_type == "start":
                    self.start_angle = (self.start_angle + 45) % 360
                # Grid size
                if ev.key == pygame.K_LEFTBRACKET:
                    self.grid_size = max(5, self.grid_size - 5)
                    self.notify(f"Grid: {self.grid_size}px")
                if ev.key == pygame.K_RIGHTBRACKET:
                    self.grid_size = min(100, self.grid_size + 5)
                    self.notify(f"Grid: {self.grid_size}px")

            # ── scroll wheel zoom ─────────────────────────────────────────────
            if ev.type == pygame.MOUSEWHEEL and self._on_canvas(mouse):
                wx, wy = s2w(mouse[0], mouse[1], self.cx, self.cy,
                             self.zoom, self.sw-SIDE_W, self.sh)
                self.zoom *= 1.12 if ev.y > 0 else 0.89
                self.zoom  = max(0.15, min(5.0, self.zoom))
                nx, ny = w2s(wx, wy, self.cx, self.cy, self.zoom, self.sw-SIDE_W, self.sh)
                self.cx += (nx - mouse[0]) / self.zoom
                self.cy += (ny - mouse[1]) / self.zoom

            # ── mouse down ────────────────────────────────────────────────────
            if ev.type == pygame.MOUSEBUTTONDOWN:
                # Toolbar click check
                tb_res = self._handle_toolbar_click(mouse, [ev])
                if tb_res is not None: return tb_res
                if not self._on_canvas(mouse):
                    res = self._sidebar_click(mouse, ev)
                    if res is not None: return res
                    continue

                # ── Trigger popup click check ─────────────────────────────
                if ev.button == 1 and self.trigger_popup:
                    mx2, my2 = mouse
                    clicked_popup = False
                    for key2, r2 in self._tpop_rects.items():
                        if not r2.collidepoint(mx2, my2): continue
                        idx = self.trigger_popup_idx
                        if key2 == "_input":
                            # Focus the value input box
                            if idx < len(self.triggers):
                                kind_now = self.triggers[idx].get("kind","speed")
                                cur_v = self.triggers[idx].get("value",
                                    TRIGGER_DESC.get(kind_now,("","",1.0,0,0))[2])
                                self._tpop_input = f"{cur_v:.2f}"
                            self._tpop_input_focus = True
                            clicked_popup = True; break
                        elif key2 == "_set":
                            # Apply typed value
                            if idx < len(self.triggers):
                                try:
                                    v = float(self._tpop_input)
                                    kind_now=self.triggers[idx].get("kind","speed")
                                    _,_,_,vmin,vmax=TRIGGER_DESC.get(kind_now,("","",1.0,0,99))
                                    v=max(vmin,min(vmax,v))
                                    self.triggers[idx]["value"]=v
                                    self.notify(f"Value = {v:.2f}")
                                except ValueError: pass
                            self._tpop_input_focus = False
                            clicked_popup = True; break
                        elif key2 in TRIGGER_KINDS:
                            # Change kind
                            if idx < len(self.triggers):
                                self.triggers[idx]["kind"] = key2
                                # Reset value to default for new kind
                                default_v = TRIGGER_DESC.get(key2,("","",1.0,0,0))[2]
                                self.triggers[idx].setdefault("value", default_v)
                                self._tpop_input = f"{self.triggers[idx]['value']:.2f}"
                                self.sel_trigger_kind = key2
                            clicked_popup = True; break
                    # Close if clicked outside
                    if not clicked_popup and self._tpop_rects:
                        all_r2 = list(self._tpop_rects.values())
                        mnx=min(r2.x for r2 in all_r2)-10; mxx=max(r2.right for r2 in all_r2)+10
                        mny=min(r2.y for r2 in all_r2)-10; mxy=max(r2.bottom for r2 in all_r2)+10
                        if not (mnx<=mx2<=mxx and mny<=my2<=mxy):
                            self.trigger_popup=False; self.trigger_popup_idx=-1
                            self._tpop_input_focus=False
                    if clicked_popup: continue

                if ev.button == 3 or ev.button == 2:
                    self.pan = True; self.pan0 = mouse
                    self.pcam = (self.cx, self.cy)

                elif ev.button == 1:
                    wx, wy = self._smouse(mouse)

                    if self.tool == "SELECT":
                        t, i = self._hit_test(wx, wy)
                        # Close existing popup if clicking elsewhere
                        if self.trigger_popup and not (t=="trigger" and i==self.trigger_popup_idx):
                            self.trigger_popup = False
                            self.trigger_popup_idx = -1
                        self.sel_type = t; self.sel_idx = i
                        # Open trigger popup immediately on click
                        if t == "trigger" and i >= 0:
                            self.trigger_popup     = True
                            self.trigger_popup_idx = i

                    elif self.tool in ("WALL_OUT","WALL_IN","BOOST"):
                        self._snapshot()
                        self.drawing = True
                        self.drag_s  = (wx, wy)

                    elif self.tool == "CHECKPOINT":
                        self._snapshot()
                        self.drawing = True
                        self.drag_s  = (wx, wy)

                    elif self.tool == "START":
                        self._snapshot()
                        self.start = [wx, wy]

                    elif self.tool == "DECO":
                        self._snapshot()
                        self.decos.append({"type":"circle","x":wx,"y":wy,
                                           "r":30,"color":list(GRASS_PRESETS[self.gr_i][0])})
                    elif self.tool == "TRIGGER":
                        self._snapshot()
                        self.drawing = True
                        self.drag_s  = (wx, wy)
                    elif self.tool == "TEXT":
                        self._snapshot()
                        self.texts.append({"x":wx,"y":wy,"text":"Text","size":24,"color":[255,255,255]})
                        self.editing_text  = True
                        self.edit_text_idx = len(self.texts)-1
                        self.sel_type="text"; self.sel_idx=self.edit_text_idx

            # ── mouse up ──────────────────────────────────────────────────────
            if ev.type == pygame.MOUSEBUTTONUP:
                if ev.button in (2, 3):
                    self.pan = False
                if ev.button == 1 and self.drawing:
                    wx, wy = self._smouse(mouse)
                    x1, y1 = self.drag_s
                    x, y   = min(x1,wx), min(y1,wy)
                    w, h   = abs(wx-x1), abs(wy-y1)
                    if w >= 8 and h >= 8:
                        if self.tool in ("WALL_OUT","WALL_IN"):
                            self.walls.append({"x":x,"y":y,"w":w,"h":h,
                                               "is_outer": self.tool=="WALL_OUT"})
                        elif self.tool == "BOOST":
                            self.boosts.append({"x":x,"y":y,"w":w,"h":h})
                        elif self.tool == "CHECKPOINT":
                            self.checkpoints.append([x, y, w, h])
                        elif self.tool == "TRIGGER":
                            default_v=TRIGGER_DESC.get(self.sel_trigger_kind,("","",1.0,0,0))[2]
                            self.triggers.append({"x":x,"y":y,"w":w,"h":h,"kind":self.sel_trigger_kind,"value":default_v})
                            # Auto-open popup to pick kind and value
                            self.sel_type="trigger"; self.sel_idx=len(self.triggers)-1
                            self.trigger_popup=True; self.trigger_popup_idx=len(self.triggers)-1
                            self._tpop_input=f"{default_v:.2f}"; self._tpop_input_focus=False
                    self.drawing = False; self.drag_s = None

            # ── pan ───────────────────────────────────────────────────────────
            if ev.type == pygame.MOUSEMOTION and self.pan and self.pan0:
                dx = (mouse[0]-self.pan0[0]) / self.zoom
                dy = (mouse[1]-self.pan0[1]) / self.zoom
                self.cx = self.pcam[0] - dx
                self.cy = self.pcam[1] - dy

        return None

    # ── sidebar click ─────────────────────────────────────────────────────────

    def _sidebar_click(self, mouse, ev):
        if ev.type != pygame.MOUSEBUTTONDOWN or ev.button != 1:
            return
        for key, r in self._sr.items():
            if not r.collidepoint(mouse): continue
            if key.startswith("tool_"):   self.tool=key[5:]; self._clear_sel()
            elif key.startswith("bg_"):   self.bg_i=int(key[3:])
            elif key.startswith("gr_"):   self.gr_i=int(key[3:])
            elif key.startswith("tr_"):   self.tr_i=int(key[3:])
            elif key.startswith("cu_"):   self.cu_i=int(key[3:])
            elif key=="lap_dec":          self.lap_count=max(1,self.lap_count-1)
            elif key=="lap_inc":          self.lap_count=min(10,self.lap_count+1)
            elif key=="name":             self.editing_name=True
            elif key=="grid_tog":         self.grid_on=not self.grid_on
            elif key=="grid_dec":         self.grid_size=max(5,self.grid_size-5)
            elif key=="grid_inc":         self.grid_size=min(100,self.grid_size+5)
            elif key=="save":             self._save()
            elif key=="new":              self._snapshot(); self._new_level(); self.notify("New level")
            elif key=="load":             self._open_load_dialog()
            elif key=="back":             return "menu"
            elif key=="del_sel":
                if self.sel_type: self._snapshot(); self._delete_sel()
            elif key=="clr_cp":
                self._snapshot(); self.checkpoints.clear(); self.notify("Checkpoints cleared")
            return

    def _open_load_dialog(self):
        """Simple in-editor level picker."""
        import os
        files = [f for f in sorted(os.listdir(LEVELS_DIR)) if f.endswith(".lev")] \
                if os.path.isdir(LEVELS_DIR) else []
        if not files:
            self.notify("No .lev files found"); return

        # Draw a small overlay picker
        clock = pygame.time.Clock()
        sel   = 0
        while True:
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT:   pygame.quit(); sys.exit()
                if ev.type == pygame.KEYDOWN:
                    if ev.key==pygame.K_ESCAPE: return
                    if ev.key==pygame.K_UP:     sel=max(0,sel-1)
                    if ev.key==pygame.K_DOWN:   sel=min(len(files)-1,sel+1)
                    if ev.key==pygame.K_RETURN:
                        self._load(os.path.join(LEVELS_DIR,files[sel])); return
                if ev.type==pygame.MOUSEBUTTONDOWN and ev.button==1:
                    mx,my=pygame.mouse.get_pos()
                    for i in range(len(files)):
                        ry=200+i*36
                        if 200<=mx<=700 and ry<=my<=ry+32:
                            sel=i
                if ev.type==pygame.MOUSEBUTTONDOWN and ev.button==1:
                    mx,my=pygame.mouse.get_pos()
                    for i in range(len(files)):
                        ry=200+i*36
                        if 200<=mx<=700 and ry<=my<=ry+32:
                            if sel==i: self._load(os.path.join(LEVELS_DIR,files[i])); return
                            sel=i

            sw,sh=self.sw,self.sh
            ov=pygame.Surface((sw,sh),pygame.SRCALPHA); ov.fill((0,0,0,175))
            self.screen.blit(ov,(0,0))
            bx,by,bw,bh=180,150,440,len(files)*36+80
            pygame.draw.rect(self.screen,(22,28,42),(bx,by,bw,bh),border_radius=10)
            pygame.draw.rect(self.screen,(70,80,105),(bx,by,bw,bh),2,border_radius=10)
            t=self.fT.render("LOAD LEVEL",True,(205,192,92))
            self.screen.blit(t,(bx+bw//2-t.get_width()//2,by+12))
            for i,fn in enumerate(files):
                ry=200+i*36
                s=(i==sel)
                pygame.draw.rect(self.screen,(48,62,48) if s else (28,34,48),(200,ry,400,32),border_radius=6)
                pygame.draw.rect(self.screen,(130,200,90) if s else (55,65,90),(200,ry,400,32),1 if not s else 2,border_radius=6)
                ft=self.fm.render(fn,True,(240,235,190) if s else (165,165,165))
                self.screen.blit(ft,(210,ry+7))
            hint=self.ft.render("↑↓ navigate   ENTER load   ESC cancel",True,(110,115,138))
            self.screen.blit(hint,(sw//2-hint.get_width()//2,by+bh-22))
            pygame.display.flip(); clock.tick(60)

    # ── draw ──────────────────────────────────────────────────────────────────

    def _draw(self, mouse):
        sw,sh = self.sw, self.sh
        cw    = sw - SIDE_W         # canvas width

        # Background
        self.screen.fill(tuple(BG_PRESETS[self.bg_i][0]))

        # Grid
        if self.grid_on:
            self._draw_grid(cw, sh)

        # World objects
        self._draw_world(mouse, cw, sh)

        # Sidebar
        self._draw_sidebar(mouse)

        # Canvas border
        pygame.draw.line(self.screen,(55,60,80),(cw,0),(cw,sh),2)

        # Notification
        if self.notif_t > 0:
            a  = min(255, int(self.notif_t*160))
            nt = self.fT.render(self.notif, True, (88,240,120))
            nt.set_alpha(a)
            self.screen.blit(nt,(cw//2-nt.get_width()//2, sh//2-20))

        # Trigger popup (drawn last so it appears on top)
        self._draw_trigger_popup(mouse)

        # ── Top-left toolbar ─────────────────────────────────────────────────
        self._draw_toolbar(mouse)

        # Bottom status bar
        wx,wy = s2w(mouse[0],mouse[1],self.cx,self.cy,self.zoom,cw,sh)
        swx,swy = self._snap(wx),self._snap(wy)
        status = (f"Zoom {self.zoom:.2f}x   World ({swx:.0f},{swy:.0f})   "
                  f"Grid {'ON '+str(self.grid_size)+'px' if self.grid_on else 'OFF'}   "
                  f"Walls:{len(self.walls)}  CPs:{len(self.checkpoints)}  "
                  f"Boosts:{len(self.boosts)}")
        st = self.ft.render(status, True, (72,76,95))
        self.screen.blit(st,(6, sh-16))

    def _draw_grid(self, cw, sh):
        gsurf = pygame.Surface((cw,sh), pygame.SRCALPHA)
        gs    = max(4, int(self.grid_size * self.zoom))
        # offset so grid moves with camera
        ox = int(-self.cx * self.zoom + cw*0.5) % gs
        oy = int(-self.cy * self.zoom + sh*0.5) % gs
        alpha = max(18, min(55, int(self.zoom*30)))
        for x in range(-gs, cw+gs, gs):
            pygame.draw.line(gsurf,(100,110,140,alpha),(x+ox,0),(x+ox,sh))
        for y in range(-gs, sh+gs, gs):
            pygame.draw.line(gsurf,(100,110,140,alpha),(0,y+oy),(cw,y+oy))
        self.screen.blit(gsurf,(0,0))

    def _draw_world(self, mouse, cw, sh):
        tc = tuple(TRACK_PRESETS[self.tr_i][0])
        gc = tuple(GRASS_PRESETS[self.gr_i][0])
        cc = tuple(CURB_PRESETS[self.cu_i][0])

        # Walls
        for i,w in enumerate(self.walls):
            sx,sy = w2s(w["x"],w["y"],self.cx,self.cy,self.zoom,cw,sh)
            pw = max(1,int(w["w"]*self.zoom)); ph = max(1,int(w["h"]*self.zoom))
            pygame.draw.rect(self.screen,tc,(int(sx),int(sy),pw,ph))
            # border colour by type
            border = cc if w["is_outer"] else (55,195,55)
            thick  = 3 if (self.sel_type=="wall" and self.sel_idx==i) else \
                     max(1, int(3*self.zoom))
            sel_col= (255,255,100) if (self.sel_type=="wall" and self.sel_idx==i) else border
            pygame.draw.rect(self.screen,sel_col,(int(sx),int(sy),pw,ph),thick)
            # label outer/inner at high zoom
            if self.zoom > 1.5:
                lbl=self.ft.render("OUT" if w["is_outer"] else "IN",True,(200,200,200))
                self.screen.blit(lbl,(int(sx)+2,int(sy)+2))

        # Decorations
        for i,d in enumerate(self.decos):
            sx,sy=w2s(d["x"],d["y"],self.cx,self.cy,self.zoom,cw,sh)
            r=max(2,int(d.get("r",30)*self.zoom))
            col=tuple(d.get("color",[40,90,50]))
            pygame.draw.circle(self.screen,col,(int(sx),int(sy)),r)
            edge=(255,255,100) if(self.sel_type=="deco" and self.sel_idx==i) else (88,210,170)
            pygame.draw.circle(self.screen,edge,(int(sx),int(sy)),r,2)

        # Boost pads
        for i,b in enumerate(self.boosts):
            sx,sy=w2s(b["x"],b["y"],self.cx,self.cy,self.zoom,cw,sh)
            pw=max(1,int(b["w"]*self.zoom)); ph=max(1,int(b["h"]*self.zoom))
            s=pygame.Surface((pw+4,ph+4),pygame.SRCALPHA)
            pygame.draw.rect(s,(255,210,0,155),(2,2,pw,ph),border_radius=4)
            ec=(255,255,100) if(self.sel_type=="boost" and self.sel_idx==i) else (255,255,120,200)
            pygame.draw.rect(s,ec,(2,2,pw,ph),2,border_radius=4)
            self.screen.blit(s,(int(sx)-2,int(sy)-2))
            if pw>20 and ph>10:
                bl=self.ft.render("BOOST",True,(200,160,0))
                self.screen.blit(bl,(int(sx)+2,int(sy)+2))

        # Triggers
        for i, tr in enumerate(self.triggers):
            sx2,sy2 = w2s(tr["x"],tr["y"],self.cx,self.cy,self.zoom,cw,sh)
            pw2=max(2,int(tr["w"]*self.zoom)); ph2=max(2,int(tr["h"]*self.zoom))
            kind=tr.get("kind","speed_up")
            col=TRIGGER_COLORS.get(kind,(200,200,200))
            sel=(self.sel_type=="trigger" and self.sel_idx==i)
            t=pygame.time.get_ticks()
            a=int(90+70*abs(math.sin(t*0.004)))
            s=pygame.Surface((pw2+4,ph2+4),pygame.SRCALPHA)
            pygame.draw.rect(s,(*col,a),(2,2,pw2,ph2),border_radius=5)
            ec=(255,255,100,255) if sel else (*col,210)
            pygame.draw.rect(s,ec,(2,2,pw2,ph2),3 if sel else 2,border_radius=5)
            self.screen.blit(s,(int(sx2)-2,int(sy2)-2))
            if pw2>18 and ph2>10:
                lbl=TRIGGER_LABELS.get(kind,kind)
                ft2=pygame.font.SysFont("consolas",max(8,int(10*self.zoom)),bold=True)
                lt=ft2.render(lbl,True,(255,255,255))
                self.screen.blit(lt,(int(sx2)+pw2//2-lt.get_width()//2,
                                      int(sy2)+ph2//2-lt.get_height()//2))

        # Texts
        for i, tx in enumerate(self.texts):
            sx2,sy2=w2s(tx["x"],tx["y"],self.cx,self.cy,self.zoom,cw,sh)
            sel=(self.sel_type=="text" and self.sel_idx==i)
            editing=(self.editing_text and self.edit_text_idx==i)
            fsz=max(8,int(tx.get("size",24)*self.zoom))
            tf=pygame.font.SysFont("consolas",fsz,bold=True)
            col=tuple(tx.get("color",[255,255,255]))
            disp=tx["text"]+("_" if editing else "")
            # Shadow
            sh2=tf.render(disp,True,(0,0,0)); self.screen.blit(sh2,(int(sx2)+2,int(sy2)+2))
            img=tf.render(disp,True,col); self.screen.blit(img,(int(sx2),int(sy2)))
            if sel:
                pygame.draw.rect(self.screen,(255,255,100),
                                  (int(sx2)-3,int(sy2)-3,img.get_width()+6,img.get_height()+6),2,border_radius=3)

        # Checkpoints (resizable rects)
        for i, cp in enumerate(self.checkpoints):
            # Support [x,y] legacy and [x,y,w,h]
            if len(cp) == 2:
                cpx, cpy, cpw, cph = cp[0]-60, cp[1]-60, 120, 120
            else:
                cpx, cpy, cpw, cph = cp[0], cp[1], cp[2], cp[3]
            sx, sy = w2s(cpx, cpy, self.cx, self.cy, self.zoom, cw, sh)
            pw = max(4, int(cpw * self.zoom))
            ph = max(4, int(cph * self.zoom))
            sel = (self.sel_type == "cp" and self.sel_idx == i)
            s = pygame.Surface((pw + 8, ph + 8), pygame.SRCALPHA)
            pygame.draw.rect(s, (80, 165, 255, 55), (4, 4, pw, ph), border_radius=4)
            ec = (255, 255, 100, 255) if sel else (80, 165, 255, 200)
            pygame.draw.rect(s, ec, (4, 4, pw, ph), 3 if sel else 2, border_radius=4)
            self.screen.blit(s, (int(sx) - 4, int(sy) - 4))
            # Number label centred in rect
            num = self.fB.render(str(i + 1), True, (200, 225, 255))
            self.screen.blit(num, (int(sx) + pw//2 - num.get_width()//2,
                                    int(sy) + ph//2 - num.get_height()//2))
            # Arrow line to next checkpoint
            if i + 1 < len(self.checkpoints):
                ncp = self.checkpoints[i + 1]
                if len(ncp) == 2:
                    ncx, ncy = ncp[0], ncp[1]
                else:
                    ncx, ncy = ncp[0] + ncp[2]*0.5, ncp[1] + ncp[3]*0.5
                nx2, ny2 = w2s(ncx, ncy, self.cx, self.cy, self.zoom, cw, sh)
                ccx = int(sx) + pw // 2; ccy = int(sy) + ph // 2
                pygame.draw.line(self.screen, (60, 100, 180), (ccx, ccy), (int(nx2), int(ny2)), 1)

        # Start
        sx,sy=w2s(self.start[0],self.start[1],self.cx,self.cy,self.zoom,cw,sh)
        r2=max(8,int(18*self.zoom))
        sel=(self.sel_type=="start")
        pygame.draw.circle(self.screen,(255,85,235),(int(sx),int(sy)),r2)
        pygame.draw.circle(self.screen,(255,255,100) if sel else (255,200,255),(int(sx),int(sy)),r2,2)
        # Arrow for angle
        ar=math.radians(self.start_angle)
        ax=int(sx + math.sin(ar)*r2*1.8); ay=int(sy - math.cos(ar)*r2*1.8)
        pygame.draw.line(self.screen,(255,255,100),(int(sx),int(sy)),(ax,ay),3)
        st=self.ft.render("START",True,(255,85,235))
        self.screen.blit(st,(int(sx)-st.get_width()//2,int(sy)-r2-16))

        # Live drag rectangle preview
        if self.drawing and self.drag_s:
            wx,wy=self._smouse(mouse)
            x1,y1=self.drag_s
            px_s=min(x1,wx); py_s=min(y1,wy)
            pw2=abs(wx-x1); ph2=abs(wy-y1)
            psx,psy=w2s(px_s,py_s,self.cx,self.cy,self.zoom,cw,sh)
            spw=int(pw2*self.zoom); sph=int(ph2*self.zoom)
            if spw>0 and sph>0:
                ov=pygame.Surface((spw,sph),pygame.SRCALPHA)
                trig_col=TRIGGER_COLORS.get(self.sel_trigger_kind,(255,140,80))
                fc={"WALL_OUT":(215,55,55,70),"WALL_IN":(55,195,55,70),
                    "BOOST":(255,210,0,70),"CHECKPOINT":(80,165,255,60),
                    "TRIGGER":(*trig_col,60)}
                ov.fill(fc.get(self.tool,(200,200,200,55)))
                self.screen.blit(ov,(int(psx),int(psy)))
                ec={"WALL_OUT":(215,55,55),"WALL_IN":(55,195,55),
                    "BOOST":(255,210,0),"CHECKPOINT":(80,165,255),
                    "TRIGGER":trig_col}
                pygame.draw.rect(self.screen,ec.get(self.tool,(200,200,200)),
                                 (int(psx),int(psy),spw,sph),2,border_radius=4)
                # Show trigger kind label in preview
                if self.tool=="TRIGGER" and spw>20 and sph>10:
                    lk=TRIGGER_LABELS.get(self.sel_trigger_kind,"TRIGGER")
                    lf=pygame.font.SysFont("consolas",11,bold=True)
                    lt=lf.render(lk,True,(255,255,255))
                    self.screen.blit(lt,(int(psx)+spw//2-lt.get_width()//2,
                                         int(psy)+sph//2-lt.get_height()//2))
                # Show dimensions
                dim=self.ft.render(f"{int(pw2)}×{int(ph2)}",True,(240,240,200))
                self.screen.blit(dim,(int(psx)+4,int(psy)+4))

        # Hover highlight
        if self.tool=="SELECT":
            wx,wy=s2w(mouse[0],mouse[1],self.cx,self.cy,self.zoom,cw,sh)
            ht,hi=self._hit_test(wx,wy)
            if ht and not(ht==self.sel_type and hi==self.sel_idx):
                if ht=="wall":
                    w=self.walls[hi]; hsx,hsy=w2s(w["x"],w["y"],self.cx,self.cy,self.zoom,cw,sh)
                    hw2=max(1,int(w["w"]*self.zoom)); hh2=max(1,int(w["h"]*self.zoom))
                    hs=pygame.Surface((hw2,hh2),pygame.SRCALPHA); hs.fill((255,255,255,35))
                    self.screen.blit(hs,(int(hsx),int(hsy)))

    def _draw_toolbar(self, mouse):
        """Top-left floating toolbar: Save, Load, New, Clear, Undo, Redo."""
        btns = [
            ("save", "💾 Save",  (42,90,42),  (62,138,62)),
            ("load", "📂 Load",  (38,48,82),  (58,72,125)),
            ("new",  "✚ New",   (80,38,38),  (125,58,58)),
            ("clr",  "🗑 Clear", (90,50,30),  (140,78,45)),
            ("undo", "↩ Undo",  (38,42,68),  (58,65,108)),
            ("redo", "↪ Redo",  (38,42,68),  (58,65,108)),
        ]
        x=6; y=6; h=26; gap=4; tb={}
        fnt=self.fm
        for key,lbl,col,hcol in btns:
            # Render label to get width
            img=fnt.render(lbl,True,(235,235,235))
            w=img.get_width()+16
            r=pygame.Rect(x,y,w,h)
            hov=r.collidepoint(mouse)
            # Shadow
            pygame.draw.rect(self.screen,(0,0,0,80),r.move(2,2),border_radius=5)
            pygame.draw.rect(self.screen,hcol if hov else col,r,border_radius=5)
            pygame.draw.rect(self.screen,(120,130,160),r,1,border_radius=5)
            self.screen.blit(img,(x+8,y+h//2-img.get_height()//2))
            tb[key]=r; x+=w+gap
        self._tb_rects=tb

    def _handle_toolbar_click(self, mouse, evs):
        """Returns 'menu' if back was clicked, else None."""
        click=any(e.type==pygame.MOUSEBUTTONDOWN and e.button==1 for e in evs)
        if not click: return None
        for key,r in self._tb_rects.items():
            if r.collidepoint(mouse):
                if key=="save": self._save()
                elif key=="load": self._open_load_dialog()
                elif key=="new": self._snapshot(); self._new_level(); self.notify("New level")
                elif key=="clr": self._snapshot(); self.walls.clear(); self.boosts.clear(); self.checkpoints.clear(); self.decos.clear(); self.triggers.clear(); self.texts.clear(); self.notify("Cleared!")
                elif key=="undo": self._undo()
                elif key=="redo": self._redo()
                return None
        return None

    def _draw_trigger_popup(self, mouse):
        """Floating popup: top section = kind picker, bottom = value input."""
        if not self.trigger_popup or self.trigger_popup_idx < 0:
            self._tpop_rects = {}
            return
        if self.trigger_popup_idx >= len(self.triggers):
            self.trigger_popup = False; self._tpop_rects={}; return

        tr   = self.triggers[self.trigger_popup_idx]
        cw   = self.sw - SIDE_W
        sx0, sy0 = w2s(tr["x"]+tr["w"], tr["y"], self.cx, self.cy, self.zoom, cw, self.sh)

        PW    = 210
        K_ROW = 28   # height per kind row
        # ── dimensions ───────────────────────────────────────────────────────
        kind_h   = len(TRIGGER_KINDS) * K_ROW + 28   # title + rows
        val_h    = 88                                  # value section
        TOTAL_H  = kind_h + val_h + 8

        px = int(min(sx0 + 10, cw - PW - 4))
        py = int(max(4, min(sy0, self.sh - TOTAL_H - 4)))

        # ── panel background ─────────────────────────────────────────────────
        panel = pygame.Surface((PW, TOTAL_H), pygame.SRCALPHA)
        panel.fill((12, 14, 24, 242))
        pygame.draw.rect(panel,(78,86,112,225),(0,0,PW,TOTAL_H),2,border_radius=10)
        self.screen.blit(panel,(px,py))

        # Connector line
        tcx = int((tr["x"]+tr["w"]*0.5-self.cx)*self.zoom + cw*0.5)
        tcy = int((tr["y"]+tr["h"]*0.5-self.cy)*self.zoom + self.sh*0.5)
        pygame.draw.line(self.screen,(90,100,138),(tcx,tcy),(px,py+TOTAL_H//2),1)

        tf  = pygame.font.SysFont("consolas",13,bold=True)
        sf  = pygame.font.SysFont("consolas",11)
        bdf = pygame.font.SysFont("consolas",11,bold=True)

        # ══ SECTION 1: Kind picker ════════════════════════════════════════════
        title = tf.render("▸ TRIGGER TYPE", True, (200,195,130))
        self.screen.blit(title,(px+PW//2-title.get_width()//2, py+6))

        current_kind = tr.get("kind","speed")
        rects = {}
        for i, kind in enumerate(TRIGGER_KINDS):
            ry = py + 26 + i * K_ROW
            r  = pygame.Rect(px+5, ry, PW-10, K_ROW-3)
            sel = (kind == current_kind)
            hov = r.collidepoint(mouse)
            col = TRIGGER_COLORS.get(kind,(200,200,200))
            cr2,cg2,cb2 = col
            row_r = pygame.Rect(px+5, ry, PW-10, K_ROW-3)

            if sel:
                bg_s = pygame.Surface((row_r.w, row_r.h), pygame.SRCALPHA)
                bg_s.fill((cr2,cg2,cb2,50))
                self.screen.blit(bg_s,(row_r.x,row_r.y))
            elif hov:
                bg_s = pygame.Surface((row_r.w, row_r.h), pygame.SRCALPHA)
                bg_s.fill((255,255,255,14))
                self.screen.blit(bg_s,(row_r.x,row_r.y))

            pygame.draw.rect(self.screen, col if sel else ((160,168,200) if hov else (52,58,80)),
                             row_r, 2 if sel else 1, border_radius=5)
            pygame.draw.circle(self.screen, col, (px+16, ry+K_ROW//2-1), 5)
            if sel: pygame.draw.circle(self.screen,(255,255,255),(px+16,ry+K_ROW//2-1),2)
            lbl = tf.render(TRIGGER_LABELS.get(kind,kind), True,
                            (255,255,255) if sel else ((200,204,225) if hov else (148,152,175)))
            self.screen.blit(lbl,(px+26, ry+K_ROW//2-lbl.get_height()//2))
            v_disp = tr.get("value", TRIGGER_DESC.get(kind,("","",1.0,0,0))[2])
            v_str  = f"×{v_disp:.2f}"
            vt = sf.render(v_str, True, col if sel else (100,105,130))
            self.screen.blit(vt,(px+PW-vt.get_width()-8, ry+K_ROW//2-vt.get_height()//2))
            rects[kind] = row_r

        # ══ SECTION 2: Value input (below kind picker) ════════════════════════
        vy   = py + kind_h
        sep_y= vy
        pygame.draw.line(self.screen,(60,68,92),(px+8,sep_y),(px+PW-8,sep_y),1)
        vy  += 5

        kind_now = tr.get("kind","speed")
        desc_info= TRIGGER_DESC.get(kind_now,("Value","",1.0,0,99))
        disp_lbl, disp_hint, default_v, vmin, vmax = desc_info

        # Section title
        sec_t = tf.render(f"▸ {disp_lbl.upper()}", True, (200,195,130))
        self.screen.blit(sec_t,(px+PW//2-sec_t.get_width()//2, vy)); vy+=18

        # Hint
        hint_t= sf.render(disp_hint, True, (100,106,130))
        self.screen.blit(hint_t,(px+PW//2-hint_t.get_width()//2, vy)); vy+=14

        # Text input box
        cur_v  = tr.get("value", default_v)
        inp_r  = pygame.Rect(px+8, vy, PW-56, 24)
        focused= self._tpop_input_focus
        box_col= (50,68,50) if focused else (30,34,50)
        brd_col= (90,200,90) if focused else (60,68,92)
        pygame.draw.rect(self.screen, box_col, inp_r, border_radius=5)
        pygame.draw.rect(self.screen, brd_col, inp_r, 2, border_radius=5)
        disp_val = (self._tpop_input+("_" if focused else "")) if focused else f"{cur_v:.2f}"
        vt2 = tf.render(disp_val, True, (220,230,200) if focused else (185,190,210))
        self.screen.blit(vt2,(inp_r.x+6, inp_r.y+inp_r.h//2-vt2.get_height()//2))

        # SET button
        set_r = pygame.Rect(px+PW-44, vy, 36, 24)
        set_hov = set_r.collidepoint(mouse)
        pygame.draw.rect(self.screen,(55,105,55) if not set_hov else (80,160,80),set_r,border_radius=5)
        pygame.draw.rect(self.screen,(90,180,90),set_r,2,border_radius=5)
        st2 = bdf.render("SET",True,(230,240,225))
        self.screen.blit(st2,st2.get_rect(center=set_r.center))
        vy+=28

        # Close hint
        ht = sf.render("ESC or click outside to close", True,(65,70,95))
        self.screen.blit(ht,(px+PW//2-ht.get_width()//2, py+TOTAL_H-13))

        # Register hit rects
        rects["_input"] = inp_r
        rects["_set"]   = set_r
        self._tpop_rects = rects


    def _draw_sidebar(self, mouse):
        sw, sh = self.sw, self.sh
        sx = sw - SIDE_W
        sr = {}

        # Draw sidebar panel
        panel = pygame.Surface((SIDE_W, sh), pygame.SRCALPHA)
        panel.fill((16, 18, 28, 242))
        pygame.draw.line(panel, (55, 62, 88, 255), (0, 0), (0, sh), 2)
        self.screen.blit(panel, (sx, 0))

        # We render all sidebar content onto a tall off-screen surface,
        # then blit only the visible portion. This means nothing ever clips.
        CONTENT_H = 1400
        surf = pygame.Surface((SIDE_W, CONTENT_H), pygame.SRCALPHA)

        def txt(s, color, font=None):
            return (font or self.ft).render(s, True, color)

        y = 6
        PADL = 4  # left padding inside surf

        # Title
        t = self.fT.render("LEVEL EDITOR", True, (205, 192, 92))
        surf.blit(t, (SIDE_W // 2 - t.get_width() // 2, y)); y += 26

        # Level name field
        nr = pygame.Rect(PADL, y, SIDE_W - 8, 22)
        col = (55, 78, 55) if self.editing_name else (30, 35, 52)
        pygame.draw.rect(surf, col, nr, border_radius=5)
        pygame.draw.rect(surf, (80, 110, 80) if self.editing_name else (55, 62, 85), nr, 1, border_radius=5)
        nt = self.fm.render((self.level_name + ("_" if self.editing_name else ""))[:24], True, (220, 215, 168))
        surf.blit(nt, (PADL + 3, y + 3))
        sr["name"] = pygame.Rect(sx + PADL, y, SIDE_W - 8, 22); y += 28

        # Tools
        surf.blit(txt("TOOLS  (1-7)", (118, 125, 148)), (PADL, y)); y += 13
        for i, tool in enumerate(TOOLS):
            sel = (tool == self.tool)
            r = pygame.Rect(PADL, y, SIDE_W - 7, 22)
            hv = pygame.Rect(sx + PADL, y, SIDE_W - 7, 22).collidepoint(mouse)
            bg = (42, 58, 42) if sel else ((34, 40, 56) if hv else (24, 28, 42))
            pygame.draw.rect(surf, bg, r, border_radius=5)
            border = TOOL_COL[tool] if sel else (48, 54, 72)
            pygame.draw.rect(surf, border, r, 2 if sel else 1, border_radius=5)
            pygame.draw.circle(surf, TOOL_COL[tool], (PADL + 9, y + 11), 4)
            tt = self.fm.render(f"{i+1} {TOOL_LABEL[tool]}", True, (218, 212, 195) if sel else (145, 148, 162))
            surf.blit(tt, (PADL + 18, y + 3))
            sr[f"tool_{tool}"] = pygame.Rect(sx + PADL, y, SIDE_W - 7, 22); y += 24

        y += 3

        # Colour preset helper
        def preset_block(label, presets, idx_attr, prefix):
            nonlocal y
            surf.blit(txt(label, (118, 125, 148)), (PADL, y)); y += 13
            cols = 2; pw = (SIDE_W - 12) // cols; ph = 16; gap = 2
            for j, (col2, name2) in enumerate(presets):
                c = j % cols; row = j // cols
                r2 = pygame.Rect(PADL + c * (pw + gap), y + row * (ph + gap), pw, ph)
                sel2 = (getattr(self, idx_attr) == j)
                hv2 = pygame.Rect(sx + r2.x, r2.y, pw, ph).collidepoint(mouse)
                bg2 = tuple(col2) if sel2 else ((38, 44, 62) if hv2 else (24, 28, 42))
                pygame.draw.rect(surf, bg2, r2, border_radius=3)
                pygame.draw.rect(surf, (218, 212, 165) if sel2 else (50, 56, 75), r2, 1 if not sel2 else 2, border_radius=3)
                surf.blit(self.ft.render(name2, True, (228, 222, 195) if sel2 else (132, 135, 152)), (r2.x + 3, r2.y + 2))
                sr[f"{prefix}{j}"] = pygame.Rect(sx + r2.x, r2.y, pw, ph)
            rows = math.ceil(len(presets) / cols)
            y += rows * (ph + gap) + 3

        preset_block("BG",         BG_PRESETS,    "bg_i",  "bg_")
        preset_block("GRASS/FILL", GRASS_PRESETS, "gr_i",  "gr_")
        preset_block("TRACK",      TRACK_PRESETS, "tr_i",  "tr_")
        preset_block("CURBS",      CURB_PRESETS,  "cu_i",  "cu_")

        y += 2
        # Laps
        surf.blit(txt("LAPS", (118, 125, 148)), (PADL, y)); y += 13
        for key, label2, rx in [("lap_dec", "–", PADL), ("lap_inc", "+", PADL + 42)]:
            r3 = pygame.Rect(rx, y, 26, 22)
            hv3 = pygame.Rect(sx + rx, y, 26, 22).collidepoint(mouse)
            pygame.draw.rect(surf, (78, 78, 118) if hv3 else (52, 52, 78), r3, border_radius=5)
            pygame.draw.rect(surf, (88, 92, 118), r3, 1, border_radius=5)
            bt = self.fB.render(label2, True, (218, 218, 218))
            surf.blit(bt, bt.get_rect(center=r3.center))
            sr[key] = pygame.Rect(sx + rx, y, 26, 22)
        lv = self.fB.render(str(self.lap_count), True, (218, 208, 158))
        surf.blit(lv, (PADL + 76, y + 3)); y += 28

        # Grid
        surf.blit(txt("GRID", (118, 125, 148)), (PADL, y)); y += 13
        tgr = pygame.Rect(PADL, y, 48, 20)
        hv4 = pygame.Rect(sx + PADL, y, 48, 20).collidepoint(mouse)
        pygame.draw.rect(surf, (42, 68, 42) if self.grid_on else (38, 28, 28), tgr, border_radius=5)
        pygame.draw.rect(surf, (88, 128, 88) if self.grid_on else (108, 68, 68), tgr, 1, border_radius=5)
        gt = self.fm.render("ON" if self.grid_on else "OFF", True, (88, 228, 88) if self.grid_on else (228, 88, 88))
        surf.blit(gt, gt.get_rect(center=tgr.center))
        sr["grid_tog"] = pygame.Rect(sx + PADL, y, 48, 20)
        for key, label2, rx in [("grid_dec", "–", PADL + 54), ("grid_inc", "+", PADL + 84)]:
            r5 = pygame.Rect(rx, y, 24, 20)
            hv5 = pygame.Rect(sx + rx, y, 24, 20).collidepoint(mouse)
            pygame.draw.rect(surf, (78, 78, 118) if hv5 else (52, 52, 78), r5, border_radius=4)
            bt = self.fm.render(label2, True, (218, 218, 218))
            surf.blit(bt, bt.get_rect(center=r5.center))
            sr[key] = pygame.Rect(sx + rx, y, 24, 20)
        surf.blit(self.ft.render(f"{self.grid_size}px", True, (155, 155, 175)), (PADL + 114, y + 4)); y += 26

        # Selection
        if self.sel_type:
            surf.blit(txt(f"Sel: {self.sel_type} #{self.sel_idx}", (228, 228, 128)), (PADL, y)); y += 13
            dr = pygame.Rect(PADL, y, SIDE_W - 8, 20)
            hv6 = pygame.Rect(sx + PADL, y, SIDE_W - 8, 20).collidepoint(mouse)
            pygame.draw.rect(surf, (155, 55, 55) if hv6 else (108, 38, 38), dr, border_radius=5)
            pygame.draw.rect(surf, (185, 80, 80), dr, 1, border_radius=5)
            dt = self.fm.render("DELETE  (Del)", True, (238, 198, 198))
            surf.blit(dt, dt.get_rect(center=dr.center))
            sr["del_sel"] = pygame.Rect(sx + PADL, y, SIDE_W - 8, 20); y += 24
        else:
            y += 4

        # Counts
        for line in [f"Walls:{len(self.walls)}  Boosts:{len(self.boosts)}",
                     f"CPs:{len(self.checkpoints)}  Decos:{len(self.decos)}",
                     f"Triggers:{len(self.triggers)}  Texts:{len(self.texts)}"]:
            surf.blit(self.ft.render(line, True, (108, 112, 135)), (PADL, y)); y += 13
        cr2 = pygame.Rect(PADL, y, SIDE_W - 8, 18)
        hvc = pygame.Rect(sx + PADL, y, SIDE_W - 8, 18).collidepoint(mouse)
        pygame.draw.rect(surf, (85, 65, 38) if hvc else (55, 42, 28), cr2, border_radius=4)
        pygame.draw.rect(surf, (120, 95, 55), cr2, 1, border_radius=4)
        surf.blit(self.ft.render("Clear Checkpoints", True, (198, 185, 148)), self.ft.render("Clear Checkpoints", True, (198, 185, 148)).get_rect(center=cr2.center))
        sr["clr_cp"] = pygame.Rect(sx + PADL, y, SIDE_W - 8, 18); y += 22

        y += 2
        # Trigger info
        if self.sel_type == "trigger" and self.sel_idx >= 0 and self.sel_idx < len(self.triggers):
            tr2=self.triggers[self.sel_idx]
            kind =tr2.get("kind","speed"); col_k=TRIGGER_COLORS.get(kind,(200,200,200))
            v2   =tr2.get("value",TRIGGER_DESC.get(kind,("","",1.0,0,0))[2])
            v_str=f"{v2:.0f} km/h" if kind=="speed" else f"×{v2:.2f}"
            surf.blit(self.ft.render("TRIGGER",True,(118,125,148)),(PADL,y)); y+=13
            kr=pygame.Rect(PADL,y,SIDE_W-8,22)
            bg_s=pygame.Surface((kr.w,kr.h),pygame.SRCALPHA); bg_s.fill((*col_k,50))
            surf.blit(bg_s,(PADL,y)); pygame.draw.rect(surf,col_k,kr,2,border_radius=5)
            kl=self.fm.render(f"{TRIGGER_LABELS.get(kind,kind)} = {v_str}",True,col_k)
            surf.blit(kl,(PADL+5,y+3)); y+=26
            surf.blit(self.ft.render("Click zone to edit",True,(88,92,115)),(PADL,y)); y+=14
        elif self.tool == "TRIGGER":
            surf.blit(self.ft.render("Drag to draw zone",True,(118,125,148)),(PADL,y)); y+=13
            surf.blit(self.ft.render("Click zone to set type+value",True,(88,92,115)),(PADL,y)); y+=14

        # Text editing hint
        if self.tool == "TEXT" or (self.sel_type=="text" and self.sel_idx>=0):
            hint_col = (228,228,128) if self.editing_text else (118,125,148)
            msg = "Typing..." if self.editing_text else "Enter=edit  Del=delete"
            surf.blit(self.ft.render(msg, True, hint_col), (PADL, y)); y+=14
            if self.sel_type=="text" and self.sel_idx>=0 and self.sel_idx<len(self.texts):
                tx=self.texts[self.sel_idx]
                surf.blit(self.ft.render(f'"{tx["text"]}"',True,(220,215,168)),(PADL,y)); y+=13

        y += 2
        # Action buttons
        for key, label2, col2, hcol2, bc2 in [
            ("save", "SAVE  Ctrl+S",   (42, 90, 42),  (62, 138, 62),  (132, 200, 132)),
            ("load", "LOAD LEVEL",     (38, 48, 82),  (58, 72, 125),  (120, 140, 198)),
            ("new",  "NEW LEVEL",      (80, 38, 38),  (125, 58, 58),  (200, 108, 108)),
            ("back", "◄ BACK TO MENU", (55, 40, 70),  (88, 62, 115),  (148, 110, 200)),
        ]:
            br2 = pygame.Rect(PADL, y, SIDE_W - 8, 26)
            hv7 = pygame.Rect(sx + PADL, y, SIDE_W - 8, 26).collidepoint(mouse)
            pygame.draw.rect(surf, hcol2 if hv7 else col2, br2, border_radius=7)
            pygame.draw.rect(surf, bc2, br2, 2, border_radius=7)
            bt = self.fB.render(label2, True, (235, 235, 235))
            surf.blit(bt, bt.get_rect(center=br2.center))
            sr[key] = pygame.Rect(sx + PADL, y, SIDE_W - 8, 26); y += 30

        # Shortcuts at bottom — always pinned to screen bottom
        hints = ["G=grid  [ ]=size", "Del=delete sel",
                 "Click trigger=edit type", "Enter=edit text",
                 "Ctrl+Z/Y undo/redo", "RMB=pan  Scroll=zoom", "ESC=close/menu"]
        hint_h = len(hints) * 13 + 4
        hy = sh - hint_h
        for h in hints:
            ht = self.ft.render(h, True, (68, 72, 92))
            self.screen.blit(ht, (sx + 4, hy)); hy += 13

        # Blit the content surface (clip to sidebar minus hint area)
        clip_h = sh - hint_h - 2
        clip_area = pygame.Rect(0, 0, SIDE_W, min(y, clip_h))
        self.screen.blit(surf, (sx, 0), area=clip_area)

        self._sr = sr