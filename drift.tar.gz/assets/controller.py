"""
controller.py  –  Drift Master Unified Input

Provides a single global InputState that merges keyboard + gamepad.
Import and use anywhere:

    from controller import get_input, pump_controller_events

Call pump_controller_events() once per frame BEFORE reading input.
Then call get_input() to get the current InputState.

────────────────────────────────────────────────────────
 GAMEPAD LAYOUT  (Xbox / generic mapping)
────────────────────────────────────────────────────────
  Left stick X        → steer
  Left stick Y        → (unused / reverse if held)
  Right trigger (RT)  → throttle / gas       (axis 5)
  Left trigger (LT)   → brake / reverse      (axis 4)
  A / Cross           → confirm / gas (alt)
  B / Circle          → back / handbrake
  X / Square          → handbrake (alt)
  Y / Triangle        → reset car
  Start               → pause
  D-pad up/down       → menu navigation
  D-pad left/right    → menu left/right
  Left shoulder (LB)  → menu back
  Right shoulder (RB) → menu confirm

Axis indices (SDL2 / pygame standard for XInput):
  0 = Left stick X
  1 = Left stick Y
  2 = Left trigger   (−1 released → +1 fully pressed, or 0→1 on some drivers)
  3 = Right stick X
  4 = Right stick Y
  5 = Right trigger  (same range as axis 2)

Hat (d-pad) index 0: (x, y) where y=1 is UP, y=-1 is DOWN
────────────────────────────────────────────────────────
"""

import pygame

# ── Tuning ────────────────────────────────────────────────────────────────────

DEADZONE        = 0.15    # ignore stick/trigger movement below this
TRIGGER_DEADZONE= 0.05    # triggers are more sensitive
STEER_POWER     = 1.4     # >1 makes steering more twitchy near centre

# Axis indices — change these if your controller maps differently
AXIS_STEER      = 0   # left stick X
AXIS_THROTTLE   = 5   # right trigger  (0→1 or −1→1 depending on driver)
AXIS_BRAKE      = 2   # left trigger   (same)
AXIS_LSTICK_Y   = 1   # left stick Y   (used for menu up/down)
AXIS_RSTICK_X   = 3   # right stick X  (used for menu left/right)

# Button indices (SDL2 XInput mapping)
BTN_A      = 0    # confirm / gas
BTN_B      = 1    # back / handbrake
BTN_X      = 2    # handbrake alt
BTN_Y      = 3    # reset
BTN_LB     = 4    # left shoulder  — menu back
BTN_RB     = 5    # right shoulder — menu confirm
BTN_BACK   = 6    # select/back
BTN_START  = 7    # pause
BTN_LS     = 8    # left stick click
BTN_RS     = 9    # right stick click


def _apply_deadzone(v, dz):
    if abs(v) < dz:
        return 0.0
    sign = 1.0 if v > 0 else -1.0
    return sign * (abs(v) - dz) / (1.0 - dz)

def _trigger_value(raw):
    """
    Triggers report either −1→+1 (SDL2) or 0→1 depending on driver.
    Normalise to 0→1 always.
    """
    # If driver returns −1 at rest, map [−1, 1] → [0, 1]
    if raw < -0.5:
        return 0.0
    if raw <= 0.0:
        return (raw + 1.0) / 1.0   # −1→+1 driver: (raw+1)/2 would be correct
    return raw                      # 0→1 driver: pass through


# ── InputState ────────────────────────────────────────────────────────────────

class InputState:
    """
    Merged keyboard + gamepad state for one frame.
    All values are updated by pump_controller_events().
    """
    def __init__(self):
        # ── Driving ──────────────────────────────────────────────────────────
        self.gas       = False    # digital (keyboard or button)
        self.brake     = False
        self.left      = False
        self.right     = False
        self.handbrake = False

        # Analogue (0.0–1.0); driving code uses these when > 0
        self.gas_axis       = 0.0
        self.brake_axis     = 0.0
        self.steer_axis     = 0.0   # −1.0 full left … +1.0 full right

        # ── Menu navigation ───────────────────────────────────────────────────
        self.menu_up      = False
        self.menu_down    = False
        self.menu_left    = False
        self.menu_right   = False
        self.menu_confirm = False   # A / Enter
        self.menu_back    = False   # B / Escape

        # ── Game actions ──────────────────────────────────────────────────────
        self.pause        = False   # Start
        self.reset        = False   # Y
        self.chat         = False   # (keyboard only — Enter)

        # ── Controller connected? ─────────────────────────────────────────────
        self.controller_active = False   # True if gamepad provided any input this frame

    # ── Helpers for driving code ─────────────────────────────────────────────

    def gas_value(self):
        """Returns 0–1 combining digital and analogue gas."""
        return max(float(self.gas), self.gas_axis)

    def brake_value(self):
        return max(float(self.brake), self.brake_axis)

    def steer_value(self):
        """
        Returns −1…+1 steering combining keyboard digital and analogue stick.
        Digital keyboard gives ±1; analogue stick gives the axis value.
        Analogue wins when both are present (so you can't double-steer).
        """
        if abs(self.steer_axis) > DEADZONE:
            return self.steer_axis
        if self.left and not self.right:
            return -1.0
        if self.right and not self.left:
            return 1.0
        return 0.0


# ── Module-level state ────────────────────────────────────────────────────────

_state      = InputState()
_joysticks  = {}          # instance_id → pygame.Joystick
_prev_hat   = {}          # instance_id → (x, y)  for edge detection
_prev_menu  = InputState()

# Edge-detect helpers so menu_up etc. are True only on the FIRST frame
_menu_held  = {"up": False, "down": False, "left": False, "right": False,
               "confirm": False, "back": False}
_menu_repeat_t = {"up": 0.0, "dn": 0.0, "lt": 0.0, "rt": 0.0}
_REPEAT_DELAY  = 0.40   # seconds before auto-repeat
_REPEAT_RATE   = 0.12   # seconds between repeated events


def get_input() -> InputState:
    """Return the current unified InputState."""
    return _state


def get_joysticks():
    """Return list of connected joystick names (for settings display)."""
    return [j.get_name() for j in _joysticks.values()]


def pump_controller_events(dt: float = 0.0):
    """
    Call once per frame BEFORE reading input.

    KEY DESIGN RULE — driving and menu inputs are STRICTLY SEPARATE:
      • Driving inputs  (gas/brake/steer/handbrake) come from triggers,
        sticks, and A/B/X buttons.
      • Menu inputs (menu_confirm/menu_back/menu_up etc.) come from A,
        B, LB, RB, d-pad, and left stick — but ONLY menu_back comes
        from B, and that flag must NOT be checked during gameplay so
        it cannot accidentally pause/close things.
      • pause comes ONLY from Start.  reset comes ONLY from Y.
      • B/X set handbrake for driving.  B also sets menu_back for menus.
        It is the caller's responsibility to only check menu_back when
        actually in a menu, never during a race.
    """
    global _state

    s = InputState()

    # ── Keyboard ─────────────────────────────────────────────────────────────
    keys = pygame.key.get_pressed()

    s.gas       = bool(keys[pygame.K_UP]    or keys[pygame.K_w])
    s.brake     = bool(keys[pygame.K_DOWN]  or keys[pygame.K_s])
    s.left      = bool(keys[pygame.K_LEFT]  or keys[pygame.K_a])
    s.right     = bool(keys[pygame.K_RIGHT] or keys[pygame.K_d])
    s.handbrake = bool(keys[pygame.K_SPACE])

    s.menu_up      = bool(keys[pygame.K_UP]    or keys[pygame.K_w])
    s.menu_down    = bool(keys[pygame.K_DOWN]   or keys[pygame.K_s])
    s.menu_left    = bool(keys[pygame.K_LEFT]   or keys[pygame.K_a])
    s.menu_right   = bool(keys[pygame.K_RIGHT]  or keys[pygame.K_d])
    s.menu_confirm = bool(keys[pygame.K_RETURN] or keys[pygame.K_KP_ENTER])
    s.menu_back    = bool(keys[pygame.K_ESCAPE])
    s.pause        = bool(keys[pygame.K_p])
    s.reset        = bool(keys[pygame.K_r])

    # ── Init / hot-plug joysticks ─────────────────────────────────────────────
    for i in range(pygame.joystick.get_count()):
        joy = pygame.joystick.Joystick(i)
        iid = joy.get_instance_id()
        if iid not in _joysticks:
            joy.init()
            _joysticks[iid] = joy

    for iid in list(_joysticks.keys()):
        try:
            _joysticks[iid].get_name()
        except Exception:
            del _joysticks[iid]

    # ── Read each connected gamepad ────────────────────────────────────────────
    for iid, joy in _joysticks.items():
        try:
            naxes    = joy.get_numaxes()
            nbuttons = joy.get_numbuttons()
            nhats    = joy.get_numhats()

            def axis(i, _joy=joy, _na=naxes):
                return _joy.get_axis(i) if i < _na else 0.0

            def btn(i, _joy=joy, _nb=nbuttons):
                return bool(_joy.get_button(i)) if i < _nb else False

            # ── Analogue trigger axes ─────────────────────────────────────────
            # Many controllers report triggers as -1.0 at rest on axis 2/5.
            # _trigger_value() normalises both -1→+1 and 0→+1 ranges to 0→1.
            raw_throttle = _trigger_value(axis(AXIS_THROTTLE))
            raw_brk      = _trigger_value(axis(AXIS_BRAKE))

            # Only register trigger input above a clear threshold to avoid
            # ghost gas/brake from a trigger resting at slightly-off-zero.
            DRIVE_THRESH = 0.08
            if raw_throttle > DRIVE_THRESH:
                s.gas_axis   = max(s.gas_axis,   raw_throttle)
                s.gas        = True
                s.controller_active = True
            if raw_brk > DRIVE_THRESH:
                s.brake_axis = max(s.brake_axis, raw_brk)
                s.brake      = True
                s.controller_active = True

            # ── Analogue steering ─────────────────────────────────────────────
            import math as _m
            raw_steer = _apply_deadzone(axis(AXIS_STEER), DEADZONE)
            if raw_steer != 0.0:
                sign      = 1.0 if raw_steer > 0 else -1.0
                raw_steer = sign * (abs(raw_steer) ** STEER_POWER)
                if abs(raw_steer) > abs(s.steer_axis):
                    s.steer_axis = raw_steer
                s.controller_active = True
                if raw_steer < -0.3: s.left  = True
                if raw_steer >  0.3: s.right = True

            # ── Face buttons — driving only ───────────────────────────────────
            # A  → gas (digital fallback, e.g. when no triggers)
            # B  → handbrake / drift  (NOT pause, NOT menu back during driving)
            # X  → handbrake / drift  (same as B)
            # Y  → reset car          (NOT a menu action during driving)
            # Start → pause           (the ONLY pause button)
            if btn(BTN_A):
                s.gas       = True
                s.controller_active = True
            if btn(BTN_B) or btn(BTN_X):
                s.handbrake = True
                s.controller_active = True
            if btn(BTN_START):
                s.pause     = True
                s.controller_active = True
            if btn(BTN_Y):
                s.reset     = True
                s.controller_active = True

            # ── Menu navigation ───────────────────────────────────────────────
            # These are ONLY meaningful in menus.  The game loop must NOT check
            # menu_confirm / menu_back while driving.
            if btn(BTN_A) or btn(BTN_RB):
                s.menu_confirm = True
            if btn(BTN_B) or btn(BTN_LB):
                s.menu_back    = True

            # ── D-pad ─────────────────────────────────────────────────────────
            if nhats > 0:
                hx, hy = joy.get_hat(0)
                if hx != 0 or hy != 0:
                    s.controller_active = True
                if hy ==  1: s.menu_up    = True
                if hy == -1: s.menu_down  = True
                if hx == -1: s.menu_left  = True; s.left  = True
                if hx ==  1: s.menu_right = True; s.right = True

            # ── Left stick for menu navigation ────────────────────────────────
            ly = _apply_deadzone(axis(AXIS_LSTICK_Y), DEADZONE)
            if ly < -0.5:
                s.menu_up   = True
                s.controller_active = True
            elif ly > 0.5:
                s.menu_down = True
                s.controller_active = True

        except Exception:
            pass   # joystick disconnected mid-frame

    _state = s
    return s


# ── FakeKeys ──────────────────────────────────────────────────────────────────
# CarController.update() takes a pygame key-state array.
# This adapter lets it work with our InputState's analogue values too.

class ControllerKeys:
    """
    Drop-in replacement for pygame.key.get_pressed() that merges
    keyboard + controller analogue inputs.

    Usage in driving code:
        keys = ControllerKeys(get_input())
        car.update(keys, dt)
    """
    def __init__(self, inp: InputState):
        self._inp = inp
        self._kb  = pygame.key.get_pressed()

    def __getitem__(self, k):
        inp = self._inp
        # Gas
        if k in (pygame.K_UP, pygame.K_w):
            return self._kb[k] or inp.gas_value() > 0.05
        # Brake
        if k in (pygame.K_DOWN, pygame.K_s):
            return self._kb[k] or inp.brake_value() > 0.05
        # Steer left
        if k in (pygame.K_LEFT, pygame.K_a):
            return self._kb[k] or inp.steer_value() < -0.1
        # Steer right
        if k in (pygame.K_RIGHT, pygame.K_d):
            return self._kb[k] or inp.steer_value() > 0.1
        # Handbrake
        if k == pygame.K_SPACE:
            return self._kb[k] or inp.handbrake
        return bool(self._kb[k])


# ── Steering override for analogue physics ────────────────────────────────────
# CarController uses digital left/right keys internally to compute steer_in.
# For analogue steering we patch the steer calculation externally.
# Call this AFTER car.update() to override the angular velocity with
# analogue precision.  (Optional — digital keys work fine too.)

def apply_analogue_steering(car, inp: InputState, dt: float):
    """
    After car.update() has run, blend the angular velocity toward
    the analogue stick target if a controller is active.
    This gives smoother mid-corner adjustments vs digital snapping.
    """
    if not inp.controller_active:
        return
    sv = inp.steer_value()
    if abs(sv) < 0.01:
        return
    import math as _m
    fwd_v   = car.fwd_speed
    sp_ratio= min(abs(fwd_v) / max(car.STEER_SPEED, 1.0), 1.0)
    target  = sv * car.STEER_RATE * car.trig_steer_mult * sp_ratio
    if car.boost > 0:
        target *= 1.0   # no extra on boost
    if hasattr(car, 'ang_vel'):
        car.ang_vel += (target - car.ang_vel) * min(1.0, dt * 18.0)


# ── Menu navigation edge-detect ───────────────────────────────────────────────
# Returns a new InputState where menu_* are True only on the FIRST frame
# they become True (or after the auto-repeat delay), to avoid flying through
# menus when a button is held.

_nav_held = {"up":False,"down":False,"left":False,"right":False,
             "confirm":False,"back":False}
_nav_timer= {"up":0.0,"down":0.0,"left":0.0,"right":0.0,
             "confirm":0.0,"back":0.0}

def nav_input(dt: float = 0.0) -> InputState:
    """
    Returns an InputState where menu navigation directions fire once on press
    and then repeat after REPEAT_DELAY at REPEAT_RATE.
    Use this in menus instead of raw get_input() for comfortable navigation.
    """
    raw = _state
    out = InputState()
    for attr in ("gas","brake","left","right","handbrake","gas_axis",
                 "brake_axis","steer_axis","pause","reset","controller_active"):
        setattr(out, attr, getattr(raw, attr))

    for key, raw_val in [("up",      raw.menu_up),
                          ("down",    raw.menu_down),
                          ("left",    raw.menu_left),
                          ("right",   raw.menu_right),
                          ("confirm", raw.menu_confirm),
                          ("back",    raw.menu_back)]:
        attr  = f"menu_{key}"
        held  = _nav_held[key]
        timer = _nav_timer[key]

        if raw_val:
            if not held:
                # First frame pressed — fire immediately
                setattr(out, attr, True)
                _nav_held[key]  = True
                _nav_timer[key] = 0.0
            else:
                # Already held — accumulate time and fire at repeat rate
                timer += dt
                _nav_timer[key] = timer
                if timer >= _REPEAT_DELAY:
                    # Fire at repeat rate after the initial delay
                    repeats_done = int((timer - _REPEAT_DELAY) / _REPEAT_RATE)
                    prev_repeats = int((timer - dt - _REPEAT_DELAY) / _REPEAT_RATE) \
                                   if timer - dt >= _REPEAT_DELAY else -1
                    if repeats_done > prev_repeats:
                        setattr(out, attr, True)
                    else:
                        setattr(out, attr, False)
                else:
                    setattr(out, attr, False)
        else:
            setattr(out, attr, False)
            _nav_held[key]  = False
            _nav_timer[key] = 0.0

    return out


# ── Controller info (for settings HUD) ───────────────────────────────────────

def controller_info() -> str:
    """Returns a short string describing connected controllers."""
    names = get_joysticks()
    if not names:
        return "No controller detected"
    if len(names) == 1:
        return names[0][:40]
    return f"{len(names)} controllers connected"


# ── On-screen keyboard (mobile / browser) ────────────────────────────────────

def show_keyboard(rect=None):
    """
    Ask the OS / browser to show the on-screen / phone keyboard.
    Call this whenever a text input field is focused.

    rect — a pygame.Rect of the input field (optional, helps OS position
           the keyboard so it doesn't cover the field).
    """
    try:
        if rect is not None:
            pygame.key.set_text_input_rect(rect)
        pygame.key.start_text_input()
    except Exception:
        pass   # not available on all platforms — silently ignore


def hide_keyboard():
    """Hide the on-screen keyboard."""
    try:
        pygame.key.stop_text_input()
    except Exception:
        pass


# ── MenuNavigator ─────────────────────────────────────────────────────────────

class MenuNavigator:
    """
    Tracks the currently selected item in a list-based menu and handles
    controller/keyboard up-down-confirm-back navigation.

    Usage:
        nav = MenuNavigator(num_items=len(buttons))

        # Each frame in your menu:
        result = nav.update(nav_input(dt))
        if result == "confirm":   # A pressed on item nav.index
            handle_select(nav.index)
        elif result == "back":    # B pressed
            go_back()

        # Draw highlight:
        for i, btn in enumerate(buttons):
            selected = (i == nav.index)
            draw_button(btn, highlighted=selected)
    """

    def __init__(self, num_items: int, wrap: bool = True):
        self.num_items = num_items
        self.wrap      = wrap
        self.index     = 0

    def set_count(self, n: int):
        self.num_items = n
        self.index = min(self.index, max(0, n - 1))

    def update(self, nav: "InputState") -> str:
        """
        Pass the result of nav_input(dt).
        Returns: "confirm", "back", "up", "down", or "" each frame.
        """
        if self.num_items == 0:
            return ""

        if nav.menu_up:
            if self.index > 0:
                self.index -= 1
            elif self.wrap:
                self.index = self.num_items - 1
            return "up"

        if nav.menu_down:
            if self.index < self.num_items - 1:
                self.index += 1
            elif self.wrap:
                self.index = 0
            return "down"

        if nav.menu_confirm:
            return "confirm"

        if nav.menu_back:
            return "back"

        return ""

    def draw_cursor(self, surf, x: int, y: int, item_height: int,
                    color=(255, 215, 48), size: int = 8):
        """
        Draw a simple triangle cursor to the left of the selected item.
        x, y  — top-left of the first item.
        item_height — pixel height per item (used to position the cursor).
        """
        cy = y + self.index * item_height + item_height // 2
        pts = [(x - size - 4, cy - size // 2),
               (x - size - 4, cy + size // 2),
               (x - 4,        cy)]
        pygame.draw.polygon(surf, color, pts)