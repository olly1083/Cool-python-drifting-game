"""
carcontroller.py  –  Drift Master

HOW THE PHYSICS WORK (simple and correct):
  • vx, vy  = velocity in WORLD space (pixels/second).  This is the one true
    source of truth and is never clobbered mid-frame.
  • Every frame we DECOMPOSE vx/vy onto the car's current forward/right axes
    to get fwd_speed and lat_speed.  We modify each component independently,
    then RECOMPOSE back into vx/vy.
  • Angle is only changed AFTER velocity is fully updated, so turning never
    teleports momentum.
  • Grip removes lateral velocity each frame: high grip = snappy cornering,
    low grip (handbrake) = sliding rear = drift.
  • Wall collision zeroes the velocity component going into the wall and pushes
    the car out by the exact penetration depth.
"""
import pygame, math, random


class Smoke:
    __slots__ = ("x","y","vx","vy","life","max_life","size","col")
    def __init__(self, x, y, vx, vy):
        self.x, self.y   = x, y
        self.vx = vx + random.uniform(-12, 12)
        self.vy = vy + random.uniform(-12, 12)
        self.life = self.max_life = random.uniform(0.30, 0.65)
        self.size = random.uniform(4, 9)
        self.col  = (random.randint(180, 215),) * 3

    def update(self, dt):
        self.x  += self.vx * dt;  self.y  += self.vy * dt
        self.vx *= (1 - dt * 3);  self.vy *= (1 - dt * 3)
        self.life -= dt
        return self.life > 0

    def draw(self, surf, cx, cy, zoom, sw, sh, quality):
        sx = (self.x - cx) * zoom + sw * 0.5
        sy = (self.y - cy) * zoom + sh * 0.5
        frac = max(0.0, self.life / self.max_life)
        sz   = max(1, int(self.size * zoom * (0.4 + 0.6 * frac)))
        if quality == "Low":
            pygame.draw.circle(surf, self.col, (int(sx), int(sy)), sz)
        else:
            a = int(170 * frac)
            s = pygame.Surface((sz * 2 + 2, sz * 2 + 2), pygame.SRCALPHA)
            pygame.draw.circle(s, (*self.col, a), (sz + 1, sz + 1), sz)
            surf.blit(s, (int(sx) - sz - 1, int(sy) - sz - 1))


class CarController:
    W = 22   # width  (pixels)
    H = 36   # height (pixels)

    # ---------- tuning ----------
    SPEED_MAX   = 500.0   # px / s
    SPEED_REV   = 130.0
    SPEED_BOOST = 650.0
    ACCEL       = 650.0   # px / s²
    ACCEL_BOOST = 1100.0
    BRAKE       = 900.0
    COAST       = 250.0   # passive slowdown (no throttle/brake)

    STEER_RATE  = 210.0   # deg / s  (at full speed)
    STEER_SPEED = 145.0   # px/s at which full steer is available

    GRIP        = 12.0    # normal grip coefficient (exp damping of lat vel)
    GRIP_DRIFT  =  0.9    # handbrake grip
    GRIP_SLIDE  =  3.5    # sliding (high lat speed, no handbrake)
    SLIDE_THRESH = 80.0   # lat speed that triggers slide mode

    def __init__(self, x, y, angle=0, color=(220, 55, 55)):
        # position
        self.x = float(x)
        self.y = float(y)
        # heading: 0 = car faces UP (screen −Y).  increases clockwise.
        self.angle = float(angle)
        self.color = tuple(color)

        # ── velocity lives in WORLD space ──────────────────────────────────
        self.vx = 0.0
        self.vy = 0.0
        # these are derived and exposed for camera / HUD
        self.speed     = 0.0
        self.fwd_speed = 0.0   # + = forward,  − = reverse
        self.lat_speed = 0.0   # + = sliding right

        self.ang_vel     = 0.0   # deg / s
        self.is_drifting = False

        # boost
        self.boost   = 0.0   # seconds remaining
        self._bflash = 0

        # active trigger zone overrides (set each frame by game session BEFORE
        # update() is called, and reset at the END of update())
        self.trig_speed_mult  = 1.0   # multiplies SPEED_MAX
        self.trig_accel_mult  = 1.0   # multiplies ACCEL
        self.trig_steer_mult  = 1.0   # multiplies STEER_RATE
        self.trig_grip_mult   = 1.0   # multiplies GRIP (lower = more drift)
        self._trig_active     = None  # name of active trigger for HUD

        # scoring
        self.drift_score = 0
        self.drift_combo = 0.0
        self.drift_mult  = 1.0

        # effects
        self.hit_timer    = 0.0
        self.skid_marks   = []
        self._skid_t      = 0.0
        self.particles    = []
        self._smoke_t     = 0.0

        # injected by session
        self.particle_quality = "High"
        self.skidmarks_on     = True

        # live tune overrides (set by ZoneTrigger, reset when car leaves)
        # None means "use class default"
        self.tune_speed_max    = None   # override SPEED_MAX
        self.tune_accel        = None   # override ACCEL
        self.tune_grip_drift   = None   # override GRIP_DRIFT
        self.tune_slide_thresh = None   # override SLIDE_THRESH
        self._active_zone      = None   # key of current zone

    # ── axes ──────────────────────────────────────────────────────────────────
    # angle=0 → nose points UP = world (0, −1)
    # pygame Y increases downward, so:
    #   forward  = (−sin θ,  −cos θ)
    #   right    = ( cos θ,  −sin θ)   ← rotate forward 90° clockwise

    def _fwd(self):
        # angle=0 -> nose UP (0,-1), angle=90 -> nose RIGHT (1,0)
        r = math.radians(self.angle)
        return (math.sin(r), -math.cos(r))

    def _right(self):
        # 90 degrees clockwise from forward
        r = math.radians(self.angle)
        return (math.cos(r), math.sin(r))

    def get_corners(self):
        fx, fy = self._fwd()
        rx, ry = self._right()
        hw, hh = self.W * 0.5, self.H * 0.5
        return [
            (self.x + fx*hh + rx*hw, self.y + fy*hh + ry*hw),
            (self.x + fx*hh - rx*hw, self.y + fy*hh - ry*hw),
            (self.x - fx*hh - rx*hw, self.y - fy*hh - ry*hw),
            (self.x - fx*hh + rx*hw, self.y - fy*hh + ry*hw),
        ]

    # ── update ────────────────────────────────────────────────────────────────

    def update(self, keys, dt):
        dt = min(dt, 0.05)
        # NOTE: trig_* multipliers are NO LONGER reset here.
        # They are set by the game session (via TriggerZone.apply_to_car)
        # BEFORE this method is called, and are reset at the END of this
        # method so they are always fresh for the next frame.

        # ── Support both plain pygame keys and ControllerKeys ─────────────────
        # If keys has analogue gas/brake/steer values, use them for physics.
        # This gives smooth trigger throttle and analogue steering.
        from controller import ControllerKeys as _CK
        if isinstance(keys, _CK):
            inp        = keys._inp
            gas_val    = inp.gas_value()
            brake_val  = inp.brake_value()
            steer_val  = inp.steer_value()   # −1…+1
            gas        = gas_val   > 0.05
            brake      = brake_val > 0.05
            left       = steer_val < -0.1
            right      = steer_val > 0.1
            hb         = inp.handbrake
            # Analogue gas/brake magnitudes for physics (0–1)
            _gas_mag   = gas_val
            _brake_mag = brake_val
            _steer_mag = steer_val   # signed −1…+1
        else:
            gas   = keys[pygame.K_UP]    or keys[pygame.K_w]
            brake = keys[pygame.K_DOWN]  or keys[pygame.K_s]
            left  = keys[pygame.K_LEFT]  or keys[pygame.K_a]
            right = keys[pygame.K_RIGHT] or keys[pygame.K_d]
            hb    = keys[pygame.K_SPACE]
            _gas_mag   = float(gas)
            _brake_mag = float(brake)
            # Digital steering: ±1 or 0
            _steer_mag = float(right) - float(left)

        # ── STEP 1: decompose current world velocity onto car axes ────────────
        fx, fy = self._fwd()
        rx, ry = self._right()

        fwd_v = self.vx * fx + self.vy * fy   # how fast we're going forward
        lat_v = self.vx * rx + self.vy * ry   # how fast we're sliding sideways

        # ── STEP 2: apply throttle / brake along the forward axis ─────────────
        boosting = self.boost > 0
        if boosting:
            self.boost   = max(0.0, self.boost - dt)
            self._bflash = (self._bflash + 1) % 6
            top_speed = self.SPEED_BOOST
            accel     = self.ACCEL_BOOST
        else:
            top_speed = self.SPEED_MAX * self.trig_speed_mult
            accel     = self.ACCEL * self.trig_accel_mult

        if gas:
            # Scale acceleration by analogue trigger depth (1.0 for keyboard)
            fwd_v += accel * _gas_mag * dt
            fwd_v  = min(fwd_v, top_speed)
        elif brake:
            if fwd_v > 1.0:
                fwd_v -= self.BRAKE * _brake_mag * dt
                fwd_v  = max(0.0, fwd_v)
            else:
                fwd_v -= self.ACCEL * 0.6 * _brake_mag * dt
                fwd_v  = max(-self.SPEED_REV, fwd_v)
        else:
            # coast
            if fwd_v > 0:
                fwd_v = max(0.0, fwd_v - self.COAST * dt)
            else:
                fwd_v = min(0.0, fwd_v + self.COAST * dt)

        # ── STEP 3: apply grip to lateral velocity ────────────────────────────
        abs_lat = abs(lat_v)
        self.is_drifting = hb or abs_lat > self.SLIDE_THRESH

        if hb:
            grip = self.GRIP_DRIFT * self.trig_grip_mult
        elif abs_lat > self.SLIDE_THRESH:
            grip = self.GRIP_SLIDE * self.trig_grip_mult
        else:
            grip = self.GRIP * self.trig_grip_mult

        # exponential decay: lat_v * e^(-grip*dt)
        lat_v *= math.exp(-grip * dt)

        # ── STEP 4: recompose world velocity BEFORE rotating the car ──────────
        self.vx = fx * fwd_v + rx * lat_v
        self.vy = fy * fwd_v + ry * lat_v

        # ── STEP 5: steer (rotate the car) ────────────────────────────────────
        speed_ratio = min(abs(fwd_v) / max(self.STEER_SPEED, 1.0), 1.0)
        steer_rate  = self.STEER_RATE * self.trig_steer_mult * speed_ratio
        if hb:
            steer_rate *= 1.55

        # Use analogue steer magnitude directly (works for both digital ±1
        # and analogue 0.0–1.0 values from the controller stick)
        steer_in = _steer_mag
        if fwd_v < -2.0:
            steer_in = -steer_in   # natural reverse steering

        target_av = steer_in * steer_rate
        self.ang_vel += (target_av - self.ang_vel) * min(1.0, dt * 16.0)
        self.angle   += self.ang_vel * dt

        # ── STEP 6: integrate position ────────────────────────────────────────
        self.x += self.vx * dt
        self.y += self.vy * dt

        # ── STEP 7: expose derived scalars ────────────────────────────────────
        self.speed     = math.hypot(self.vx, self.vy)
        self.fwd_speed = fwd_v
        self.lat_speed = lat_v

        # ── STEP 8: drift scoring ─────────────────────────────────────────────
        intensity = max(0.0, abs_lat - self.SLIDE_THRESH * 0.5)
        if self.is_drifting and intensity > 5:
            self.drift_combo += dt * intensity * 0.04
            self.drift_mult   = 1.0 + min(self.drift_combo / 40.0, 9.0)
            self.drift_score += int(intensity * self.drift_mult * dt * 1.0)
        else:
            self.drift_combo = max(0.0, self.drift_combo - dt * 20.0)
            self.drift_mult  = max(1.0, self.drift_mult  - dt * 2.5)

        # ── STEP 9: effects ───────────────────────────────────────────────────
        if self.hit_timer > 0:
            self.hit_timer -= dt

        if self.skidmarks_on:
            self._skid_t += dt
            if self.is_drifting and self.speed > 15 and self._skid_t >= 0.02:
                self._skid_t = 0.0
                rx2, ry2 = self._right()
                for s in (-1, 1):
                    self.skid_marks.append([
                        self.x + rx2 * self.W * 0.38 * s,
                        self.y + ry2 * self.W * 0.38 * s,
                        200.0
                    ])
            for sk in self.skid_marks:
                sk[2] -= dt * 55
            self.skid_marks = [sk for sk in self.skid_marks if sk[2] > 0]
            if len(self.skid_marks) > 1400:
                self.skid_marks = self.skid_marks[-1400:]

        if self.particle_quality != "Off":
            self._smoke_t += dt
            interval = 0.04 if self.particle_quality == "High" else 0.08
            if self.is_drifting and self.speed > 15 and self._smoke_t >= interval:
                self._smoke_t = 0.0
                fx2, fy2 = self._fwd()
                rx2, ry2 = self._right()
                for s in (-1, 1):
                    px = self.x + rx2 * self.W * 0.4 * s - fx2 * self.H * 0.4
                    py = self.y + ry2 * self.W * 0.4 * s - fy2 * self.H * 0.4
                    self.particles.append(Smoke(px, py,
                                                -rx2 * lat_v * 0.2,
                                                -ry2 * lat_v * 0.2))
            self.particles = [p for p in self.particles if p.update(dt)]

        # ── STEP 10: reset trigger multipliers for next frame ─────────────────
        # The game session applies trigger effects BEFORE calling update(), so
        # we wipe them here at the end — ready for the next frame's apply pass.
        self.trig_speed_mult = 1.0
        self.trig_accel_mult = 1.0
        self.trig_steer_mult = 1.0
        self.trig_grip_mult  = 1.0
        self._trig_active    = None

    # ── wall collision ────────────────────────────────────────────────────────

    def push_out_of_rect(self, rect, is_outer):
        """
        Both outer walls and inner islands are solid rects the car must not
        enter.  For every corner found inside the rect we:
          1. Find the shortest exit direction (min penetration axis).
          2. Move the car that far out plus a small margin.
          3. Remove the velocity component pointing INTO the wall (reflect
             with heavy damping so the car slides along the wall instead of
             sticking or bouncing wildly).
        We loop up to 8 times so the car cannot get wedged between two walls.
        """
        hit = False
        for _ in range(8):
            moved = False
            for cx, cy in self.get_corners():
                if not rect.collidepoint(cx, cy):
                    continue

                # How deep is this corner inside the rect on each face?
                # pen_X is always positive when the corner is truly inside.
                pen_l = cx - rect.left    # depth past left  edge  -> exit LEFT
                pen_r = rect.right  - cx  # depth past right edge  -> exit RIGHT
                pen_t = cy - rect.top     # depth past top   edge  -> exit UP
                pen_b = rect.bottom - cy  # depth past bottom edge -> exit DOWN

                # Pick the face with smallest penetration = shortest escape.
                minp = min(pen_l, pen_r, pen_t, pen_b)

                # Exit direction: push car OUT of the rect.
                # pen_l smallest -> exit via left edge  -> move car LEFT  (-x)
                # pen_r smallest -> exit via right edge -> move car RIGHT (+x)
                # pen_t smallest -> exit via top edge   -> move car UP    (-y)
                # pen_b smallest -> exit via bottom edge-> move car DOWN  (+y)
                if   minp == pen_l: nx, ny = -1,  0   # push left
                elif minp == pen_r: nx, ny =  1,  0   # push right
                elif minp == pen_t: nx, ny =  0, -1   # push up
                else:               nx, ny =  0,  1   # push down

                # Move car out by penetration depth + margin
                self.x += nx * (minp + 2.0)
                self.y += ny * (minp + 2.0)

                # Velocity correction: remove the component going INTO the wall.
                # The wall surface normal pointing OUT (away from solid) = (nx, ny).
                # Dot product < 0 means car is moving INTO the wall.
                v_dot = self.vx * nx + self.vy * ny
                if v_dot < 0:
                    # Remove the inward component entirely, keep tangential.
                    self.vx -= v_dot * nx
                    self.vy -= v_dot * ny
                    # Dampen to prevent sliding forever
                    self.vx *= 0.70
                    self.vy *= 0.70
                    self.hit_timer = 0.12

                hit   = True
                moved = True
                break   # corners changed — restart loop with new position

            if not moved:
                break   # no corners inside any wall edge — done

        return hit

    def reset(self, x, y, angle=0):
        self.x, self.y, self.angle = float(x), float(y), float(angle)
        self.vx = self.vy = self.ang_vel = 0.0
        self.speed = self.fwd_speed = self.lat_speed = 0.0
        self.is_drifting = False
        self.drift_score = 0
        self.drift_combo = 0.0
        self.drift_mult  = 1.0
        self.boost       = 0.0
        self.hit_timer   = 0.0
        self.skid_marks.clear()
        self.particles.clear()

    # ── draw ──────────────────────────────────────────────────────────────────

    def draw(self, surf, cam_x, cam_y, zoom):
        sw, sh = surf.get_size()

        # skid marks
        if self.skidmarks_on and self.skid_marks:
            sk_s = pygame.Surface((sw, sh), pygame.SRCALPHA)
            r    = max(1, int(3 * zoom))
            for sk in self.skid_marks:
                ssx = (sk[0] - cam_x) * zoom + sw * 0.5
                ssy = (sk[1] - cam_y) * zoom + sh * 0.5
                pygame.draw.circle(sk_s, (10, 10, 10, int(min(255, sk[2]))),
                                   (int(ssx), int(ssy)), r)
            surf.blit(sk_s, (0, 0))

        # smoke
        for p in self.particles:
            p.draw(surf, cam_x, cam_y, zoom, sw, sh, self.particle_quality)

        sx = (self.x - cam_x) * zoom + sw * 0.5
        sy = (self.y - cam_y) * zoom + sh * 0.5
        cw = max(8,  int(self.W * zoom))
        ch = max(12, int(self.H * zoom))
        pd, p2 = 8, 4
        br = max(3, int(6 * zoom))

        # shadow
        shd = pygame.Surface((cw + 16, ch + 12), pygame.SRCALPHA)
        pygame.draw.ellipse(shd, (0, 0, 0, 55), (4, 6, cw + 8, ch))
        rs  = pygame.transform.rotate(shd, -self.angle)
        surf.blit(rs, rs.get_rect(center=(int(sx) + 5, int(sy) + 6)))

        # body
        body = pygame.Surface((cw + pd, ch + pd), pygame.SRCALPHA)
        r, g, b = self.color
        if self.boost > 0 and self._bflash < 3:
            r = min(255, r + 100);  g = min(255, g + 80)
        if self.hit_timer > 0:
            r, g, b = 255, 255, 255

        pygame.draw.rect(body, (r, g, b), (p2, p2, cw, ch), border_radius=br)

        roof = (min(255,r+40), min(255,g+40), min(255,b+40))
        rfw = max(4, int(cw * .56));  rfh = max(3, int(ch * .40))
        pygame.draw.rect(body, roof,
                         (p2 + (cw-rfw)//2, p2 + int(ch*.09), rfw, rfh),
                         border_radius=max(2, br-2))

        ww = max(4, int(cw * .64));  wh = max(3, int(ch * .21))
        wx_ = p2 + (cw-ww)//2;       wy_ = p2 + int(ch * .12)
        pygame.draw.rect(body, (160, 220, 255, 210),
                         (wx_, wy_, ww, wh), border_radius=max(2, br-3))
        pygame.draw.rect(body, (130, 188, 228, 155),
                         (wx_, p2 + int(ch*.60), ww, max(2, int(ch*.14))),
                         border_radius=max(2, br-3))

        lw = max(2, int(cw * .24));  lh = max(2, int(ch * .07))
        ly = p2 + ch - lh - max(1, int(2*zoom))
        pygame.draw.rect(body, (255, 38, 38), (p2 + 2,        ly, lw, lh), border_radius=2)
        pygame.draw.rect(body, (255, 38, 38), (p2 + cw-lw-2,  ly, lw, lh), border_radius=2)
        hy = p2 + max(1, int(2*zoom))
        pygame.draw.rect(body, (255, 242, 178), (p2 + 2,        hy, lw, lh), border_radius=2)
        pygame.draw.rect(body, (255, 242, 178), (p2 + cw-lw-2,  hy, lw, lh), border_radius=2)

        if self.is_drifting and self.speed > 15:
            pulse = abs(math.sin(pygame.time.get_ticks() * 0.008))
            ga    = int(80 + 140 * pulse)
            pygame.draw.rect(body, (*self.color, ga),
                             (0, 0, cw+pd, ch+pd), 2, border_radius=br+2)

        rb = pygame.transform.rotate(body, -self.angle)
        surf.blit(rb, rb.get_rect(center=(int(sx), int(sy))))

    # ── score HUD ─────────────────────────────────────────────────────────────

    def draw_score_hud(self, surf, fB, fM, fS, sw, sh):
        panel = pygame.Surface((238, 108), pygame.SRCALPHA)
        panel.fill((0, 0, 0, 162))
        pygame.draw.rect(panel, (88, 80, 42, 200), (0, 0, 238, 108), 2, border_radius=8)
        surf.blit(panel, (sw - 248, 10))

        surf.blit(fS.render("DRIFT SCORE", True, (182, 168, 105)), (sw-240, 14))
        val = fB.render(f"{self.drift_score:,}", True, (255, 215, 48))
        surf.blit(val, (sw-240, 30))

        if self.is_drifting and self.speed > 15:
            mx = fM.render(f"×{self.drift_mult:.1f}", True, (255, 92, 32))
            surf.blit(mx, (sw-240 + val.get_width() + 8, 36))
            surf.blit(fS.render(f"COMBO  {self.drift_combo:.0f}", True, (255, 158, 48)), (sw-240, 74))

        km_h = self.speed * (300.0 / self.SPEED_MAX)
        bw   = int(min(km_h, 300) / 300 * 215)
        pygame.draw.rect(surf, (26, 26, 36), (sw-240, 96, 215, 10), border_radius=5)
        bc = (48, 198, 255) if not self.is_drifting else (255, 102, 32)
        if bw > 0:
            pygame.draw.rect(surf, bc, (sw-240, 96, bw, 10), border_radius=5)
        surf.blit(fS.render(f"{km_h:.0f} km/h", True, (148, 148, 148)), (sw-110, 96))

        if self.boost > 0:
            bv  = int(min(self.boost / 3.0, 1.0) * 200)
            by2 = sh - 30
            pygame.draw.rect(surf, (40, 36, 8),   (sw//2-100, by2, 200, 14), border_radius=7)
            pygame.draw.rect(surf, (255, 198, 0), (sw//2-100, by2, bv, 14),  border_radius=7)
            bl = fS.render("BOOST", True, (255, 215, 48))
            surf.blit(bl, (sw//2 - bl.get_width()//2, by2 - 18))