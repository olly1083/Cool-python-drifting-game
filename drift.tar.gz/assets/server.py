"""
server.py  –  Drift Master Multiplayer Server
Run:  python server.py [--port 7777] [--wsport 7778] [--config server_config.json]

Desktop clients  →  TCP on --port   (default 7777)
Browser clients  →  WebSocket on --wsport (default 7778)
Both share identical game logic.

Requires:  pip install websockets

════════════════════════════════════════════════════════
 OPERATOR CONSOLE
════════════════════════════════════════════════════════
  list / kick / ban / unban / bans / mute / unmute
  msg / skip / reload / config / set / status / help
  quit / exit
════════════════════════════════════════════════════════
"""
import argparse, asyncio, json, math, os, random, socket
import sys, threading, time, traceback

# Ensure the game's own modules (network.py, carcontroller.py etc.) are found
# before any identically-named packages installed in site-packages.
_here = os.path.abspath(os.path.dirname(__file__))
if _here not in sys.path:
    sys.path.insert(0, _here)

from network import (
    DEFAULT_PORT, MAX_PLAYERS, TICK_RATE,
    VOTE_DURATION, COUNTDOWN_SECS, BUMPER_DURATION, RACE_TIMEOUT,
    MODE_RACE, MODE_BUMPER, MODES, MODE_LABELS, MODE_DESCS,
    S_WELCOME, S_LEVEL_DATA, S_PLAYER_JOIN, S_PLAYER_LEAVE,
    S_LOBBY, S_VOTE_START, S_VOTE_UPDATE, S_COUNTDOWN,
    S_GAME_START, S_STATE, S_LAP, S_FINISH, S_GAME_OVER,
    S_CHAT, S_PING,
    C_JOIN, C_READY, C_VOTE, C_INPUT, C_CHAT, C_PONG,
    MsgBuffer,
)

import pygame
os.environ.setdefault("SDL_VIDEODRIVER", "dummy")
os.environ.setdefault("SDL_AUDIODRIVER", "dummy")
pygame.init()

from carcontroller import CarController
import pygame.locals as _pl

LEVELS_DIR      = "levels"
CONFIG_FILE     = "server_config.json"
WS_PORT_DEFAULT = 7778

ST_LOBBY     = "lobby"
ST_VOTING    = "voting"
ST_COUNTDOWN = "countdown"
ST_RACING    = "racing"
ST_RESULTS   = "results"

# ── Default config ────────────────────────────────────────────────────────────
DEFAULT_CONFIG = {
    "server_name":          "Drift Master Server",
    "motd":                 "Welcome! Have fun drifting.",
    "max_players":          16,
    "port":                 DEFAULT_PORT,
    "ws_port":              WS_PORT_DEFAULT,
    "levels_dir":           LEVELS_DIR,
    "min_players_to_start": 1,
    "vote_duration":        20.0,
    "countdown_secs":       5.0,
    "results_display_secs": 15.0,
    "allow_join_mid_vote":  True,
    "allow_join_mid_game":  False,
    "race_timeout":         300.0,
    "bumper_duration":      120.0,
    "triggers_enabled":     True,
    "chat_enabled":         True,
    "chat_max_length":      200,
    "chat_rate_limit":      1.5,
    "name_max_length":      20,
    "kick_on_input_flood":  True,
    "input_flood_threshold":60,
    "operator_password":    "",
    "log_file":             "",
    "banned_ips":           [],
}

CONFIG_HELP = {
    "server_name":          "Display name shown to players",
    "motd":                 "Message of the day sent on join",
    "max_players":          "Maximum simultaneous players (1-16)",
    "ws_port":              "WebSocket port for browser clients (default 7778)",
    "min_players_to_start": "Ready players needed before voting begins",
    "vote_duration":        "Seconds players have to vote",
    "countdown_secs":       "Pre-race countdown seconds",
    "results_display_secs": "Seconds to show results before lobby reset",
    "allow_join_mid_vote":  "Allow new players during voting (true/false)",
    "allow_join_mid_game":  "Allow new players during a race (true/false)",
    "race_timeout":         "Force-end race after this many seconds",
    "bumper_duration":      "Bumper cars time limit in seconds",
    "triggers_enabled":     "Enable/disable level trigger zones (true/false)",
    "chat_enabled":         "Enable/disable all player chat (true/false)",
    "chat_max_length":      "Max characters per chat message",
    "chat_rate_limit":      "Min seconds between player messages",
    "name_max_length":      "Max player name length",
    "kick_on_input_flood":  "Kick players spamming inputs (true/false)",
    "input_flood_threshold":"Inputs/sec that triggers flood detection",
    "operator_password":    "Password for /op command (empty = disabled)",
    "log_file":             "Log file path (empty = stdout only)",
    "banned_ips":           "(read-only — use ban/unban commands)",
}


# ── Config ────────────────────────────────────────────────────────────────────

def load_config(path):
    cfg = dict(DEFAULT_CONFIG)
    if os.path.exists(path):
        try:
            with open(path) as f:
                user = json.load(f)
            for k, v in user.items():
                if k in cfg:
                    cfg[k] = v
            _log(f"[CFG]  Loaded config from {path}")
        except Exception as e:
            _log(f"[WARN] Could not load {path}: {e} — using defaults")
    else:
        _log(f"[CFG]  {path} not found — creating with defaults")
        save_config(cfg, path)
    return cfg

def save_config(cfg, path):
    try:
        with open(path, "w") as f:
            json.dump(cfg, f, indent=2)
    except Exception as e:
        _log(f"[WARN] Could not save config: {e}")


# ── Logging ───────────────────────────────────────────────────────────────────

_log_lock        = threading.Lock()
_log_file_handle = None

def _log(msg):
    ts   = time.strftime("%H:%M:%S")
    line = f"[{ts}] {msg}"
    with _log_lock:
        print(line, flush=True)
        if _log_file_handle:
            try:
                _log_file_handle.write(line + "\n")
                _log_file_handle.flush()
            except Exception:
                pass

def _set_log_file(path):
    global _log_file_handle
    if _log_file_handle:
        _log_file_handle.close()
        _log_file_handle = None
    if path:
        try:
            _log_file_handle = open(path, "a", encoding="utf-8")
            _log(f"[CFG]  Logging to {path}")
        except Exception as e:
            _log(f"[WARN] Cannot open log file: {e}")


# ── Helpers ───────────────────────────────────────────────────────────────────

def load_levels(directory):
    levels = {}
    if not os.path.isdir(directory):
        _log(f"[WARN] Levels directory '{directory}' not found.")
        return levels
    for fn in sorted(os.listdir(directory)):
        if fn.endswith(".lev"):
            path = os.path.join(directory, fn)
            try:
                with open(path) as f:
                    data = json.load(f)
                levels[fn] = data
                _log(f"[LEV]  Loaded: {fn}  ({data.get('name', fn)})")
            except Exception as e:
                _log(f"[WARN] Could not load {fn}: {e}")
    return levels

class _FakeKeys:
    def __init__(self, inp):
        self._d = {
            _pl.K_UP:    inp.get("gas",   False),
            _pl.K_w:     inp.get("gas",   False),
            _pl.K_DOWN:  inp.get("brake", False),
            _pl.K_s:     inp.get("brake", False),
            _pl.K_LEFT:  inp.get("left",  False),
            _pl.K_a:     inp.get("left",  False),
            _pl.K_RIGHT: inp.get("right", False),
            _pl.K_d:     inp.get("right", False),
            _pl.K_SPACE: inp.get("hb",    False),
        }
    def __getitem__(self, k):
        return self._d.get(k, False)

def dict_to_keys(inp):
    return _FakeKeys(inp)

def _spawn_grid(sx, sy, angle, n):
    rad = math.radians(angle)
    fwd = (math.sin(rad), -math.cos(rad))
    rgt = (math.cos(rad),  math.sin(rad))
    positions = []
    cols = 2; spacing_side = 45; spacing_back = 60
    for i in range(n):
        row = i // cols; col = i % cols
        side_off = (col - (cols-1)/2.0) * spacing_side
        back_off = (row + 1) * spacing_back
        positions.append((sx - fwd[0]*back_off + rgt[0]*side_off,
                           sy - fwd[1]*back_off + rgt[1]*side_off))
    return positions


# ── ServerTriggerZone ─────────────────────────────────────────────────────────

TRIGGER_DEFAULTS_SRV = {"speed":1.5, "accel":1.5, "steer":1.5, "drift":0.3}

class ServerTriggerZone:
    def __init__(self, d):
        self.rect  = pygame.Rect(int(d["x"]),int(d["y"]),int(d["w"]),int(d["h"]))
        self.kind  = d.get("kind","speed")
        raw        = float(d.get("value", TRIGGER_DEFAULTS_SRV.get(self.kind, 1.0)))
        self.value = self._clamp(self.kind, raw)

    @staticmethod
    def _clamp(kind, v):
        if kind == "speed":   return 1.0 if v>10.0 else max(0.1,min(10.0,v))
        if kind in ("accel","steer"): return max(0.1,min(10.0,v))
        if kind == "drift":   return max(0.05,min(10.0,v))
        return v

    def apply_to_car(self, car):
        if self.kind=="speed":
            car.trig_speed_mult *= self.value
            car._trig_active = f"SPEED ×{self.value:.1f}"
        elif self.kind=="accel":
            car.trig_accel_mult *= self.value
            car._trig_active = f"ACCEL ×{self.value:.1f}"
        elif self.kind=="steer":
            car.trig_steer_mult *= self.value
            car._trig_active = f"TURN ×{self.value:.1f}"
        elif self.kind=="drift":
            car.trig_grip_mult *= self.value
            car._trig_active = f"DRIFT ×{self.value:.1f}"


# ── Connection abstractions ───────────────────────────────────────────────────

class TcpConn:
    """Wraps a non-blocking TCP socket + MsgBuffer."""
    def __init__(self, sock, addr):
        self._buf  = MsgBuffer(sock)
        self._sock = sock
        self._addr = addr

    @property
    def ip(self): return self._addr[0]

    def send(self, msg):
        return self._buf.send(msg)

    def recv_all(self):
        # Returns list or None (disconnect)
        return self._buf.recv_all()

    def close(self):
        try: self._sock.close()
        except: pass


class WsConn:
    """
    Thread-safe bridge between the game thread and an asyncio WebSocket.
    The asyncio receiver pushes messages into _inbox.
    The game thread drains _inbox via recv_all() and posts sends via
    asyncio.run_coroutine_threadsafe so it never blocks the event loop.
    """
    def __init__(self, ws, loop, addr):
        self._ws     = ws
        self._loop   = loop
        self._addr   = addr
        self._inbox  = []
        self._lock   = threading.Lock()
        self._closed = False
        self._disconnected = False   # set by asyncio thread on WS close

    @property
    def ip(self): return self._addr[0] if self._addr else "unknown"

    def _push(self, msg):
        with self._lock:
            self._inbox.append(msg)

    def send(self, msg):
        if self._closed:
            return False
        try:
            txt = json.dumps(msg, separators=(",",":"))
            asyncio.run_coroutine_threadsafe(self._ws.send(txt), self._loop)
            return True
        except Exception:
            return False

    def recv_all(self):
        """Returns list (never None — disconnects signalled via _disconnected)."""
        with self._lock:
            out = list(self._inbox)
            self._inbox.clear()
        return out

    def mark_disconnected(self):
        self._disconnected = True
        self._closed = True

    def close(self):
        self._closed = True
        try:
            asyncio.run_coroutine_threadsafe(self._ws.close(), self._loop)
        except Exception:
            pass


# ── Player ────────────────────────────────────────────────────────────────────

class Player:
    _next_pid = 1

    def __init__(self, conn):
        self.pid   = Player._next_pid;  Player._next_pid += 1
        self.conn  = conn
        self.name  = f"Player{self.pid}"
        self.color = random.choice([
            [220,55,55],[55,120,220],[55,195,75],[215,178,38],
            [175,55,215],[235,135,28],[240,240,240],[28,195,195],
            [255,80,160],[80,220,255],[120,255,120],[255,160,80],
        ])
        self.ready      = False
        self.muted      = False
        self.is_op      = False
        self.vote_level = None
        self.vote_mode  = None
        self.input_times= []
        self.chat_last_t= 0.0
        self.car        = None
        self.inputs     = {"gas":False,"brake":False,"left":False,"right":False,"hb":False}
        self.last_seq   = -1
        self.lap        = 0;  self.next_cp = 0
        self.lap_times  = []; self.best_lap = None
        self.lap_start  = 0.0
        self.finished   = False;  self.finish_time = None
        self.hits       = 0;  self.hit_cd = {}
        self.drift_score= 0
        self.trig_touch = {};  self.trig_active = {}

    @property
    def ip(self): return self.conn.ip

    def send(self, msg): return self.conn.send(msg)

    def recv(self):
        if isinstance(self.conn, TcpConn):
            return self.conn.recv_all()   # may return None
        return self.conn.recv_all()        # always list


# ── Server ────────────────────────────────────────────────────────────────────

class Server:

    def __init__(self, cfg, config_path):
        self.cfg         = cfg
        self.config_path = config_path
        self.levels      = load_levels(cfg["levels_dir"])
        self.players     = {}
        self.lock        = threading.Lock()
        self.state       = ST_LOBBY
        self.vote_end    = 0.0
        self.level_key   = None
        self.level_data  = None
        self.mode        = None
        self.walls       = []
        self.checkpoints = []
        self.trigger_zones = []
        self.max_laps    = 3
        self.game_start_t= 0.0
        self.game_timer  = 0.0
        self._tick_t     = 0.0
        self._running    = True
        self._ws_loop    = None   # set by WS thread

    # ── Entry point ───────────────────────────────────────────────────────────

    def run(self, ws_port):
        if self.cfg.get("log_file"):
            _set_log_file(self.cfg["log_file"])

        _log(f"[SRV]  \"{self.cfg['server_name']}\" starting")
        _log(f"[SRV]  TCP port {self.cfg['port']}  |  WS port {ws_port}")
        _log(f"[SRV]  {len(self.levels)} level(s) loaded")
        _log("[SRV]  Type 'help' for operator commands")

        # WebSocket server on background asyncio thread
        threading.Thread(target=self._run_ws_server, args=(ws_port,),
                          daemon=True).start()

        # Console on background thread
        threading.Thread(target=self._console_loop, daemon=True).start()

        # TCP accept + game tick loop on main thread
        self._run_tcp_loop()

    # ── TCP loop ──────────────────────────────────────────────────────────────

    def _run_tcp_loop(self):
        sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock.bind(("0.0.0.0", self.cfg["port"]))
        sock.listen(MAX_PLAYERS)
        sock.setblocking(False)

        last = time.time()
        while self._running:
            try:
                conn, addr = sock.accept()
                conn.setblocking(False)
                threading.Thread(target=self._tcp_join,
                                  args=(conn,addr), daemon=True).start()
            except BlockingIOError:
                pass
            except Exception as e:
                _log(f"[ERR]  TCP accept: {e}")

            now = time.time()
            dt  = min(now - last, 0.05);  last = now
            try:
                self._tick(dt)
            except Exception:
                _log("[ERR]  Tick:\n" + traceback.format_exc())
            time.sleep(1.0 / (TICK_RATE * 4))

    def _tcp_join(self, raw_sock, addr):
        ip  = addr[0]
        buf = MsgBuffer(raw_sock)
        if ip in self.cfg.get("banned_ips", []):
            buf.send({"type":"error","msg":"You are banned."})
            raw_sock.close(); return

        _log(f"[TCP]  Connection from {addr}")
        raw_sock.settimeout(10.0)
        raw = b""
        try:
            while b"\n" not in raw:
                chunk = raw_sock.recv(4096)
                if not chunk: raw_sock.close(); return
                raw += chunk
        except Exception:
            raw_sock.close(); return
        raw_sock.settimeout(None)
        raw_sock.setblocking(False)

        try:
            msg = json.loads(raw.split(b"\n")[0])
        except Exception:
            raw_sock.close(); return

        if msg.get("type") != C_JOIN:
            raw_sock.close(); return

        self._complete_join(TcpConn(raw_sock, addr), msg)

    # ── WebSocket loop ────────────────────────────────────────────────────────

    def _run_ws_server(self, ws_port):
        try:
            import websockets.asyncio.server as _wsm
        except ImportError:
            _log("[WARN] 'websockets' package not installed — browser clients disabled")
            _log("[WARN] Fix: pip install websockets")
            return

        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        self._ws_loop = loop

        async def _handler(ws):
            addr = ws.remote_address or ("unknown", 0)
            ip   = addr[0]
            if ip in self.cfg.get("banned_ips", []):
                await ws.send(json.dumps({"type":"error","msg":"You are banned."}))
                await ws.close(); return

            _log(f"[WS]   Connection from {addr}")
            try:
                raw_text = await asyncio.wait_for(ws.recv(), timeout=10.0)
            except Exception:
                await ws.close(); return

            try:
                msg = json.loads(raw_text)
            except Exception:
                await ws.close(); return

            if msg.get("type") != C_JOIN:
                await ws.close(); return

            ws_conn = WsConn(ws, loop, addr)
            player  = self._complete_join(ws_conn, msg)
            if player is None:
                await ws.close(); return

            # Receive loop — push messages into the player's inbox
            try:
                async for text in ws:
                    try:
                        ws_conn._push(json.loads(text))
                    except Exception:
                        pass
            except Exception:
                pass
            finally:
                ws_conn.mark_disconnected()
                with self.lock:
                    if player.pid in self.players:
                        self._disconnect(player.pid)

        async def _serve():
            async with _wsm.serve(_handler, "0.0.0.0", ws_port):
                _log(f"[WS]   Listening on port {ws_port}")
                await asyncio.Future()

        loop.run_until_complete(_serve())

    # ── Shared join ───────────────────────────────────────────────────────────

    def _complete_join(self, conn, msg):
        with self.lock:
            max_p          = int(self.cfg.get("max_players", MAX_PLAYERS))
            allow_mid_vote = self.cfg.get("allow_join_mid_vote", True)
            allow_mid_game = self.cfg.get("allow_join_mid_game", False)

            if len(self.players) >= max_p:
                conn.send({"type":"error","msg":"Server is full."}); return None
            if self.state == ST_RACING and not allow_mid_game:
                conn.send({"type":"error","msg":"Game in progress."}); return None
            if self.state == ST_VOTING and not allow_mid_vote:
                conn.send({"type":"error","msg":"Voting in progress."}); return None
            if self.state in (ST_COUNTDOWN, ST_RESULTS) and not allow_mid_game:
                conn.send({"type":"error","msg":"Game in progress."}); return None

            p = Player(conn)
            max_nl = int(self.cfg.get("name_max_length", 20))
            p.name = str(msg.get("name", p.name))[:max_nl].strip() or p.name
            if msg.get("color"):
                p.color = list(msg["color"])[:3]
            self.players[p.pid] = p

        level_list = [{"key":k,"name":v.get("name",k),"laps":v.get("lap_count",3)}
                       for k,v in self.levels.items()]
        p.send({"type":S_WELCOME,"pid":p.pid,
                 "server_name":self.cfg["server_name"],"level_list":level_list})

        motd = self.cfg.get("motd","").strip()
        if motd:
            p.send({"type":S_CHAT,"pid":0,"name":"[Server]","text":motd})

        for key, data in self.levels.items():
            p.send({"type":S_LEVEL_DATA,"key":key,"data":data})

        self._broadcast({"type":S_PLAYER_JOIN,"pid":p.pid,"name":p.name,"color":p.color},
                          exclude=p.pid)
        self._send_lobby()

        if self.state == ST_VOTING:
            remaining = max(0.0, self.vote_end - time.time())
            p.send({"type":S_VOTE_START,"levels":level_list,
                     "modes":[{"id":m,"label":MODE_LABELS[m],"desc":MODE_DESCS[m]} for m in MODES],
                     "duration":remaining})
            self._send_vote_update()

        tp = "WS" if isinstance(conn, WsConn) else "TCP"
        _log(f"[JOIN] {p.name} (pid={p.pid}) via {tp} from {conn.ip}")
        return p

    # ── Main tick ─────────────────────────────────────────────────────────────

    def _tick(self, dt):
        with self.lock:
            dead = []
            for pid, p in self.players.items():
                if isinstance(p.conn, TcpConn):
                    msgs = p.conn.recv_all()
                    if msgs is None:
                        dead.append(pid); continue
                else:
                    msgs = p.conn.recv_all()
                    if p.conn._disconnected:
                        dead.append(pid); continue
                for m in msgs:
                    self._handle_msg(p, m)
            for pid in dead:
                self._disconnect(pid)

            if   self.state == ST_LOBBY:     self._tick_lobby()
            elif self.state == ST_VOTING:    self._tick_voting(dt)
            elif self.state == ST_COUNTDOWN: self._tick_countdown(dt)
            elif self.state == ST_RACING:    self._tick_racing(dt)

            if self.state == ST_RACING:
                self._tick_t += dt
                if self._tick_t >= 1.0 / TICK_RATE:
                    self._tick_t = 0.0
                    self._broadcast_state()

    # ── Message handler ───────────────────────────────────────────────────────

    def _handle_msg(self, p, m):
        t = m.get("type")

        if t == C_READY:
            p.ready = True
            self._send_lobby()

        elif t == C_VOTE:
            if self.state == ST_VOTING:
                lk = m.get("level_key"); md = m.get("mode")
                if lk in self.levels: p.vote_level = lk
                if md in MODES:       p.vote_mode  = md
                self._send_vote_update()

        elif t == C_INPUT:
            if self.state == ST_RACING and p.car and not p.finished:
                now = time.time()
                if self.cfg.get("kick_on_input_flood", True):
                    thresh = int(self.cfg.get("input_flood_threshold", 60))
                    p.input_times = [x for x in p.input_times if now-x < 1.0]
                    p.input_times.append(now)
                    if len(p.input_times) > thresh:
                        _log(f"[KICK] {p.name} input flood")
                        self._kick_pid(p.pid, "Input flood"); return
                seq = m.get("seq", 0)
                if seq > p.last_seq:
                    p.last_seq = seq
                    p.inputs = {k: bool(m.get(k)) for k in ("gas","brake","left","right","hb")}

        elif t == C_CHAT:
            if not self.cfg.get("chat_enabled", True): return
            if p.muted:
                p.send({"type":S_CHAT,"pid":0,"name":"[Server]","text":"You are muted."}); return
            now  = time.time()
            rate = float(self.cfg.get("chat_rate_limit", 1.5))
            if now - p.chat_last_t < rate: return
            p.chat_last_t = now
            text = str(m.get("text",""))[:int(self.cfg.get("chat_max_length",200))]
            if not text.strip(): return
            _log(f"[CHAT] {p.name}: {text}")
            self._broadcast({"type":S_CHAT,"pid":p.pid,"name":p.name,"text":text})

        elif t == C_PONG:
            pass

    # ── State ticks ───────────────────────────────────────────────────────────

    def _tick_lobby(self):
        if not self.players: return
        min_p = int(self.cfg.get("min_players_to_start", 1))
        ready = [p for p in self.players.values() if p.ready]
        if len(ready) >= min_p and len(ready) == len(self.players):
            self._start_voting()

    def _tick_voting(self, dt):
        if time.time() >= self.vote_end:
            self._resolve_vote()

    def _tick_countdown(self, dt):
        self.game_timer -= dt
        if self.game_timer <= 0:
            self._start_game()

    def _tick_racing(self, dt):
        self.game_timer += dt
        for pid, p in self.players.items():
            if not p.car or p.finished: continue
            for i, tz in enumerate(self.trigger_zones):
                key      = f"tz_{i}"
                was      = p.trig_touch.get(key, False)
                touching = tz.rect.collidepoint(p.car.x, p.car.y)
                if not touching:
                    for cx, cy in p.car.get_corners():
                        if tz.rect.collidepoint(cx, cy): touching=True; break
                if touching and not was:
                    p.trig_active[key] = not p.trig_active.get(key, False)
                p.trig_touch[key] = touching
                if p.trig_active.get(key, False):
                    tz.apply_to_car(p.car)
            p.car.update(dict_to_keys(p.inputs), dt)
            p.drift_score = p.car.drift_score
            for wr in self.walls:
                p.car.push_out_of_rect(wr, True)
            self._check_checkpoints(p)

        if self.mode == MODE_BUMPER:
            self._detect_bumper_hits()

        if self.mode == MODE_RACE:
            timeout  = self.game_timer > float(self.cfg.get("race_timeout", RACE_TIMEOUT))
            all_done = all(p.finished for p in self.players.values() if p.car)
            if (all_done and self.players) or timeout:
                self._end_game()
        elif self.mode == MODE_BUMPER:
            if self.game_timer >= float(self.cfg.get("bumper_duration", BUMPER_DURATION)):
                self._end_game()

    # ── Voting / game ─────────────────────────────────────────────────────────

    def _start_voting(self):
        self.state    = ST_VOTING
        dur           = float(self.cfg.get("vote_duration", VOTE_DURATION))
        self.vote_end = time.time() + dur
        llist         = [{"key":k,"name":v.get("name",k)} for k,v in self.levels.items()]
        self._broadcast({"type":S_VOTE_START,"levels":llist,
                          "modes":[{"id":m,"label":MODE_LABELS[m],"desc":MODE_DESCS[m]} for m in MODES],
                          "duration":dur})
        _log("[VOTE] Voting started")

    def _send_vote_update(self):
        lv={}; mv={}
        for p in self.players.values():
            if p.vote_level: lv[p.vote_level]=lv.get(p.vote_level,0)+1
            if p.vote_mode:  mv[p.vote_mode] =mv.get(p.vote_mode, 0)+1
        self._broadcast({"type":S_VOTE_UPDATE,"level_votes":lv,"mode_votes":mv})

    def _resolve_vote(self):
        if not self.levels: _log("[WARN] No levels."); return
        lv={}; mv={}
        for p in self.players.values():
            if p.vote_level: lv[p.vote_level]=lv.get(p.vote_level,0)+1
            if p.vote_mode:  mv[p.vote_mode] =mv.get(p.vote_mode, 0)+1
        self.level_key  = max(lv,key=lv.get) if lv else random.choice(list(self.levels.keys()))
        self.mode       = max(mv,key=mv.get) if mv else MODE_RACE
        self.level_data = self.levels[self.level_key]
        _log(f"[VOTE] Result: {self.level_key}/{self.mode}")
        self._start_countdown()

    def _start_countdown(self):
        self.state      = ST_COUNTDOWN
        secs            = float(self.cfg.get("countdown_secs", COUNTDOWN_SECS))
        self.game_timer = secs
        lname           = self.level_data.get("name", self.level_key)
        self._broadcast({"type":S_COUNTDOWN,"seconds":secs,"level_key":self.level_key,
                          "level_name":lname,"mode":self.mode})
        _log(f"[SRV]  Countdown: {lname}/{MODE_LABELS.get(self.mode,self.mode)}")

    def _start_game(self):
        ld = self.level_data
        sx = float(ld.get("start_x",500)); sy=float(ld.get("start_y",500))
        sa = float(ld.get("start_angle",0))
        self.walls=[pygame.Rect(int(w["x"]),int(w["y"]),int(w["w"]),int(w["h"]))
                    for w in ld.get("walls",[])]
        self.checkpoints=[]
        for cp in ld.get("checkpoints",[]):
            if len(cp)==2: self.checkpoints.append(pygame.Rect(int(cp[0])-60,int(cp[1])-60,120,120))
            else: self.checkpoints.append(pygame.Rect(int(cp[0]),int(cp[1]),int(cp[2]),int(cp[3])))
        self.max_laps=ld.get("lap_count",3)
        self.trigger_zones=[]
        if self.cfg.get("triggers_enabled",True):
            for td in ld.get("triggers",[]):
                try: self.trigger_zones.append(ServerTriggerZone(td))
                except Exception as e: _log(f"[WARN] Trigger: {e}")

        spawns=_spawn_grid(sx,sy,sa,len(self.players)); player_list=[]
        for i,(pid,p) in enumerate(self.players.items()):
            spx,spy=spawns[i]
            p.car=CarController(spx,spy,sa,p.color)
            p.car.particle_quality="Off"; p.car.skidmarks_on=False
            p.lap=p.next_cp=0; p.lap_times=[]; p.best_lap=None
            p.finished=False; p.finish_time=None; p.hits=0; p.hit_cd={}
            p.drift_score=0; p.lap_start=time.time(); p.trig_touch={}; p.trig_active={}
            player_list.append({"pid":pid,"name":p.name,"color":p.color,"x":spx,"y":spy,"angle":sa})

        self.state=ST_RACING; self.game_timer=0.0; self.game_start_t=time.time()
        self._broadcast({"type":S_GAME_START,"level_key":self.level_key,
                          "mode":self.mode,"players":player_list})
        _log(f"[GAME] Started: {self.level_key}/{self.mode} ({len(self.players)} players)")

    def _check_checkpoints(self, p):
        if not self.checkpoints or p.next_cp>=len(self.checkpoints): return
        cp=self.checkpoints[p.next_cp]; car=p.car
        hit=cp.collidepoint(car.x,car.y)
        if not hit:
            for cx,cy in car.get_corners():
                if cp.collidepoint(cx,cy): hit=True; break
        if not hit: return
        p.next_cp+=1
        if p.next_cp>=len(self.checkpoints):
            p.lap+=1; now=time.time(); lt=now-p.lap_start
            p.lap_times.append(lt)
            if p.best_lap is None or lt<p.best_lap: p.best_lap=lt
            p.lap_start=now; p.next_cp=0
            self._broadcast({"type":S_LAP,"pid":p.pid,"lap":p.lap,"lap_time":round(lt,3)})
            _log(f"[LAP]  {p.name} Lap {p.lap} {lt:.2f}s")
            if self.mode==MODE_RACE and p.lap>=self.max_laps:
                p.finished=True; p.finish_time=time.time()-self.game_start_t
                self._broadcast({"type":S_FINISH,"pid":p.pid,"total_time":round(p.finish_time,3)})
                _log(f"[FIN]  {p.name} {p.finish_time:.2f}s")

    def _detect_bumper_hits(self):
        pids=list(self.players.keys()); now=time.time()
        for i in range(len(pids)):
            for j in range(i+1,len(pids)):
                a=self.players[pids[i]]; b=self.players[pids[j]]
                if not a.car or not b.car: continue
                dist=math.hypot(a.car.x-b.car.x,a.car.y-b.car.y)
                if dist>38: continue
                if dist>0:
                    nx=(b.car.x-a.car.x)/dist; ny=(b.car.y-a.car.y)/dist
                    push=max(0,38-dist)*0.5
                    b.car.vx+=nx*push*8; b.car.vy+=ny*push*8
                    a.car.vx-=nx*push*8; a.car.vy-=ny*push*8
                    b.car.x+=nx*push; b.car.y+=ny*push; a.car.x-=nx*push; a.car.y-=ny*push
                cd=f"{min(pids[i],pids[j])}_{max(pids[i],pids[j])}"
                if now-a.hit_cd.get(cd,0)>1.5:
                    a.hit_cd[cd]=b.hit_cd[cd]=now
                    (a if a.car.speed>=b.car.speed else b).hits+=1

    def _end_game(self):
        self.state=ST_RESULTS
        results=[]
        for pid,p in self.players.items():
            results.append({"pid":pid,"name":p.name,"color":p.color,"laps":p.lap,
                              "best_lap":round(p.best_lap,3) if p.best_lap else None,
                              "total_time":round(p.finish_time,3) if p.finish_time else None,
                              "hits":p.hits,"drift_score":p.drift_score})
        if self.mode==MODE_RACE:
            results.sort(key=lambda r:(r["total_time"] is None,r["total_time"] or 9999,-r["laps"]))
        else:
            results.sort(key=lambda r:-r["hits"])
        self._broadcast({"type":S_GAME_OVER,"results":results})
        delay=float(self.cfg.get("results_display_secs",15.0))
        _log(f"[GAME] Over — lobby reset in {delay:.0f}s")
        def _back():
            time.sleep(delay)
            with self.lock:
                if self.state==ST_RESULTS: self._reset_lobby()
        threading.Thread(target=_back,daemon=True).start()

    def _reset_lobby(self):
        self.state=ST_LOBBY; self.level_key=self.level_data=self.mode=None
        self.walls=[]; self.checkpoints=[]; self.trigger_zones=[]
        for p in self.players.values():
            p.ready=p.finished=False; p.vote_level=p.vote_mode=p.car=None
        self._send_lobby(); _log("[SRV]  Lobby reset")

    # ── Broadcast ─────────────────────────────────────────────────────────────

    def _send_lobby(self):
        snap=[{"pid":p.pid,"name":p.name,"color":p.color,"ready":p.ready}
               for p in self.players.values()]
        self._broadcast({"type":S_LOBBY,"players":snap})

    def _broadcast_state(self):
        st={}
        for pid,p in self.players.items():
            if p.car:
                st[str(pid)]={"x":round(p.car.x,1),"y":round(p.car.y,1),
                               "angle":round(p.car.angle,1),"speed":round(p.car.speed,1),
                               "lat":round(p.car.lat_speed,1),"drifting":p.car.is_drifting,
                               "boost":round(p.car.boost,2),"hits":p.hits,"lap":p.lap,
                               "next_cp":p.next_cp,"finished":p.finished,
                               "drift_score":p.drift_score}
        self._broadcast({"type":S_STATE,"players":st})

    def _broadcast(self, msg, exclude=None):
        dead=[]
        for pid,p in self.players.items():
            if pid==exclude: continue
            if not p.send(msg): dead.append(pid)
        for pid in dead: self._disconnect(pid)

    def _disconnect(self, pid):
        p=self.players.pop(pid,None)
        if p:
            try: p.conn.close()
            except: pass
            _log(f"[DISC] {p.name} (pid={pid})")
            self._broadcast({"type":S_PLAYER_LEAVE,"pid":pid})
            self._send_lobby()
            if self.state==ST_RACING and not self.players: self._reset_lobby()

    # ── Operator helpers ──────────────────────────────────────────────────────

    def _kick_pid(self, pid, reason="Kicked by operator"):
        p=self.players.get(pid)
        if p:
            p.send({"type":"error","msg":f"You were kicked: {reason}"})
            time.sleep(0.05); self._disconnect(pid)

    def _find_player(self, token):
        try:
            pid=int(token); return self.players.get(pid)
        except ValueError:
            tl=token.lower()
            for p in self.players.values():
                if p.name.lower().startswith(tl): return p
        return None

    # ── Console ───────────────────────────────────────────────────────────────

    def _console_loop(self):
        while self._running:
            try:
                line=input().strip()
            except EOFError:
                break
            except Exception:
                continue
            if not line: continue
            try:
                self._console_cmd(line)
            except Exception:
                print(f"[CMD]  Error:\n{traceback.format_exc()}")

    def _console_cmd(self, line):
        parts=line.split(None,2); cmd=parts[0].lower()

        if cmd=="help":
            print("""
  list                     list connected players (shows TCP/WS type)
  kick  <pid|name>         kick a player
  ban   <pid|name>         ban player's IP and kick
  unban <ip>               remove IP ban
  bans                     list banned IPs
  mute  <pid|name>         silence chat
  unmute <pid|name>        restore chat
  msg   <text>             broadcast server announcement
  skip                     skip voting / force-end game
  reload                   reload levels from disk
  config [key]             print config / describe key
  set   <key> <value>      change config live
  status                   server state + connection counts
  quit / exit              shutdown
""")
        elif cmd=="list":
            with self.lock:
                if not self.players: print("  (no players)"); return
                print(f"  {'PID':<5} {'Name':<20} {'IP':<16} {'Via':<5} State")
                print("  "+"-"*62)
                for p in self.players.values():
                    tags=[]
                    if p.ready:    tags.append("ready")
                    if p.muted:    tags.append("muted")
                    if p.finished: tags.append("fin")
                    via="WS" if isinstance(p.conn,WsConn) else "TCP"
                    print(f"  {p.pid:<5} {p.name:<20} {p.ip:<16} {via:<5} {','.join(tags) or '-'}")

        elif cmd=="kick":
            if len(parts)<2: print("  Usage: kick <pid|name>"); return
            with self.lock:
                p=self._find_player(parts[1])
                if not p: print(f"  Not found: {parts[1]}"); return
                reason=parts[2] if len(parts)>2 else "Kicked by operator"
                _log(f"[KICK] {p.name} — {reason}"); self._kick_pid(p.pid,reason)

        elif cmd=="ban":
            if len(parts)<2: print("  Usage: ban <pid|name>"); return
            with self.lock:
                p=self._find_player(parts[1])
                if not p: print(f"  Not found: {parts[1]}"); return
                ip=p.ip
                if ip not in self.cfg.setdefault("banned_ips",[]):
                    self.cfg["banned_ips"].append(ip); save_config(self.cfg,self.config_path)
                reason=parts[2] if len(parts)>2 else "Banned by operator"
                _log(f"[BAN]  {p.name} IP={ip}"); self._kick_pid(p.pid,reason)
                print(f"  Banned {ip}")

        elif cmd=="unban":
            if len(parts)<2: print("  Usage: unban <ip>"); return
            ip=parts[1]; bans=self.cfg.setdefault("banned_ips",[])
            if ip in bans:
                bans.remove(ip); save_config(self.cfg,self.config_path)
                _log(f"[BAN]  Unbanned {ip}"); print(f"  Unbanned {ip}")
            else: print(f"  {ip} is not banned.")

        elif cmd=="bans":
            bans=self.cfg.get("banned_ips",[])
            if bans:
                for ip in bans: print(f"    {ip}")
            else: print("  No banned IPs.")

        elif cmd=="mute":
            if len(parts)<2: print("  Usage: mute <pid|name>"); return
            with self.lock:
                p=self._find_player(parts[1])
                if not p: print(f"  Not found: {parts[1]}"); return
                p.muted=True
                p.send({"type":S_CHAT,"pid":0,"name":"[Server]","text":"You have been muted."})
                _log(f"[MUTE] {p.name}"); print(f"  Muted {p.name}")

        elif cmd=="unmute":
            if len(parts)<2: print("  Usage: unmute <pid|name>"); return
            with self.lock:
                p=self._find_player(parts[1])
                if not p: print(f"  Not found: {parts[1]}"); return
                p.muted=False
                p.send({"type":S_CHAT,"pid":0,"name":"[Server]","text":"You have been unmuted."})
                _log(f"[MUTE] {p.name} unmuted"); print(f"  Unmuted {p.name}")

        elif cmd=="msg":
            if len(parts)<2: print("  Usage: msg <text>"); return
            text=line[len(cmd):].strip(); _log(f"[MSG]  {text}")
            with self.lock:
                self._broadcast({"type":S_CHAT,"pid":0,"name":"[Server]","text":text})

        elif cmd=="skip":
            with self.lock:
                if self.state==ST_VOTING:    self.vote_end=0.0; print("  Voting skipped.")
                elif self.state==ST_RACING:  self._end_game(); print("  Game force-ended.")
                elif self.state==ST_LOBBY:   self._start_voting(); print("  Voting started.")
                else: print(f"  Nothing to skip in state: {self.state}")

        elif cmd=="reload":
            with self.lock:
                old=len(self.levels); self.levels=load_levels(self.cfg["levels_dir"])
                _log(f"[LEV]  {old}→{len(self.levels)}"); print(f"  Loaded {len(self.levels)} level(s).")

        elif cmd=="status":
            with self.lock:
                tcp=sum(1 for p in self.players.values() if isinstance(p.conn,TcpConn))
                ws =sum(1 for p in self.players.values() if isinstance(p.conn,WsConn))
                print(f"  State:   {self.state}")
                print(f"  Players: {len(self.players)}/{self.cfg.get('max_players',MAX_PLAYERS)}")
                print(f"  TCP: {tcp}  WebSocket (browser): {ws}")
                if self.level_key: print(f"  Level:   {self.level_key}")
                if self.mode:      print(f"  Mode:    {self.mode}")
                if self.state==ST_VOTING: print(f"  Vote ends: {max(0,self.vote_end-time.time()):.1f}s")
                if self.state==ST_RACING: print(f"  Game time: {self.game_timer:.1f}s")

        elif cmd=="config":
            if len(parts)>=2:
                key=parts[1]
                if key in CONFIG_HELP:
                    print(f"  {key}: {CONFIG_HELP[key]}")
                    print(f"  Current: {self.cfg.get(key)}")
                else: print(f"  Unknown key: {key}")
                return
            print(f"\n  {'Key':<30} Value"); print("  "+"-"*55)
            for k,v in self.cfg.items():
                if k=="banned_ips": print(f"  {'banned_ips':<30} [{len(v)} IP(s)]")
                else: print(f"  {k:<30} {v}")
            print()

        elif cmd=="set":
            if len(parts)<3: print("  Usage: set <key> <value>"); return
            key=parts[1]; value=parts[2]
            if key not in DEFAULT_CONFIG: print(f"  Unknown key '{key}'."); return
            if key=="banned_ips": print("  Use ban/unban instead."); return
            default=DEFAULT_CONFIG[key]
            try:
                if isinstance(default,bool):  coerced=value.lower() in ("true","1","yes","on")
                elif isinstance(default,int):  coerced=int(value)
                elif isinstance(default,float):coerced=float(value)
                else: coerced=value
            except ValueError:
                print(f"  Bad value — expected {type(default).__name__}"); return
            self.cfg[key]=coerced; save_config(self.cfg,self.config_path)
            _log(f"[CFG]  {key}={coerced!r}"); print(f"  {key} = {coerced!r}  (saved)")
            if key=="log_file": _set_log_file(coerced)

        elif cmd in ("quit","exit"):
            _log("[SRV]  Operator shutdown")
            with self.lock:
                self._broadcast({"type":S_CHAT,"pid":0,"name":"[Server]",
                                  "text":"Server is shutting down."})
            self._running=False; sys.exit(0)

        else:
            print(f"  Unknown command '{cmd}'. Type 'help'.")


# ── Entry point ───────────────────────────────────────────────────────────────

if __name__=="__main__":
    ap=argparse.ArgumentParser(description="Drift Master Multiplayer Server")
    ap.add_argument("--port",   type=int, default=None, help="TCP port (desktop clients)")
    ap.add_argument("--wsport", type=int, default=None, help="WebSocket port (browser clients)")
    ap.add_argument("--levels", type=str, default=None, help="Levels directory")
    ap.add_argument("--config", type=str, default=CONFIG_FILE)
    args=ap.parse_args()

    cfg=load_config(args.config)
    if args.port:   cfg["port"]       = args.port
    if args.levels: cfg["levels_dir"] = args.levels
    ws_port=args.wsport if args.wsport else cfg.get("ws_port", WS_PORT_DEFAULT)

    Server(cfg, args.config).run(ws_port)