"""mainmenu.py – Da Drifting Game"""
import pygame, sys, os, math, random, json
from settings import SaveData

LEVELS_DIR = "levels"

CAR_COLORS = [
    ((220,55,55),  "RED"),
    ((55,120,220), "BLUE"),
    ((55,195,75),  "GREEN"),
    ((215,178,38), "GOLD"),
    ((175,55,215), "PURPLE"),
    ((235,135,28), "ORANGE"),
    ((240,240,240),"WHITE"),
    ((28,195,195), "CYAN"),
]


def list_levels():
    out=[]
    if not os.path.isdir(LEVELS_DIR): return out
    for fn in sorted(os.listdir(LEVELS_DIR)):
        if fn.endswith(".lev"):
            p=os.path.join(LEVELS_DIR,fn)
            try:
                d=json.load(open(p))
                out.append({"path":p,"key":fn,"name":d.get("name",fn),
                            "laps":d.get("lap_count",3),"target":d.get("target_score",0)})
            except Exception: pass
    return out


# ── Btn ───────────────────────────────────────────────────────────────────────

class Btn:
    def __init__(self,x,y,w,h,text,col=(55,75,115),hov=(78,108,178)):
        self.r=pygame.Rect(x,y,w,h);self.text=text;self.col=col;self.hov=hov
    def draw(self,surf,font,mouse):
        hv=self.r.collidepoint(mouse)
        pygame.draw.rect(surf,(0,0,0,75),self.r.move(3,4),border_radius=9)
        pygame.draw.rect(surf,self.hov if hv else self.col,self.r,border_radius=9)
        pygame.draw.rect(surf,(182,202,252) if hv else (86,106,152),self.r,2,border_radius=9)
        img=font.render(self.text,True,(238,238,238))
        surf.blit(img,img.get_rect(center=self.r.center))
    def clicked(self,mouse,evs):
        return self.r.collidepoint(mouse) and \
               any(e.type==pygame.MOUSEBUTTONDOWN and e.button==1 for e in evs)


# ── Bg particles ──────────────────────────────────────────────────────────────

class BgParts:
    def __init__(self,sw,sh):
        self.sw,self.sh=sw,sh
        self.pts=[self._n(random.randint(0,sw),random.randint(0,sh)) for _ in range(65)]
    def _n(self,x=None,y=None):
        return{"x":x or random.randint(0,self.sw),"y":y or self.sh+6,
               "vy":random.uniform(-.45,-1.05),"vx":random.uniform(-.3,.3),
               "sz":random.uniform(1,4),"a":random.randint(25,115),
               "col":random.choice([(215,55,55),(55,118,215),(255,195,42),(72,195,92)])}
    def update(self):
        for i,p in enumerate(self.pts):
            p["x"]+=p["vx"];p["y"]+=p["vy"]
            if p["y"]<-8: self.pts[i]=self._n()
    def draw(self,surf):
        for p in self.pts:
            sz=int(p["sz"]);s=pygame.Surface((sz*2+2,sz*2+2),pygame.SRCALPHA)
            r,g,b=p["col"];pygame.draw.circle(s,(r,g,b,p["a"]),(sz+1,sz+1),sz)
            surf.blit(s,(int(p["x"])-sz-1,int(p["y"])-sz-1))


# ── mini car ─────────────────────────────────────────────────────────────────

def draw_mini_car(surf,cx,cy,color,angle,size=1.0):
    w,h=int(22*size),int(36*size);p2=4;br=max(2,int(5*size))
    s=pygame.Surface((w+8,h+8),pygame.SRCALPHA)
    r,g,b=color
    pygame.draw.rect(s,(r,g,b),(p2,p2,w,h),border_radius=br)
    roof=tuple(min(255,c+35) for c in (r,g,b))
    rfw=max(3,int(w*.56));rfh=max(2,int(h*.38))
    pygame.draw.rect(s,roof,(p2+(w-rfw)//2,p2+int(h*.10),rfw,rfh),border_radius=max(2,br-2))
    ww=max(3,int(w*.62));wh=max(2,int(h*.20))
    pygame.draw.rect(s,(165,222,255,200),(p2+(w-ww)//2,p2+int(h*.13),ww,wh),border_radius=max(2,br-3))
    lw=max(2,int(w*.23));lh2=max(2,int(h*.07));ly=p2+h-lh2-2
    pygame.draw.rect(s,(255,40,40),(p2+2,ly,lw,lh2),border_radius=2)
    pygame.draw.rect(s,(255,40,40),(p2+w-lw-2,ly,lw,lh2),border_radius=2)
    pygame.draw.rect(s,(255,242,185),(p2+2,p2+2,lw,lh2),border_radius=2)
    pygame.draw.rect(s,(255,242,185),(p2+w-lw-2,p2+2,lw,lh2),border_radius=2)
    rot=pygame.transform.rotate(s,-angle)
    surf.blit(rot,rot.get_rect(center=(cx,cy)))


# ── MainMenu ──────────────────────────────────────────────────────────────────

class MainMenu:
    def __init__(self,screen,sd:SaveData):
        self.screen=screen;self.sd=sd
        self.clock=pygame.time.Clock()
        self.sw,self.sh=screen.get_size()
        self.fT=pygame.font.SysFont("consolas",62,bold=True)
        self.fS=pygame.font.SysFont("consolas",18,bold=True)
        self.fB=pygame.font.SysFont("consolas",21,bold=True)
        self.fm=pygame.font.SysFont("consolas",14,bold=True)
        self.ft=pygame.font.SysFont("consolas",13)
        self.state="main"
        self.sel_level=sd.prefs.get("selected_level",0)
        self.sel_car  =sd.prefs.get("selected_car",  0)
        self.levels=list_levels()
        if self.sel_level>=len(self.levels): self.sel_level=0
        if self.sel_car  >=len(CAR_COLORS):  self.sel_car  =0
        self.bg=BgParts(self.sw,self.sh)
        self.t=0.0
        self._mk_btns()

    def _mk_btns(self):
        cx=self.sw//2; bw,bh,gap=282,51,13; y0=245
        self.mbtns=[
            Btn(cx-bw//2, y0+0*(bh+gap), bw, bh, "RACE",
                (50,96,50),   (70,145,70)),
            Btn(cx-bw//2, y0+1*(bh+gap), bw, bh, "MULTIPLAYER",
                (38,78,98),   (55,118,148)),
            Btn(cx-bw//2, y0+2*(bh+gap), bw, bh, "SELECT CAR",
                (50,50,110),  (70,70,170)),
            Btn(cx-bw//2, y0+3*(bh+gap), bw, bh, "LEVEL CREATOR",
                (96,50,50),   (145,70,70)),
            Btn(cx-bw//2, y0+4*(bh+gap), bw, bh, "SETTINGS",
                (50,76,96),   (70,116,145)),
            Btn(cx-bw//2, y0+5*(bh+gap), bw, bh, "CONTROLS",
                (50,76,76),   (70,116,116)),
            Btn(cx-bw//2, y0+6*(bh+gap), bw, bh, "QUIT",
                (76,34,34),   (132,50,50)),
        ]

    def _save_prefs(self):
        self.sd.prefs["selected_car"]  =self.sel_car
        self.sd.prefs["selected_level"]=self.sel_level
        self.sd.save()

    def run(self):
        from controller import pump_controller_events, nav_input, MenuNavigator, show_keyboard
        ctrl_nav = MenuNavigator(len(self.mbtns))

        while True:
            dt  = self.clock.tick(60)/1000.0; self.t += dt
            inp = pump_controller_events(dt)
            nav = nav_input(dt)
            evs = pygame.event.get()
            mouse = pygame.mouse.get_pos()

            for ev in evs:
                if ev.type == pygame.QUIT: pygame.quit(); sys.exit()
                if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                    if self.state != "main": self.state = "main"

            # Controller B = back to main
            if nav.menu_back and self.state != "main":
                self.state = "main"

            self.bg.update()

            # Controller navigation on main menu
            fake_evs = list(evs)
            if self.state == "main" and inp.controller_active:
                ctrl_nav.num_items = len(self.mbtns)
                action = ctrl_nav.update(nav)
                if action == "confirm" and 0 <= ctrl_nav.index < len(self.mbtns):
                    btn_rect = self.mbtns[ctrl_nav.index].r
                    fake_ev = pygame.event.Event(pygame.MOUSEBUTTONDOWN,
                                                  {"button": 1, "pos": btn_rect.center})
                    fake_evs.append(fake_ev)
                    mouse = btn_rect.center
                # Track mouse hover → sync ctrl_nav index
            elif not inp.controller_active:
                for i, b in enumerate(self.mbtns):
                    if b.r.collidepoint(mouse):
                        ctrl_nav.index = i

            if   self.state == "main":     res = self._main(mouse, fake_evs, ctrl_nav=ctrl_nav, ctrl_active=inp.controller_active)
            elif self.state == "levels":   res = self._levels(mouse, fake_evs)
            elif self.state == "cars":     res = self._cars(mouse, fake_evs)
            elif self.state == "controls": res = self._controls(mouse, fake_evs)
            else: res = None
            pygame.display.flip()
            if res is not None: return res

    def _bg_draw(self):
        self.screen.fill((13,16,26))
        gs=pygame.Surface((self.sw,self.sh),pygame.SRCALPHA);gsz=56
        ox=int(self.t*16)%gsz;oy=int(self.t*8)%gsz
        for x in range(-gsz,self.sw+gsz,gsz):
            pygame.draw.line(gs,(25,35,54,62),(x-ox,0),(x-ox,self.sh))
        for y in range(-gsz,self.sh+gsz,gsz):
            pygame.draw.line(gs,(25,35,54,62),(0,y-oy),(self.sw,y-oy))
        self.screen.blit(gs,(0,0));self.bg.draw(self.screen)

    def _title(self):
        pulse=abs(math.sin(self.t*1.8))*6
        gw=self.fT.render("DA DRIFTING GAME",True,(190,50,24))
        for off in ((4,5),(2,3)):
            self.screen.blit(gw,(self.sw//2-gw.get_width()//2+off[0],65+off[1]))
        tw=self.fT.render("DA DRIFTING GAME",True,(255,110,50))
        self.screen.blit(tw,(self.sw//2-tw.get_width()//2,65))
        sub=self.fS.render("THE DRIFTING EXPERIENCE",True,(128,150,192))
        self.screen.blit(sub,(self.sw//2-sub.get_width()//2,142))
        ul=int(400+pulse*3)
        pygame.draw.line(self.screen,(200,72,34),(self.sw//2-ul//2,168),(self.sw//2+ul//2,168),3)

    def _main(self, mouse, evs, ctrl_nav=None, ctrl_active=False):
        self._bg_draw(); self._title()
        for i in range(3):
            ang=math.degrees(math.atan2(math.cos(self.t*.36+i*2),math.sin(self.t*.36+i*2)))+90
            bx=int(self.sw//2+math.sin(self.t*.36+i*2)*348)
            by=int(205+math.cos(self.t*.28+i)*25+i*102)
            draw_mini_car(self.screen,bx,by,[(214,54,54),(54,116,214),(255,194,40)][i],ang)
        cc=CAR_COLORS[self.sel_car][0]
        draw_mini_car(self.screen,self.sw-88,88,cc,math.sin(self.t*1.5)*18,1.1)
        cn=self.ft.render(CAR_COLORS[self.sel_car][1],True,(165,165,165))
        self.screen.blit(cn,(self.sw-88-cn.get_width()//2,133))

        for btn in self.mbtns:
            btn.draw(self.screen,self.fB,mouse)
            if btn.clicked(mouse,evs):
                t=btn.text
                if   t=="RACE":           self.levels and self._set_state("levels")
                elif t=="MULTIPLAYER":    return("multiplayer",None,None,None)
                elif t=="SELECT CAR":     self.state="cars"
                elif t=="LEVEL CREATOR":  return("creator",None,None,None)
                elif t=="SETTINGS":       return("settings",None,None,None)
                elif t=="CONTROLS":       self.state="controls"
                elif t=="QUIT":           self._save_prefs();pygame.quit();sys.exit()

        # Controller cursor
        if ctrl_active and ctrl_nav is not None and self.mbtns:
            ctrl_nav.num_items = len(self.mbtns)
            first = self.mbtns[0].r
            ctrl_nav.draw_cursor(self.screen, x=first.left, y=first.top,
                                  item_height=first.height + 13)
            hint_txt = "D-pad/stick=navigate   A=select   B=back"
        else:
            hint_txt = "Da Drifting Game v1.2   |   ESC = back"

        if not self.levels:
            nl=self.fm.render("No .lev files found \u2013 use Level Creator!",True,(190,86,86))
            self.screen.blit(nl,(self.sw//2-nl.get_width()//2,self.sh-35))
        ver=self.ft.render(hint_txt,True,(50,54,70))
        self.screen.blit(ver,(10,self.sh-17))
        return None

    def _set_state(self, s):
        self.state = s

    def _levels(self,mouse,evs):
        self._bg_draw(); self._title()
        sw,sh=self.sw,self.sh
        ROWS=6; ROW_H=68; px=sw//2-310; pw=620; y_start=210
        total=len(self.levels)
        pages=max(1,(total+ROWS-1)//ROWS)
        if not hasattr(self,'_level_page'): self._level_page=0
        self._level_page=max(0,min(pages-1,self._level_page))
        page_start=self._level_page*ROWS

        ttl=self.fB.render("SELECT LEVEL",True,(202,190,94))
        self.screen.blit(ttl,(sw//2-ttl.get_width()//2,y_start-24))
        if pages>1:
            pg=self.ft.render(f"Page {self._level_page+1} / {pages}",True,(130,135,158))
            self.screen.blit(pg,(sw//2-pg.get_width()//2,y_start-6))

        for slot in range(ROWS):
            i=page_start+slot
            if i>=total: break
            lvl=self.levels[i]; sel=(i==self.sel_level)
            ry=y_start+slot*ROW_H
            r=pygame.Rect(px,ry,pw,ROW_H-6); hov=r.collidepoint(mouse)
            bg=(64,90,64) if sel else (32,39,50)
            if hov: bg=(80,112,80) if sel else (44,54,68)
            pygame.draw.rect(self.screen,bg,r,border_radius=9)
            pygame.draw.rect(self.screen,(140,206,94) if sel else (66,84,66),
                              r,2 if not sel else 3,border_radius=9)
            idx_t=self.fm.render(str(i+1),True,(160,165,185))
            self.screen.blit(idx_t,(px+10,ry+ROW_H//2-idx_t.get_height()//2-6))
            ox=36
            self.screen.blit(self.fB.render(lvl["name"],True,
                              (238,234,190) if sel else (170,170,170)),(px+ox,ry+8))
            self.screen.blit(self.ft.render(
                f"Laps: {lvl['laps']}   Target: {lvl['target']:,} pts",
                True,(130,152,130)),(px+ox,ry+30))
            st=self.sd.get_level_stats(lvl["key"])
            if st["races"]>0:
                parts=[]
                if st["best_lap"]:   parts.append(f"Best {st['best_lap']:.2f}s")
                if st["best_score"]: parts.append(f"Score {st['best_score']:,}")
                parts.append(f"×{st['races']}")
                stat_txt=self.ft.render("  ".join(parts),True,(100,188,180))
                self.screen.blit(stat_txt,(px+pw-stat_txt.get_width()-10,ry+30))
            for ev in evs:
                if ev.type==pygame.MOUSEBUTTONDOWN and ev.button==1 and hov:
                    self.sel_level=i

        bot_y=y_start+ROWS*ROW_H+4
        if pages>1:
            prev_r=pygame.Rect(px,bot_y,120,36)
            next_r=pygame.Rect(px+pw-120,bot_y,120,36)
            for r2,lbl2,delta in [(prev_r,"◄ PREV",-1),(next_r,"NEXT ►",+1)]:
                can=(self._level_page+delta)>=0 and (self._level_page+delta)<pages
                col2=(45,55,75) if can else (28,32,45)
                hcol2=(65,80,115) if can else (28,32,45)
                hov2=r2.collidepoint(mouse) and can
                pygame.draw.rect(self.screen,hcol2 if hov2 else col2,r2,border_radius=7)
                pygame.draw.rect(self.screen,(80,90,120) if can else (40,44,58),r2,2,border_radius=7)
                lt=self.fm.render(lbl2,True,(210,210,220) if can else (80,84,100))
                self.screen.blit(lt,lt.get_rect(center=r2.center))
                for ev in evs:
                    if ev.type==pygame.MOUSEBUTTONDOWN and ev.button==1 and hov2:
                        self._level_page+=delta
            for p in range(min(pages,20)):
                dot_x=sw//2-min(pages,20)*8+p*16
                dot_col=(140,206,94) if p==self._level_page else (55,62,80)
                pygame.draw.circle(self.screen,dot_col,(dot_x,bot_y+18),
                                    5 if p==self._level_page else 3)

        btn_y=sh-56
        sb=Btn(sw//2-145,btn_y,290,46,"START RACE!",(50,112,50),(70,172,70))
        sb.draw(self.screen,self.fB,mouse)
        if sb.clicked(mouse,evs) and self.levels and self.sel_level<len(self.levels):
            lvl=self.levels[self.sel_level]
            self._save_prefs()
            return("race",lvl["path"],lvl["key"],CAR_COLORS[self.sel_car][0])

        bb=Btn(18,btn_y,110,38,"◄ BACK",(54,34,34),(92,50,50))
        bb.draw(self.screen,self.fm,mouse)
        if bb.clicked(mouse,evs): self.state="main"

        ct=self.ft.render(f"{total} level{'s' if total!=1 else ''} found",True,(80,85,100))
        self.screen.blit(ct,(sw-ct.get_width()-14,btn_y+12))
        return None

    def _cars(self,mouse,evs):
        self._bg_draw()
        ttl=self.fB.render("SELECT YOUR CAR",True,(202,190,94))
        self.screen.blit(ttl,(self.sw//2-ttl.get_width()//2,50))
        cols=4;sz=136;gap=16;tw2=cols*sz+(cols-1)*gap
        sx0=self.sw//2-tw2//2;sy0=100
        for i,(color,name) in enumerate(CAR_COLORS):
            row=i//cols;col=i%cols;x=sx0+col*(sz+gap);y=sy0+row*(sz+gap)
            sel=(i==self.sel_car);r=pygame.Rect(x,y,sz,sz);hov=r.collidepoint(mouse)
            bg=(44,64,44) if sel else (25,30,40)
            if hov: bg=(56,76,56) if sel else (34,44,56)
            pygame.draw.rect(self.screen,bg,r,border_radius=11)
            pygame.draw.rect(self.screen,(140,210,90) if sel else (54,64,76),
                              r,2 if not sel else 3,border_radius=11)
            draw_mini_car(self.screen,x+sz//2,y+sz//2-10,color,
                           math.sin(self.t*1.5+i)*14 if sel else 0)
            nt=self.fm.render(name,True,(215,215,215) if sel else (132,132,132))
            self.screen.blit(nt,(x+sz//2-nt.get_width()//2,y+sz-21))
            for ev in evs:
                if ev.type==pygame.MOUSEBUTTONDOWN and ev.button==1 and hov:
                    self.sel_car=i;self._save_prefs()
        bb=Btn(18,self.sh-55,110,38,"◄ BACK",(54,34,34),(92,50,50))
        bb.draw(self.screen,self.fm,mouse)
        if bb.clicked(mouse,evs): self.state="main"
        return None

    def _controls(self,mouse,evs):
        self._bg_draw()
        ttl=self.fB.render("CONTROLS",True,(202,190,94))
        self.screen.blit(ttl,(self.sw//2-ttl.get_width()//2,50))
        rows=[
            ("W / ↑",      "Accelerate"),
            ("S / ↓",      "Brake  (hold to reverse)"),
            ("A / ←",      "Steer Left"),
            ("D / →",      "Steer Right"),
            ("SPACE",      "Handbrake  →  Drift!"),
            ("P",          "Pause / Unpause"),
            ("R",          "Reset car to start"),
            ("ESC",        "Back to menu"),
            ("ENTER",      "Open / send chat (multiplayer)"),
            ("",""),
            ("DRIFT TIP:", "Build up speed, then tap SPACE into a corner."),
            ("",           "Counter-steer with A/D to hold the angle."),
            ("",           "The longer you hold the drift, the higher the multiplier!"),
        ]
        ph=len(rows)*35+22
        panel=pygame.Surface((548,ph),pygame.SRCALPHA);panel.fill((0,0,0,145))
        pygame.draw.rect(panel,(72,78,94,190),(0,0,548,ph),2,border_radius=10)
        self.screen.blit(panel,(self.sw//2-274,100))
        for i,(key,desc) in enumerate(rows):
            y=110+i*35
            if key: self.screen.blit(self.fB.render(key,True,(255,210,90)),(self.sw//2-260,y))
            if desc: self.screen.blit(self.fm.render(desc,True,(198,198,198)),(self.sw//2-6,y+2))
        bb=Btn(18,self.sh-55,110,38,"◄ BACK",(54,34,34),(92,50,50))
        bb.draw(self.screen,self.fm,mouse)
        if bb.clicked(mouse,evs): self.state="main"
        return None