"""
multiplayer_client.py  –  Drift Master Multiplayer Client

Accessed via the MULTIPLAYER button in the main menu.
Connects to a server, receives all level data (no local levels needed),
goes through lobby → voting → countdown → game → results.
"""
import pygame, sys, math, json, socket, threading, time, random, os
sys.path.insert(0, os.path.dirname(__file__))

from network import (
    DEFAULT_PORT,
    MODE_RACE, MODE_BUMPER, MODE_LABELS, MODE_DESCS, MODES,
    BUMPER_DURATION,
    S_WELCOME, S_LEVEL_DATA, S_PLAYER_JOIN, S_PLAYER_LEAVE,
    S_LOBBY, S_VOTE_START, S_VOTE_UPDATE, S_COUNTDOWN,
    S_GAME_START, S_STATE, S_LAP, S_FINISH, S_GAME_OVER,
    S_CHAT, S_PING,
    C_JOIN, C_READY, C_VOTE, C_INPUT, C_CHAT, C_PONG,
    MsgBuffer,
)
from carcontroller import CarController

# ── State machine ─────────────────────────────────────────────────────────────
CS_CONNECT  = "connect"
CS_LOBBY    = "lobby"
CS_VOTING   = "voting"
CS_COUNTDOWN= "countdown"
CS_RACING   = "racing"
CS_RESULTS  = "results"
CS_ERROR    = "error"

# ── Colours ───────────────────────────────────────────────────────────────────
COL_BG       = (13, 16, 26)
COL_PANEL    = (20, 24, 38)
COL_BORDER   = (55, 62, 88)
COL_GOLD     = (205, 192, 92)
COL_GREEN    = (55, 195, 75)
COL_RED      = (215, 55, 55)
COL_BLUE     = (80, 165, 255)
COL_WHITE    = (235, 235, 235)
COL_GREY     = (135, 138, 155)
COL_CHAT_BG  = (10, 12, 22, 200)

CAR_COLORS = [
    ([220,55,55],  "RED"),    ([55,120,220], "BLUE"),
    ([55,195,75],  "GREEN"),  ([215,178,38], "GOLD"),
    ([175,55,215], "PURPLE"), ([235,135,28], "ORANGE"),
    ([240,240,240],"WHITE"),  ([28,195,195], "CYAN"),
]


# ── RemoteCar ─────────────────────────────────────────────────────────────────

class RemoteCar:
    """Smoothly interpolated remote player car."""
    INTERP = 12.0   # lerp speed

    def __init__(self, pid, name, color, x, y, angle):
        self.pid      = pid
        self.name     = name
        self.color    = tuple(color)
        self.x        = float(x)
        self.y        = float(y)
        self.angle    = float(angle)
        self.tx       = float(x)   # target (from server)
        self.ty       = float(y)
        self.tangle   = float(angle)
        self.speed    = 0.0
        self.drifting = False
        self.boost    = 0.0
        self.hits     = 0
        self.lap      = 0
        self.finished = False
        self.drift_score = 0
        # Reuse CarController just for drawing
        self._draw_car = CarController(x, y, angle, color)
        self._draw_car.particle_quality = "Low"
        self._draw_car.skidmarks_on     = False

    def server_update(self, d):
        self.tx       = float(d["x"])
        self.ty       = float(d["y"])
        self.tangle   = float(d["angle"])
        self.speed    = float(d.get("speed", 0))
        self.drifting = bool(d.get("drifting", False))
        self.boost    = float(d.get("boost", 0))
        self.hits     = int(d.get("hits", 0))
        self.lap      = int(d.get("lap", 0))
        self.finished = bool(d.get("finished", False))
        self.drift_score = int(d.get("drift_score", 0))

    def update(self, dt):
        a = min(1.0, dt * self.INTERP)
        self.x     += (self.tx - self.x)     * a
        self.y     += (self.ty - self.y)     * a
        # Angle lerp (handle wrap-around)
        da = (self.tangle - self.angle + 540) % 360 - 180
        self.angle += da * a
        # Mirror into draw car
        self._draw_car.x          = self.x
        self._draw_car.y          = self.y
        self._draw_car.angle      = self.angle
        self._draw_car.speed      = self.speed
        self._draw_car.is_drifting= self.drifting
        self._draw_car.boost      = self.boost
        self._draw_car.lat_speed  = 80.0 if self.drifting else 0.0

    def draw(self, surf, cx, cy, zoom):
        self._draw_car.draw(surf, cx, cy, zoom)


# ── Background builder (same as main.py) ─────────────────────────────────────

def build_bg(ld):
    gc = tuple(ld.get("grass_color", [38, 88, 48]))
    tc = tuple(ld.get("track_color", [72, 76, 82]))
    cc = tuple(ld.get("curb_color",  [210, 50, 50]))
    walls = ld.get("walls", [])
    decs  = ld.get("decorations", [])
    PADDING = 1200

    if walls:
        xs = [w["x"] for w in walls] + [w["x"]+w["w"] for w in walls]
        ys = [w["y"] for w in walls] + [w["y"]+w["h"] for w in walls]
    else:
        sx0 = ld.get("start_x", 500); sy0 = ld.get("start_y", 500)
        xs = [sx0]; ys = [sy0]
    for d in decs:
        r = d.get("r", 30)
        xs += [d["x"]-r, d["x"]+r]; ys += [d["y"]-r, d["y"]+r]

    ox = int(min(xs)) - PADDING;  oy = int(min(ys)) - PADDING
    W  = int(max(xs)) - int(min(xs)) + PADDING*2
    H  = int(max(ys)) - int(min(ys)) + PADDING*2
    bg = pygame.Surface((W, H))
    bg.fill(gc)

    def rr(obj):
        return (int(obj["x"])-ox, int(obj["y"])-oy, int(obj["w"]), int(obj["h"]))

    for w in walls:
        if w.get("is_outer", True): pygame.draw.rect(bg, tc, rr(w))
    for w in walls:
        if not w.get("is_outer", True): pygame.draw.rect(bg, gc, rr(w))
    for d in decs:
        col = tuple(d.get("color", [40,80,50]))
        lx = int(d["x"])-ox; ly = int(d["y"])-oy
        if d["type"]=="rect":
            pygame.draw.rect(bg, col, (lx, ly, int(d["w"]), int(d["h"])))
        elif d["type"]=="circle":
            pygame.draw.circle(bg, col, (lx, ly), int(d.get("r",30)))
    for w in walls:
        pygame.draw.rect(bg, cc, rr(w), 6)
    return bg, ox, oy


# ── Chat box ──────────────────────────────────────────────────────────────────

class ChatBox:
    MAX = 20

    def __init__(self):
        self.messages = []   # (name, text, color, age)
        self.input    = ""
        self.active   = False
        self.font     = None

    def _ensure_font(self):
        if not self.font:
            self.font = pygame.font.SysFont("consolas", 13)

    def add(self, name, text, color=(200,200,200)):
        self.messages.append([name, text, list(color), 8.0])
        if len(self.messages) > self.MAX:
            self.messages.pop(0)

    def update(self, dt):
        for m in self.messages:
            m[3] -= dt
        self.messages = [m for m in self.messages if m[3] > 0]

    def handle_key(self, ev):
        """Returns text to send (or None). Call on KEYDOWN events."""
        if ev.key == pygame.K_RETURN:
            if self.active:
                t = self.input.strip()
                self.input  = ""
                self.active = False
                return t if t else None
            else:
                self.active = True
        elif self.active:
            if ev.key == pygame.K_ESCAPE:
                self.active = False; self.input = ""
            elif ev.key == pygame.K_BACKSPACE:
                self.input = self.input[:-1]
            elif ev.unicode.isprintable() and len(self.input) < 80:
                self.input += ev.unicode
        return None

    def draw(self, surf, x, y, w):
        self._ensure_font()
        f = self.font
        visible = self.messages[-8:]
        for i, (name, text, col, age) in enumerate(visible):
            a = min(255, int(age * 80))
            line = f"{name}: {text}" if name else text
            img  = f.render(line, True, tuple(col))
            img.set_alpha(a)
            surf.blit(img, (x, y - (len(visible)-i)*16))
        if self.active:
            ibox = pygame.Rect(x, y+4, w, 20)
            pygame.draw.rect(surf, (20,24,38,220), ibox, border_radius=4)
            pygame.draw.rect(surf, (70,80,110),    ibox, 1, border_radius=4)
            prompt = f.render("> " + self.input + "_", True, (220,220,200))
            surf.blit(prompt, (x+4, y+6))


# ── Main client class ─────────────────────────────────────────────────────────

class MultiplayerClient:

    def __init__(self, screen, sd, my_name, my_color, host, port, ws_port=7778):
        self.screen    = screen
        self.sd        = sd
        self.sw, self.sh = screen.get_size()
        self.my_name   = my_name
        self.my_color  = list(my_color)
        self.host      = host
        self.port      = port
        self.ws_port   = ws_port   # WebSocket port for browser clients
        self.clock     = pygame.time.Clock()

        # Fonts
        self.fT = pygame.font.SysFont("consolas", 36, bold=True)
        self.fB = pygame.font.SysFont("consolas", 22, bold=True)
        self.fM = pygame.font.SysFont("consolas", 17, bold=True)
        self.fS = pygame.font.SysFont("consolas", 14, bold=True)
        self.ft = pygame.font.SysFont("consolas", 13)

        # Network
        self.sock   = None
        self.buf    = None
        self.my_pid = None
        self._net_lock = threading.Lock()

        # State
        self.state      = CS_CONNECT
        self.error_msg  = ""
        self.lobby_players = []   # [{pid,name,color,ready}]

        # Voting
        self.vote_levels    = []   # [{key,name}]
        self.vote_modes     = []   # [{id,label,desc}]
        self.my_vote_level  = None
        self.my_vote_mode   = None
        self.vote_level_counts = {}
        self.vote_mode_counts  = {}
        self.vote_end_t     = 0.0
        self.vote_duration  = 20.0
        # Built each frame by _draw_voting(), read by _handle_vote_clicks()
        self._vote_level_rects = {}
        self._vote_mode_rects  = {}

        # Countdown
        self.countdown_secs  = 5.0
        self.countdown_level = ""
        self.countdown_mode  = ""
        self.countdown_start = 0.0

        # Game
        self.level_key   = None
        self.level_data  = None
        self.mode        = None
        self.bg_surf     = None
        self.bg_ox = self.bg_oy = 0
        self.levels_cache = {}   # key → level dict (received from server)

        # My car (local prediction)
        self.my_car      = None
        self.cam_x = self.cam_y = 0.0
        self.zoom        = 1.0
        self.target_zoom = 1.0

        # Remote cars
        self.remote_cars = {}   # pid → RemoteCar (everyone including me for rendering)
        self.all_players = {}   # pid → {name, color}

        # Results
        self.results     = []

        # Input sequence number
        self._input_seq  = 0
        self._last_input = {}

        # Walls for local collision prediction
        self.walls = []

        # Checkpoints for local display
        self.checkpoints = []
        self.max_laps    = 3
        self.my_next_cp  = 0
        self.my_lap      = 0

        # Client-side trigger active state (mirrors server per-player toggle)
        # keyed by trigger index → bool
        self._client_trig_active = {}
        self._client_trig_touch  = {}

        # Game timer (bumper cars)
        self.game_start_t = 0.0

        # Chat
        self.chat = ChatBox()

        # Shake
        self.shake = 0.0

        # Input seq
        self._seq = 0

    # ── Connection ────────────────────────────────────────────────────────────

    # Whether we're running inside Pygbag (browser WebAssembly)
    IS_WEB = sys.platform == "emscripten"

    def connect(self):
        if self.IS_WEB:
            return self._connect_ws()
        return self._connect_tcp()

    def _connect_tcp(self):
        """Desktop: plain TCP socket."""
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            s.settimeout(5.0)
            s.connect((self.host, self.port))
            s.settimeout(None)
            s.setblocking(False)
            self.sock = s
            self.buf  = MsgBuffer(s)
            self._send({"type": C_JOIN,
                            "name": self.my_name,
                            "color": self.my_color})
            return True
        except Exception as e:
            self.error_msg = f"Could not connect to {self.host}:{self.port}\n{e}"
            self.state = CS_ERROR
            return False

    def _connect_ws(self):
        """
        Browser: connect via the browser's native WebSocket API through
        Pygbag's platform.window bridge.

        Automatically uses wss:// when the page is served over HTTPS,
        and ws:// when served over HTTP — matching the browser's security
        requirements so the connection is never blocked.
        """
        try:
            import platform

            # Auto-detect the correct scheme based on page protocol.
            # window.location.protocol is "https:" or "http:".
            # We let JS decide so this works whether hosted locally or on a
            # live HTTPS site without any extra config from the player.
            js_code = f"""
(function() {{
    // Clean up any previous connection
    if (window._drift_ws) {{
        try {{ window._drift_ws.close(); }} catch(e) {{}}
        window._drift_ws = null;
    }}
    window._drift_ws_inbox  = [];
    window._drift_ws_closed = false;
    window._drift_ws_error  = null;

    // Choose ws:// or wss:// to match the page protocol
    var scheme = (window.location.protocol === 'https:') ? 'wss' : 'ws';
    var url = scheme + '://{self.host}:{self.ws_port}';
    console.log('[Drift] Connecting to ' + url);

    var ws = new WebSocket(url);
    ws.onopen = function() {{
        console.log('[Drift] WebSocket connected');
    }};
    ws.onmessage = function(evt) {{
        window._drift_ws_inbox.push(evt.data);
    }};
    ws.onclose = function(evt) {{
        console.log('[Drift] WebSocket closed, code=' + evt.code);
        window._drift_ws_closed = true;
    }};
    ws.onerror = function(evt) {{
        console.error('[Drift] WebSocket error');
        window._drift_ws_error  = 'WebSocket error — check server address and port';
        window._drift_ws_closed = true;
    }};
    window._drift_ws = ws;
}})();
"""
            platform.window.eval(js_code)

            self._ws_pending_join = {"type": C_JOIN,
                                      "name": self.my_name,
                                      "color": self.my_color}
            return True
        except Exception as e:
            self.error_msg = f"WebSocket connect failed:\n{e}"
            self.state = CS_ERROR
            return False

    def _ws_js_send(self, msg: dict):
        """Send a JSON message through the browser WebSocket."""
        try:
            import platform
            text = json.dumps(msg, separators=(",", ":"))
            platform.window.eval(
                f'if(window._drift_ws && window._drift_ws.readyState===1)'
                f'window._drift_ws.send({json.dumps(text)});'
            )
        except Exception:
            pass

    # ── Main run loop ─────────────────────────────────────────────────────────

    def run(self):
        if not self.connect():
            return self._show_error()

        while True:
            dt = self.clock.tick(60) / 1000.0

            # Network receive
            result = self._recv_network()
            if result == "disconnect":
                self.state     = CS_ERROR
                self.error_msg = "Disconnected from server."

            # Events
            res = self._handle_events(dt)
            if res is not None:
                return res

            # Update
            self._update(dt)

            # Draw
            self._draw()
            pygame.display.flip()

    def _send(self, msg: dict):
        """Send a message to the server regardless of transport."""
        if self.IS_WEB:
            self._ws_js_send(msg)
        elif self.buf:
            self._send(msg)

    def _recv_network(self):
        if self.IS_WEB:
            return self._recv_ws()
        # TCP path
        if not self.buf:
            return None
        msgs = self.buf.recv_all()
        if msgs is None:
            return "disconnect"
        for m in msgs:
            self._handle_server_msg(m)
        return None

    def _recv_ws(self):
        """Poll the browser WebSocket inbox via platform.window."""
        try:
            import platform
            win = platform.window

            # Check for error/close before trying to send the join packet
            if win.eval("!!window._drift_ws_closed"):
                # Surface any JS-side error message
                js_err = win.eval("window._drift_ws_error || ''")
                if js_err and js_err != "null":
                    self.error_msg = str(js_err)
                elif not self.error_msg:
                    self.error_msg = "Disconnected from server."
                return "disconnect"

            # Send the pending join once the socket is OPEN (readyState === 1)
            if hasattr(self, "_ws_pending_join") and self._ws_pending_join:
                rs = win.eval("window._drift_ws ? window._drift_ws.readyState : -1")
                if rs == 1:
                    self._ws_js_send(self._ws_pending_join)
                    self._ws_pending_join = None

            # Drain the JS inbox
            raw = win.eval("JSON.stringify(window._drift_ws_inbox || [])")
            if raw and raw != "null":
                try:
                    messages = json.loads(raw)
                except Exception:
                    messages = []
                if messages:
                    win.eval("window._drift_ws_inbox = [];")
                    for text in messages:
                        try:
                            self._handle_server_msg(json.loads(text))
                        except Exception:
                            pass
        except Exception:
            pass
        return None

    def _handle_server_msg(self, m):
        t = m.get("type")

        if t == S_WELCOME:
            self.my_pid = m["pid"]
            for lv in m.get("level_list", []):
                pass   # we'll get full data via S_LEVEL_DATA
            self.state = CS_LOBBY

        elif t == S_LEVEL_DATA:
            self.levels_cache[m["key"]] = m["data"]

        elif t == S_PLAYER_JOIN:
            self.all_players[m["pid"]] = {"name": m["name"], "color": m["color"]}
            self.chat.add("", f"» {m['name']} joined", (120, 200, 120))

        elif t == S_PLAYER_LEAVE:
            pid = m["pid"]
            info = self.all_players.pop(pid, None)
            name = info["name"] if info else f"Player{pid}"
            self.chat.add("", f"» {name} left", (200, 120, 120))
            self.remote_cars.pop(pid, None)

        elif t == S_LOBBY:
            self.lobby_players = m["players"]
            for p in m["players"]:
                self.all_players[p["pid"]] = {"name": p["name"], "color": p["color"]}

        elif t == S_VOTE_START:
            self.state           = CS_VOTING
            self.vote_levels     = m["levels"]
            self.vote_modes      = m["modes"]
            self.vote_duration   = m["duration"]
            self.vote_end_t      = time.time() + m["duration"]
            # Pre-select first option
            if self.vote_levels and not self.my_vote_level:
                self.my_vote_level = self.vote_levels[0]["key"]
            if self.vote_modes and not self.my_vote_mode:
                self.my_vote_mode  = self.vote_modes[0]["id"]
            self._send_vote()

        elif t == S_VOTE_UPDATE:
            self.vote_level_counts = m.get("level_votes", {})
            self.vote_mode_counts  = m.get("mode_votes",  {})

        elif t == S_COUNTDOWN:
            self.state             = CS_COUNTDOWN
            self.countdown_secs    = float(m["seconds"])
            self.countdown_level   = m.get("level_name", m.get("level_key",""))
            self.countdown_mode    = m.get("mode","")
            self.countdown_start   = time.time()

        elif t == S_GAME_START:
            self._on_game_start(m)

        elif t == S_STATE:
            self._on_state(m)

        elif t == S_LAP:
            pid  = m["pid"]
            name = self.all_players.get(pid, {}).get("name", f"P{pid}")
            lt   = m.get("lap_time", 0)
            self.chat.add("", f"  {name} — Lap {m['lap']}  {lt:.2f}s",
                           (88,255,88) if pid==self.my_pid else (180,255,180))

        elif t == S_FINISH:
            pid  = m["pid"]
            name = self.all_players.get(pid, {}).get("name", f"P{pid}")
            tt   = m.get("total_time", 0)
            self.chat.add("", f"✓ {name} finished  {tt:.2f}s", (255,215,48))
            if pid == self.my_pid and self.my_car:
                self.my_car.is_drifting = False

        elif t == S_GAME_OVER:
            self.results = m["results"]
            self.state   = CS_RESULTS

        elif t == S_CHAT:
            pid   = m["pid"]
            color = self.all_players.get(pid, {}).get("color", [200,200,200])
            self.chat.add(m["name"], m["text"], color)

        elif t == S_PING:
            self._send({"type": C_PONG})

    # ── Game start ────────────────────────────────────────────────────────────

    def _on_game_start(self, m):
        self.level_key  = m["level_key"]
        self.mode       = m["mode"]
        self.level_data = self.levels_cache.get(self.level_key, {})
        self.state      = CS_RACING
        self.game_start_t = time.time()

        # Build background
        if self.level_data:
            self.bg_surf, self.bg_ox, self.bg_oy = build_bg(self.level_data)

        # Walls for local collision
        self.walls = []
        for w in self.level_data.get("walls", []):
            self.walls.append(pygame.Rect(int(w["x"]), int(w["y"]),
                                           int(w["w"]), int(w["h"])))

        # Checkpoints
        self.checkpoints = []
        for cp in self.level_data.get("checkpoints", []):
            if len(cp) == 2:
                self.checkpoints.append(
                    pygame.Rect(int(cp[0])-60, int(cp[1])-60, 120, 120))
            else:
                self.checkpoints.append(
                    pygame.Rect(int(cp[0]), int(cp[1]), int(cp[2]), int(cp[3])))
        self.max_laps   = self.level_data.get("lap_count", 3)
        self.my_next_cp = 0
        self.my_lap     = 0
        self._client_trig_active = {}
        self._client_trig_touch  = {}

        # Create cars
        self.remote_cars = {}
        for pd in m["players"]:
            pid = pd["pid"]
            rc  = RemoteCar(pid, pd["name"], pd["color"],
                             pd["x"], pd["y"], pd["angle"])
            self.remote_cars[pid] = rc
            if pid == self.my_pid:
                # Local car for client-side prediction
                self.my_car = CarController(pd["x"], pd["y"], pd["angle"],
                                             pd["color"])
                self.my_car.particle_quality = self.sd.settings.get("particle_quality","High")
                self.my_car.skidmarks_on     = self.sd.settings.get("skidmarks", True)
                self.cam_x = float(pd["x"])
                self.cam_y = float(pd["y"])

        self.chat.add("", f"» {MODE_LABELS.get(self.mode,'?')} started!",
                       (255, 215, 48))

    def _on_state(self, m):
        for pid_s, d in m.get("players", {}).items():
            pid = int(pid_s)
            if pid in self.remote_cars:
                self.remote_cars[pid].server_update(d)
                # Update my local tracking from server authority
                if pid == self.my_pid:
                    self.my_lap     = d.get("lap", self.my_lap)
                    self.my_next_cp = d.get("next_cp", self.my_next_cp)

    # ── Events ────────────────────────────────────────────────────────────────

    def _handle_events(self, dt):
        for ev in pygame.event.get():
            if ev.type == pygame.QUIT:
                pygame.quit(); sys.exit()

            if ev.type == pygame.KEYDOWN:
                # Chat has priority
                text = self.chat.handle_key(ev)
                if text:
                    self._send({"type": C_CHAT, "text": text})
                    continue
                if self.chat.active:
                    continue

                if ev.key == pygame.K_ESCAPE:
                    return "menu"

                if self.state == CS_LOBBY and ev.key == pygame.K_RETURN:
                    self._send({"type": C_READY})

                if self.state == CS_RESULTS and ev.key in (pygame.K_RETURN, pygame.K_SPACE):
                    # Return to lobby (server will reset anyway)
                    self.state = CS_LOBBY
                    return None

        # Mouse clicks for voting
        if self.state == CS_VOTING:
            self._handle_vote_clicks()

        return None

    # ── Update ────────────────────────────────────────────────────────────────

    def _update(self, dt):
        self.chat.update(dt)

        if self.state == CS_RACING:
            self._update_racing(dt)

        if self.state == CS_COUNTDOWN:
            # Just display — server drives the transition
            pass

    def _update_racing(self, dt):
        if not self.my_car:
            return

        from controller import pump_controller_events, ControllerKeys
        ctrl = pump_controller_events(dt)
        ck   = ControllerKeys(ctrl)
        keys = pygame.key.get_pressed()

        # Send merged keyboard + controller inputs to server
        send_inp = {
            "gas":   bool(keys[pygame.K_UP]   or keys[pygame.K_w]  or ctrl.gas_value()   > 0.05),
            "brake": bool(keys[pygame.K_DOWN]  or keys[pygame.K_s]  or ctrl.brake_value() > 0.05),
            "left":  bool(keys[pygame.K_LEFT]  or keys[pygame.K_a]  or ctrl.steer_value() < -0.1),
            "right": bool(keys[pygame.K_RIGHT] or keys[pygame.K_d]  or ctrl.steer_value() >  0.1),
            "hb":    bool(keys[pygame.K_SPACE] or ctrl.handbrake),
        }
        if send_inp != self._last_input:
            self._seq += 1
            self._send({"type": C_INPUT, "seq": self._seq, **send_inp})
            self._last_input = dict(send_inp)

        # ── Trigger detection + application BEFORE car.update() ───────────────
        # Must mirror the server's per-player toggle logic exactly so the local
        # physics prediction and the visual ON/OFF state stay in sync.
        TRIG_SANITISE = {
            "speed": lambda v: 1.0 if v > 10.0 else max(0.1, min(10.0, v)),
            "accel": lambda v: max(0.1, min(10.0, v)),
            "steer": lambda v: max(0.1, min(10.0, v)),
            "drift": lambda v: max(0.05, min(10.0, v)),
        }
        if self.level_data:
            for i, tr in enumerate(self.level_data.get("triggers", [])):
                tr_rect = pygame.Rect(int(tr["x"]), int(tr["y"]),
                                      int(tr["w"]), int(tr["h"]))
                # Edge-detect: is the car newly entering this zone?
                touching = tr_rect.collidepoint(self.my_car.x, self.my_car.y)
                if not touching:
                    for cx2, cy2 in self.my_car.get_corners():
                        if tr_rect.collidepoint(cx2, cy2):
                            touching = True; break
                was = self._client_trig_touch.get(i, False)
                if touching and not was:
                    self._client_trig_active[i] = not self._client_trig_active.get(i, False)
                self._client_trig_touch[i] = touching

                # Apply multiplier to local car if this trigger is active
                if self._client_trig_active.get(i, False):
                    kind  = tr.get("kind", "speed")
                    raw_v = float(tr.get("value", 1.0))
                    v     = TRIG_SANITISE.get(kind, lambda x: x)(raw_v)
                    if kind == "speed":
                        self.my_car.trig_speed_mult *= v
                        self.my_car._trig_active = f"SPEED ×{v:.1f}"
                    elif kind == "accel":
                        self.my_car.trig_accel_mult *= v
                        self.my_car._trig_active = f"ACCEL ×{v:.1f}"
                    elif kind == "steer":
                        self.my_car.trig_steer_mult *= v
                        self.my_car._trig_active = f"TURN ×{v:.1f}"
                    elif kind == "drift":
                        self.my_car.trig_grip_mult *= v
                        self.my_car._trig_active = f"DRIFT ×{v:.1f}"

        # ── Local physics prediction (reads the mults we just set) ─────────────
        # CarController.update() resets trig_* mults at the end of each frame,
        # so we must apply them every frame before calling update().
        self.my_car.update(ck, dt)

        for wr in self.walls:
            if self.my_car.push_out_of_rect(wr, True):
                self.shake = max(self.shake, 5.0)
        if self.shake > 0:
            self.shake = max(0.0, self.shake - dt*55)

        # Reconcile position from server state (snap remote car → local)
        me = self.remote_cars.get(self.my_pid)
        if me:
            me.update(dt)
            # Soft-correct local car toward server authority
            self.my_car.x     += (me.tx - self.my_car.x)     * min(1.0, dt * 3)
            self.my_car.y     += (me.ty - self.my_car.y)     * min(1.0, dt * 3)
            self.my_car.angle += ((me.tangle - self.my_car.angle + 540)%360 - 180) * min(1.0, dt*3)

        # Update remote cars
        for pid, rc in self.remote_cars.items():
            if pid != self.my_pid:
                rc.update(dt)

        # Camera
        tx = self.my_car.x + self.my_car.vx * 0.12
        ty = self.my_car.y + self.my_car.vy * 0.12
        self.cam_x += (tx - self.cam_x) * min(1.0, dt * 9)
        self.cam_y += (ty - self.cam_y) * min(1.0, dt * 9)
        self.target_zoom = max(0.58, 1.05 - (self.my_car.speed / self.my_car.SPEED_MAX)*0.42)
        self.zoom += (self.target_zoom - self.zoom) * min(1.0, dt * 3)

    # ── Draw dispatch ─────────────────────────────────────────────────────────

    def _draw(self):
        if   self.state == CS_CONNECT:   self._draw_connecting()
        elif self.state == CS_LOBBY:     self._draw_lobby()
        elif self.state == CS_VOTING:    self._draw_voting()
        elif self.state == CS_COUNTDOWN: self._draw_countdown()
        elif self.state == CS_RACING:    self._draw_racing()
        elif self.state == CS_RESULTS:   self._draw_results()
        elif self.state == CS_ERROR:     self._draw_error()

    # ── Connecting ────────────────────────────────────────────────────────────

    def _draw_connecting(self):
        self.screen.fill(COL_BG)
        t = self.fB.render(f"Connecting to {self.host}:{self.port}…", True, COL_WHITE)
        self.screen.blit(t, (self.sw//2 - t.get_width()//2, self.sh//2 - 20))

    def _draw_error(self):
        self.screen.fill(COL_BG)
        # Break long error messages and add WSS guidance if relevant
        raw_lines = self.error_msg.split("\n")
        lines = []
        for l in raw_lines:
            # Wrap long lines
            while len(l) > 60:
                lines.append(l[:60]); l = l[60:]
            lines.append(l)

        # Detect the HTTPS/WSS problem and add a helpful hint
        is_tls_err = any("insecure" in l.lower() or "https" in l.lower()
                          or "wss" in l.lower() or "mixed" in l.lower()
                          for l in lines)
        if is_tls_err:
            lines += [
                "",
                "Your game is served over HTTPS so the",
                "server must also support WSS (secure",
                "WebSocket). Set up a reverse proxy:",
                "",
                "  nginx/Caddy in front of port 7778",
                "  → forwards to ws://localhost:7778",
                "",
                "Or test on HTTP (e.g. localhost).",
            ]

        total_h = len(lines) * 22
        start_y = self.sh // 2 - total_h // 2
        for i, line in enumerate(lines):
            col = COL_RED if i == 0 else ((255,200,80) if line.startswith("  ") else COL_GREY)
            t   = self.ft.render(line, True, col)
            self.screen.blit(t, (self.sw//2 - t.get_width()//2, start_y + i*22))

        h = self.ft.render("Press ESC to return to menu", True, (80,84,98))
        self.screen.blit(h, (self.sw//2 - h.get_width()//2, self.sh - 24))

    def _show_error(self):
        """Blocking error display when we can't connect at all."""
        clock = pygame.time.Clock()
        while True:
            for ev in pygame.event.get():
                if ev.type == pygame.QUIT: pygame.quit(); sys.exit()
                if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE:
                    return "menu"
            self._draw_error()
            pygame.display.flip()
            clock.tick(30)

    # ── Lobby ─────────────────────────────────────────────────────────────────

    def _draw_lobby(self):
        sw, sh = self.sw, self.sh
        self.screen.fill(COL_BG)

        t = self.fT.render("LOBBY", True, COL_GOLD)
        self.screen.blit(t, (sw//2 - t.get_width()//2, 24))

        # Player list
        panel_w = 420; panel_x = sw//2 - panel_w//2
        panel_h = max(200, len(self.lobby_players)*52 + 60)
        pygame.draw.rect(self.screen, COL_PANEL,
                          (panel_x, 80, panel_w, panel_h), border_radius=10)
        pygame.draw.rect(self.screen, COL_BORDER,
                          (panel_x, 80, panel_w, panel_h), 2, border_radius=10)

        for i, p in enumerate(self.lobby_players):
            ry = 100 + i*52
            col = tuple(p["color"])
            is_me = (p["pid"] == self.my_pid)
            pygame.draw.rect(self.screen, (30,36,52),
                              (panel_x+8, ry, panel_w-16, 44), border_radius=7)
            if is_me:
                pygame.draw.rect(self.screen, COL_GOLD,
                                  (panel_x+8, ry, panel_w-16, 44), 2, border_radius=7)
            pygame.draw.circle(self.screen, col, (panel_x+30, ry+22), 14)
            name_t = self.fM.render(p["name"] + (" (you)" if is_me else ""),
                                     True, COL_WHITE)
            self.screen.blit(name_t, (panel_x+52, ry+6))
            status = "✓ READY" if p["ready"] else "waiting…"
            scol   = COL_GREEN if p["ready"] else COL_GREY
            st = self.fS.render(status, True, scol)
            self.screen.blit(st, (panel_x+52, ry+24))

        # Ready button
        btn_y = 80 + panel_h + 16
        my_ready = next((p["ready"] for p in self.lobby_players
                          if p["pid"]==self.my_pid), False)
        btn_col  = (42,90,42) if not my_ready else (28,60,28)
        btn_txt  = "PRESS ENTER — READY" if not my_ready else "✓ READY — waiting for others…"
        btn = pygame.Rect(sw//2-180, btn_y, 360, 46)
        mouse = pygame.mouse.get_pos()
        hov   = btn.collidepoint(mouse)
        pygame.draw.rect(self.screen, (62,138,62) if hov else btn_col, btn, border_radius=9)
        pygame.draw.rect(self.screen, COL_GREEN, btn, 2, border_radius=9)
        bt = self.fB.render(btn_txt, True, COL_WHITE)
        self.screen.blit(bt, bt.get_rect(center=btn.center))
        if hov and pygame.mouse.get_pressed()[0]:
            self._send({"type": C_READY})

        hint = self.ft.render("ESC = disconnect   ENTER = ready", True, COL_GREY)
        self.screen.blit(hint, (sw//2 - hint.get_width()//2, sh-20))

        # Chat
        self.chat.draw(self.screen, 10, sh-80, sw//2-20)

    # ── Voting ────────────────────────────────────────────────────────────────

    def _handle_vote_clicks(self):
        if not pygame.mouse.get_pressed()[0]:
            return
        mx, my = pygame.mouse.get_pos()
        # Level buttons: built during draw — store rects
        for key, r in self._vote_level_rects.items():
            if r.collidepoint(mx, my) and self.my_vote_level != key:
                self.my_vote_level = key
                self._send_vote()
        for mid, r in self._vote_mode_rects.items():
            if r.collidepoint(mx, my) and self.my_vote_mode != mid:
                self.my_vote_mode = mid
                self._send_vote()

    def _send_vote(self):
        self._send({"type": C_VOTE,
                        "level_key": self.my_vote_level,
                        "mode":      self.my_vote_mode})

    def _draw_voting(self):
        sw, sh = self.sw, self.sh
        self.screen.fill(COL_BG)
        self._vote_level_rects = {}
        self._vote_mode_rects  = {}

        t = self.fT.render("VOTE", True, COL_GOLD)
        self.screen.blit(t, (sw//2 - t.get_width()//2, 14))

        remaining = max(0.0, self.vote_end_t - time.time())
        tr = self.fB.render(f"{remaining:.0f}s", True,
                              COL_RED if remaining < 6 else COL_WHITE)
        self.screen.blit(tr, (sw - tr.get_width() - 14, 18))

        # ── Level list (left half) ────────────────────────────────────────────
        lx = 30; lw = sw//2 - 50; ry = 70
        self.screen.blit(self.fS.render("SELECT MAP", True, COL_GREY), (lx, ry)); ry += 20
        total_votes = sum(self.vote_level_counts.values()) or 1
        for lv in self.vote_levels:
            key  = lv["key"]; name = lv.get("name", key)
            sel  = (key == self.my_vote_level)
            votes= self.vote_level_counts.get(key, 0)
            r    = pygame.Rect(lx, ry, lw, 44)
            hov  = r.collidepoint(pygame.mouse.get_pos())
            bg   = (44,64,44) if sel else ((30,38,52) if hov else (22,26,38))
            pygame.draw.rect(self.screen, bg, r, border_radius=7)
            pygame.draw.rect(self.screen, COL_GREEN if sel else COL_BORDER,
                              r, 2 if sel else 1, border_radius=7)
            self.screen.blit(self.fM.render(name, True,
                              COL_WHITE if sel else COL_GREY), (lx+10, ry+5))
            # Vote bar
            pct = votes / total_votes
            bw  = int((lw-20)*pct)
            if bw > 0:
                pygame.draw.rect(self.screen, (55,140,55,160),
                                  (lx+10, ry+28, bw, 8), border_radius=3)
            vc = self.ft.render(f"{votes} vote{'s' if votes!=1 else ''}",
                                 True, COL_GREY)
            self.screen.blit(vc, (lx+lw-vc.get_width()-8, ry+28))
            self._vote_level_rects[key] = r
            ry += 52

        # ── Mode list (right half) ────────────────────────────────────────────
        mx2 = sw//2 + 20; mw = sw//2 - 50; ry2 = 70
        self.screen.blit(self.fS.render("SELECT MODE", True, COL_GREY),
                          (mx2, ry2)); ry2 += 20
        total_mv = sum(self.vote_mode_counts.values()) or 1
        for md in self.vote_modes:
            mid   = md["id"]; label = md["label"]; desc = md.get("desc","")
            sel   = (mid == self.my_vote_mode)
            votes2= self.vote_mode_counts.get(mid, 0)
            r2    = pygame.Rect(mx2, ry2, mw, 56)
            hov   = r2.collidepoint(pygame.mouse.get_pos())
            bg    = (44,44,64) if sel else ((30,32,52) if hov else (22,24,38))
            pygame.draw.rect(self.screen, bg, r2, border_radius=7)
            pygame.draw.rect(self.screen, COL_BLUE if sel else COL_BORDER,
                              r2, 2 if sel else 1, border_radius=7)
            self.screen.blit(self.fM.render(label, True,
                              COL_WHITE if sel else COL_GREY), (mx2+10, ry2+5))
            self.screen.blit(self.ft.render(desc, True, (110,115,138)),
                              (mx2+10, ry2+26))
            pct2 = votes2 / total_mv
            bw2  = int((mw-20)*pct2)
            if bw2 > 0:
                pygame.draw.rect(self.screen, (55,55,140,160),
                                  (mx2+10, ry2+42, bw2, 8), border_radius=3)
            vc2 = self.ft.render(f"{votes2} vote{'s' if votes2!=1 else ''}",
                                  True, COL_GREY)
            self.screen.blit(vc2, (mx2+mw-vc2.get_width()-8, ry2+42))
            self._vote_mode_rects[mid] = r2
            ry2 += 64

        hint = self.ft.render("Click to vote   —   votes update live", True, COL_GREY)
        self.screen.blit(hint, (sw//2-hint.get_width()//2, sh-20))
        self.chat.draw(self.screen, 10, sh-50, sw//2-20)

    # ── Countdown ─────────────────────────────────────────────────────────────

    def _draw_countdown(self):
        # Show last racing frame underneath if available
        self.screen.fill(COL_BG)

        elapsed  = time.time() - self.countdown_start
        remaining= max(0, self.countdown_secs - elapsed)
        mode_lbl = MODE_LABELS.get(self.countdown_mode, self.countdown_mode)

        t1 = self.fT.render(self.countdown_level, True, COL_WHITE)
        self.screen.blit(t1, (self.sw//2-t1.get_width()//2, self.sh//2-90))

        t2 = self.fB.render(mode_lbl, True, COL_BLUE)
        self.screen.blit(t2, (self.sw//2-t2.get_width()//2, self.sh//2-48))

        num = int(math.ceil(remaining))
        col = COL_RED if num <= 1 else COL_GOLD
        big = pygame.font.SysFont("consolas", 110, bold=True)
        nt  = big.render(str(num) if num > 0 else "GO!", True, col)
        self.screen.blit(nt, (self.sw//2-nt.get_width()//2, self.sh//2-10))

    # ── Racing ────────────────────────────────────────────────────────────────

    def _draw_racing(self):
        sw, sh = self.sw, self.sh
        shx = random.uniform(-self.shake, self.shake) if self.shake else 0
        shy = random.uniform(-self.shake, self.shake) if self.shake else 0
        cx  = self.cam_x + shx/self.zoom
        cy  = self.cam_y + shy/self.zoom

        # Background
        gc = tuple(self.level_data.get("grass_color", [38,88,48]) if self.level_data else [38,88,48])
        self.screen.fill(gc)
        if self.bg_surf:
            bw  = int(self.bg_surf.get_width()  * self.zoom)
            bh  = int(self.bg_surf.get_height() * self.zoom)
            if bw > 0 and bh > 0:
                sc  = pygame.transform.scale(self.bg_surf, (bw, bh))
                bsx = int((self.bg_ox - cx) * self.zoom + sw*0.5)
                bsy = int((self.bg_oy - cy) * self.zoom + sh*0.5)
                self.screen.blit(sc, (bsx, bsy))

        # Checkpoints
        for i, cp in enumerate(self.checkpoints):
            active = (i == self.my_next_cp)
            self._draw_checkpoint(cp, cx, cy, active)

        # Boost pads & triggers (visual only, state is server-driven)
        if self.level_data:
            self._draw_level_extras(cx, cy)

        # Remote cars (draw behind local)
        for pid, rc in self.remote_cars.items():
            if pid != self.my_pid:
                rc.draw(self.screen, cx, cy, self.zoom)
                self._draw_name_tag(rc, cx, cy)

        # Local car
        if self.my_car:
            self.my_car.draw(self.screen, cx, cy, self.zoom)

        self._draw_race_hud(cx, cy)
        self.chat.draw(self.screen, 10, sh-30, sw//2-20)

    def _draw_checkpoint(self, cp_rect, cx, cy, active):
        sw, sh = self.sw, self.sh
        sx = (cp_rect.x - cx)*self.zoom + sw*0.5
        sy = (cp_rect.y - cy)*self.zoom + sh*0.5
        pw = max(4, int(cp_rect.w*self.zoom))
        ph = max(4, int(cp_rect.h*self.zoom))
        t  = pygame.time.get_ticks()
        s  = pygame.Surface((pw+8, ph+8), pygame.SRCALPHA)
        if active:
            pulse = int(60+90*abs(math.sin(t*0.007)))
            pygame.draw.rect(s, (88,255,88,pulse), (4,4,pw,ph), border_radius=4)
            pygame.draw.rect(s, (58,218,58,255),   (4,4,pw,ph), 3, border_radius=4)
        else:
            pygame.draw.rect(s, (175,175,175,30), (4,4,pw,ph), border_radius=4)
            pygame.draw.rect(s, (148,148,148,80), (4,4,pw,ph), 2, border_radius=4)
        self.screen.blit(s, (int(sx)-4, int(sy)-4))

    def _draw_level_extras(self, cx, cy):
        sw, sh = self.sw, self.sh
        t = pygame.time.get_ticks()

        # Boost pads
        for b in self.level_data.get("boost_pads", []):
            sx = (b["x"]-cx)*self.zoom + sw*0.5
            sy = (b["y"]-cy)*self.zoom + sh*0.5
            pw = max(1,int(b["w"]*self.zoom)); ph=max(1,int(b["h"]*self.zoom))
            a  = int(130+90*abs(math.sin(t*0.005)))
            s  = pygame.Surface((pw+4,ph+4), pygame.SRCALPHA)
            pygame.draw.rect(s,(255,215,0,a),(2,2,pw,ph),border_radius=4)
            pygame.draw.rect(s,(255,255,120,200),(2,2,pw,ph),2,border_radius=4)
            self.screen.blit(s,(int(sx)-2,int(sy)-2))

        # Trigger zones
        TRIG_COLORS = {
            "speed": (80,220,255),
            "accel": (120,255,120),
            "steer": (220,160,255),
            "drift": (255,80,160),
        }
        TRIG_LABELS = {
            "speed": "SPEED",
            "accel": "ACCEL",
            "steer": "TURN",
            "drift": "DRIFT",
        }
        for i, tr in enumerate(self.level_data.get("triggers", [])):
            sx = (tr["x"]-cx)*self.zoom + sw*0.5
            sy = (tr["y"]-cy)*self.zoom + sh*0.5
            pw = max(2, int(tr["w"]*self.zoom))
            ph = max(2, int(tr["h"]*self.zoom))
            kind   = tr.get("kind", "speed")
            r,g,b  = TRIG_COLORS.get(kind, (200,200,200))
            active = self._client_trig_active.get(i, False)
            s = pygame.Surface((pw+4, ph+4), pygame.SRCALPHA)
            if active:
                a2 = int(140+80*abs(math.sin(t*0.006)))
                pygame.draw.rect(s,(r,g,b,a2),   (2,2,pw,ph), border_radius=5)
                pygame.draw.rect(s,(r,g,b,255),  (2,2,pw,ph), 3, border_radius=5)
            else:
                pygame.draw.rect(s,(r,g,b,55),   (2,2,pw,ph), border_radius=5)
                pygame.draw.rect(s,(r,g,b,140),  (2,2,pw,ph), 2, border_radius=5)
            self.screen.blit(s,(int(sx)-2,int(sy)-2))
            if pw > 24 and ph > 14:
                val   = tr.get("value", 1.0)
                lbl_s = f"{TRIG_LABELS.get(kind,kind)} ×{val:.1f}"
                font  = pygame.font.SysFont("consolas", max(9,int(11*self.zoom)), bold=True)
                lbl   = font.render(lbl_s, True,
                                    (255,255,255) if active else (180,180,180))
                self.screen.blit(lbl,(int(sx)+pw//2-lbl.get_width()//2,
                                      int(sy)+ph//2-lbl.get_height()//2))
                badge_f = pygame.font.SysFont("consolas", max(7,int(9*self.zoom)), bold=True)
                badge   = badge_f.render("ON" if active else "OFF", True,
                                          (100,255,100) if active else (200,100,100))
                self.screen.blit(badge,(int(sx)+2, int(sy)+2))

        # Text labels
        for tx in self.level_data.get("texts", []):
            sx = (tx["x"]-cx)*self.zoom + sw*0.5
            sy = (tx["y"]-cy)*self.zoom + sh*0.5
            fsz= max(8,int(tx.get("size",24)*self.zoom))
            f  = pygame.font.SysFont("consolas",fsz,bold=True)
            col= tuple(tx.get("color",[255,255,255]))
            sh2= f.render(tx["text"],True,(0,0,0))
            self.screen.blit(sh2,(int(sx)+2,int(sy)+2))
            img= f.render(tx["text"],True,col)
            self.screen.blit(img,(int(sx),int(sy)))

    def _draw_name_tag(self, rc, cx, cy):
        sw, sh = self.sw, self.sh
        sx = (rc.x - cx)*self.zoom + sw*0.5
        sy = (rc.y - cy)*self.zoom + sh*0.5 - 28*self.zoom
        tag = self.ft.render(rc.name, True, tuple(rc.color))
        self.screen.blit(tag, (int(sx)-tag.get_width()//2, int(sy)))

    def _draw_race_hud(self, cx, cy):
        sw, sh = self.sw, self.sh
        if not self.my_car:
            return

        # Left panel
        panel = pygame.Surface((268, 165), pygame.SRCALPHA)
        panel.fill((0,0,0,158))
        pygame.draw.rect(panel,(70,76,93,198),(0,0,268,165),2,border_radius=8)
        self.screen.blit(panel,(10,10))

        ld_name = self.level_data.get("name","") if self.level_data else ""
        self.screen.blit(self.ft.render(ld_name,True,(148,156,178)),(18,14))

        if self.mode == MODE_RACE:
            self.screen.blit(self.fM.render(
                f"Lap {min(self.my_lap+1,self.max_laps)} / {self.max_laps}",
                True,(238,238,238)),(18,30))
            self.screen.blit(self.ft.render(
                f"CP {self.my_next_cp} / {len(self.checkpoints)}",
                True,(148,190,148)),(18,58))

        elif self.mode == MODE_BUMPER:
            elapsed = time.time() - self.game_start_t
            rem     = max(0.0, BUMPER_DURATION - elapsed)
            self.screen.blit(self.fM.render(f"Time  {rem:.0f}s",True,(255,215,48)),(18,30))
            me_rc = self.remote_cars.get(self.my_pid)
            my_hits = me_rc.hits if me_rc else 0
            self.screen.blit(self.fM.render(f"Hits  {my_hits}",True,(255,100,100)),(18,58))

        # Speed bar
        km_h = self.my_car.speed * (300/self.my_car.SPEED_MAX)
        bw   = int(min(km_h,300)/300*238)
        pygame.draw.rect(self.screen,(30,30,40),(18,130,238,11),border_radius=5)
        bc = (255,92,32) if self.my_car.is_drifting else (46,186,255)
        if bw > 0:
            pygame.draw.rect(self.screen,bc,(18,130,bw,11),border_radius=5)
        self.screen.blit(self.ft.render(f"{km_h:.0f} km/h",True,(185,185,185)),(18,145))

        # Drift score HUD
        self.my_car.draw_score_hud(self.screen,
            pygame.font.SysFont("consolas",44,bold=True),
            pygame.font.SysFont("consolas",26,bold=True),
            pygame.font.SysFont("consolas",16,bold=True),
            sw, sh)

        # Mini leaderboard (top-right)
        self._draw_leaderboard()

        hint = self.ft.render("WASD=Drive  SPACE=Handbrake  ENTER=Chat  ESC=Menu",
                               True,(80,84,98))
        self.screen.blit(hint,(sw//2-hint.get_width()//2,sh-16))

    def _draw_leaderboard(self):
        sw = self.sw
        entries = []
        for pid, rc in self.remote_cars.items():
            if self.mode == MODE_RACE:
                score = (rc.lap, rc.finished)
                entries.append((score, rc.name, rc.color, pid))
                entries.sort(key=lambda e: (-e[0][0], not e[0][1]))
            else:
                entries.append((rc.hits, rc.name, rc.color, pid))
                entries.sort(key=lambda e: -e[0])

        panel_h = len(entries)*22 + 30
        panel   = pygame.Surface((185, panel_h), pygame.SRCALPHA)
        panel.fill((0,0,0,148))
        pygame.draw.rect(panel,(70,76,93,198),(0,0,185,panel_h),2,border_radius=6)
        self.screen.blit(panel,(sw-195,10))

        lbl_txt = "LAPS" if self.mode==MODE_RACE else "HITS"
        self.screen.blit(self.fS.render(lbl_txt, True, COL_GOLD),(sw-188, 14))

        for i, entry in enumerate(entries[:8]):
            ey = 34 + i*22
            if self.mode == MODE_RACE:
                score, name, color, pid = entry
                val_s = f"Lap {score[0]}"
            else:
                score, name, color, pid = entry
                val_s = str(score)
            is_me = (pid == self.my_pid)
            col   = tuple(color)
            if is_me:
                pygame.draw.rect(self.screen,(40,50,70,180),(sw-193,ey-1,181,20),border_radius=4)
            self.screen.blit(self.ft.render(f"{i+1}.",True,COL_GREY),(sw-190,ey))
            self.screen.blit(self.ft.render(name[:12],True,col),(sw-175,ey))
            vt = self.ft.render(val_s,True,COL_WHITE)
            self.screen.blit(vt,(sw-vt.get_width()-14,ey))

    # ── Results ───────────────────────────────────────────────────────────────

    def _draw_results(self):
        sw, sh = self.sw, self.sh
        self.screen.fill(COL_BG)

        t = self.fT.render("RESULTS", True, COL_GOLD)
        self.screen.blit(t,(sw//2-t.get_width()//2, 20))

        mode_lbl = MODE_LABELS.get(self.mode, self.mode or "")
        ml = self.fS.render(mode_lbl, True, COL_BLUE)
        self.screen.blit(ml,(sw//2-ml.get_width()//2, 62))

        # Table header
        hx = sw//2 - 320
        for cx2, txt in [(hx+40,"#"), (hx+80,"Player"),
                          (hx+310,"Laps"), (hx+380,"Best Lap"),
                          (hx+470,"Total"), (hx+560,"Hits"), (hx+630,"Score")]:
            self.screen.blit(self.fS.render(txt,True,COL_GREY),(cx2,95))

        medals = ["🥇","🥈","🥉"]
        for i, r in enumerate(self.results[:12]):
            ry   = 120 + i*42
            is_me= (r["pid"] == self.my_pid)
            panel= pygame.Rect(hx, ry, 640, 38)
            bg   = (40,60,40) if is_me else (24,28,42)
            pygame.draw.rect(self.screen, bg, panel, border_radius=7)
            pygame.draw.rect(self.screen, COL_GOLD if is_me else COL_BORDER,
                              panel, 2 if is_me else 1, border_radius=7)

            # Medal / rank
            rank = medals[i] if i < 3 else str(i+1)
            rt = self.fM.render(rank, True, COL_GOLD if i<3 else COL_GREY)
            self.screen.blit(rt,(hx+4, ry+8))

            # Colour dot + name
            pygame.draw.circle(self.screen, tuple(r["color"]),
                                (hx+72, ry+19), 8)
            nt = self.fM.render(r["name"], True,
                                 COL_WHITE if is_me else COL_WHITE)
            self.screen.blit(nt,(hx+88, ry+8))

            # Stats
            for cx2, val in [
                (hx+310, str(r.get("laps",0))),
                (hx+380, f"{r['best_lap']:.2f}s" if r.get("best_lap") else "-"),
                (hx+470, f"{r['total_time']:.2f}s" if r.get("total_time") else "-"),
                (hx+560, str(r.get("hits",0))),
                (hx+620, f"{r.get('drift_score',0):,}"),
            ]:
                self.screen.blit(self.ft.render(val, True, COL_WHITE),(cx2,ry+12))

        hint = self.fS.render("ENTER / SPACE  —  back to lobby", True, COL_GREY)
        self.screen.blit(hint,(sw//2-hint.get_width()//2, sh-30))
        self.chat.draw(self.screen,10,sh-60,sw//2-20)


# ── Connect screen (shown from main menu) ────────────────────────────────────

class ConnectScreen:
    """
    Simple UI to enter server IP, port, name and pick car colour.
    Returns a MultiplayerClient when the user clicks Connect.
    """

    def __init__(self, screen, sd):
        self.screen = screen
        self.sd     = sd
        self.sw, self.sh = screen.get_size()
        self.clock  = pygame.time.Clock()
        self.fT = pygame.font.SysFont("consolas",30,bold=True)
        self.fB = pygame.font.SysFont("consolas",20,bold=True)
        self.fS = pygame.font.SysFont("consolas",15,bold=True)
        self.ft = pygame.font.SysFont("consolas",13)

        self.host      = "127.0.0.1"
        self.port_str  = str(DEFAULT_PORT)
        self.ws_port_str = "7778"
        self.name      = sd.prefs.get("mp_name", "Player")
        self.sel_color = sd.prefs.get("mp_color", 0)
        self.focus     = "host"   # which field is focused
        self.error     = ""
        self.IS_WEB    = sys.platform == "emscripten"

    def run(self):
        from controller import pump_controller_events, nav_input, show_keyboard, hide_keyboard
        field_order = ["host", "ws_port", "name"] if self.IS_WEB else \
                      ["host", "port", "ws_port", "name"]
        while True:
            dt    = self.clock.tick(60)/1000.0
            inp   = pump_controller_events(dt)
            nav   = nav_input(dt)
            evs   = pygame.event.get()
            mouse = pygame.mouse.get_pos()

            # Show keyboard for focused text field when controller active
            if inp.controller_active and hasattr(self, "_field_rects"):
                if self.focus in self._field_rects:
                    show_keyboard(self._field_rects[self.focus])

            for ev in evs:
                if ev.type==pygame.QUIT: pygame.quit(); sys.exit()
                if ev.type==pygame.KEYDOWN:
                    if ev.key==pygame.K_ESCAPE: hide_keyboard(); return "menu"
                    self._key(ev)
                if ev.type==pygame.MOUSEBUTTONDOWN and ev.button==1:
                    res = self._click(mouse)
                    if res: return res

            # Controller navigation
            if nav.menu_back: hide_keyboard(); return "menu"
            if nav.menu_down or nav.menu_up:
                idx = field_order.index(self.focus) if self.focus in field_order else 0
                idx = (idx + (1 if nav.menu_down else -1)) % len(field_order)
                self.focus = field_order[idx]
                if hasattr(self, "_field_rects") and self.focus in self._field_rects:
                    show_keyboard(self._field_rects[self.focus])
            if nav.menu_confirm:
                hide_keyboard()
                res = self._try_connect()
                if res: return res

            self._draw(mouse)
            pygame.display.flip()

    def tick(self):
        """Single-frame update for Pygbag async loop. Returns None to continue."""
        from controller import pump_controller_events, nav_input, show_keyboard, hide_keyboard
        dt    = self.clock.tick(60) / 1000.0
        inp   = pump_controller_events(dt)
        nav   = nav_input(dt)
        evs   = pygame.event.get()
        mouse = pygame.mouse.get_pos()

        # Show keyboard whenever a text field is focused and controller is used
        if inp.controller_active and hasattr(self, "_field_rects"):
            if self.focus in self._field_rects:
                show_keyboard(self._field_rects[self.focus])

        for ev in evs:
            if ev.type == pygame.QUIT: pygame.quit(); sys.exit()
            if ev.type == pygame.KEYDOWN:
                if ev.key == pygame.K_ESCAPE:
                    hide_keyboard(); return "menu"
                self._key(ev)
            if ev.type == pygame.MOUSEBUTTONDOWN and ev.button == 1:
                res = self._click(mouse)
                if res: return res

        # Controller navigation through fields
        field_order = ["host", "ws_port", "name"] if self.IS_WEB else \
                      ["host", "port", "ws_port", "name"]
        if nav.menu_back:
            hide_keyboard(); return "menu"
        if nav.menu_down or nav.menu_up:
            idx = field_order.index(self.focus) if self.focus in field_order else 0
            idx = (idx + (1 if nav.menu_down else -1)) % len(field_order)
            self.focus = field_order[idx]
            if hasattr(self, "_field_rects") and self.focus in self._field_rects:
                show_keyboard(self._field_rects[self.focus])
        if nav.menu_confirm:
            hide_keyboard()
            res = self._try_connect()
            if res: return res

        self._draw(mouse)
        return None

    def _key(self, ev):
        from controller import show_keyboard
        if ev.key == pygame.K_TAB:
            order = ["host", "port", "ws_port", "name"] if not self.IS_WEB else ["host", "ws_port", "name"]
            idx   = order.index(self.focus) if self.focus in order else 0
            self.focus = order[(idx+1)%len(order)]
            # Show keyboard for the newly focused field if rects are available
            if hasattr(self, "_field_rects") and self.focus in self._field_rects:
                show_keyboard(self._field_rects[self.focus])
            return
        if self.focus == "host":
            self._edit(ev, "host", "0123456789.")
        elif self.focus == "port":
            self._edit(ev, "port_str", "0123456789")
        elif self.focus == "ws_port":
            self._edit(ev, "ws_port_str", "0123456789")
        elif self.focus == "name":
            self._edit(ev, "name", None, max_len=16)

    def _edit(self, ev, attr, allowed, max_len=40):
        v = getattr(self, attr)
        if ev.key == pygame.K_BACKSPACE:
            setattr(self, attr, v[:-1])
        elif ev.unicode and (allowed is None or ev.unicode in allowed):
            if len(v) < max_len:
                setattr(self, attr, v + ev.unicode)

    def _click(self, mouse):
        from controller import show_keyboard, hide_keyboard
        prev_focus = self.focus
        # Field focus
        for fld, r in self._field_rects.items():
            if r.collidepoint(mouse):
                self.focus = fld
                show_keyboard(r)   # show phone/OS keyboard when tapping a field
        # Colour picker
        for i, r in self._color_rects.items():
            if r.collidepoint(mouse):
                self.sel_color = i
                hide_keyboard()
        # Connect button
        if self._connect_r.collidepoint(mouse):
            hide_keyboard()
            return self._try_connect()
        return None

    def _try_connect(self):
        try:
            port = int(self.port_str)
        except ValueError:
            self.error = "Invalid TCP port"; return None
        try:
            ws_port = int(self.ws_port_str)
        except ValueError:
            self.error = "Invalid WebSocket port"; return None
        if not self.host:
            self.error = "Enter a host"; return None
        if not self.name.strip():
            self.error = "Enter a name"; return None

        color = CAR_COLORS[self.sel_color % len(CAR_COLORS)][0]
        self.sd.prefs["mp_name"]  = self.name
        self.sd.prefs["mp_color"] = self.sel_color
        self.sd.save()

        client = MultiplayerClient(self.screen, self.sd,
                                    self.name.strip(), color,
                                    self.host, port, ws_port)
        return client

    def _draw(self, mouse):
        sw, sh = self.sw, self.sh
        self.screen.fill((13,16,26))
        self._field_rects  = {}
        self._color_rects  = {}

        t = self.fT.render("MULTIPLAYER", True, (205,192,92))
        self.screen.blit(t,(sw//2-t.get_width()//2, 20))

        # Browser badge
        if self.IS_WEB:
            wb = self.ft.render("Browser mode — connects via WebSocket", True, (80,180,255))
            self.screen.blit(wb,(sw//2-wb.get_width()//2, 58))

        cx = sw//2; y = 80

        # On browser we only show WS port, not TCP port
        if self.IS_WEB:
            fields = [("host",    "Server IP",       self.host),
                      ("ws_port", "WebSocket Port",   self.ws_port_str),
                      ("name",    "Your Name",        self.name)]
        else:
            fields = [("host",    "Server IP",        self.host),
                      ("port",    "TCP Port",          self.port_str),
                      ("ws_port", "WebSocket Port",    self.ws_port_str),
                      ("name",    "Your Name",         self.name)]

        for fld, lbl, val in fields:
            attr = {"host":"host","port":"port_str","ws_port":"ws_port_str","name":"name"}[fld]
            self.screen.blit(self.fS.render(lbl,True,(148,152,175)),(cx-240,y))
            r = pygame.Rect(cx-240,y+18,480,30)
            focused = (self.focus==fld)
            pygame.draw.rect(self.screen,(30,38,52) if not focused else (38,50,70),r,border_radius=6)
            pygame.draw.rect(self.screen,(80,100,140) if focused else (50,58,80),r,2,border_radius=6)
            vt = self.fS.render(val+("_" if focused else ""),True,
                                 (220,220,200) if focused else (175,178,195))
            self.screen.blit(vt,(r.x+6,r.y+6))
            self._field_rects[fld] = r
            y += 62

        # Colour picker
        self.screen.blit(self.fS.render("Car Colour",True,(148,152,175)),(cx-240,y))
        y += 18
        for i,(col,name) in enumerate(CAR_COLORS):
            cr = pygame.Rect(cx-240+i*62, y, 54, 40)
            sel= (i==self.sel_color)
            pygame.draw.rect(self.screen,tuple(col),cr,border_radius=6)
            pygame.draw.rect(self.screen,(255,255,100) if sel else (50,58,80),
                              cr,3 if sel else 1,border_radius=6)
            nt = self.ft.render(name,True,(220,220,200))
            self.screen.blit(nt,(cr.x+cr.w//2-nt.get_width()//2,cr.y+cr.h-14))
            self._color_rects[i] = cr
        y += 56

        # Error
        if self.error:
            et = self.fS.render(self.error,True,(220,80,80))
            self.screen.blit(et,(cx-et.get_width()//2,y)); y+=26

        # Connect button
        self._connect_r = pygame.Rect(cx-140,y+8,280,44)
        hov = self._connect_r.collidepoint(mouse)
        pygame.draw.rect(self.screen,(62,138,62) if hov else (42,90,42),
                          self._connect_r,border_radius=9)
        pygame.draw.rect(self.screen,(88,200,88),self._connect_r,2,border_radius=9)
        bt = self.fB.render("CONNECT",True,(238,238,238))
        self.screen.blit(bt,bt.get_rect(center=self._connect_r.center))

        hint = self.ft.render("TAB = next field   ESC = back",True,(68,72,92))
        self.screen.blit(hint,(sw//2-hint.get_width()//2,sh-18))


# ── Entry point called from mainmenu.py ──────────────────────────────────────

def run_multiplayer(screen, sd):
    """
    Blocking desktop entry point. Called from main.py on desktop.
    """
    cs = ConnectScreen(screen, sd)
    while True:
        result = cs.run()
        if result == "menu":
            return "menu"
        if isinstance(result, MultiplayerClient):
            ret = result.run()
            if ret == "menu":
                return "menu"


async def run_multiplayer_async(screen, sd):
    """
    Async entry point for Pygbag (browser). Uses tick() on every class
    so the browser event loop is never blocked.
    """
    cs = ConnectScreen(screen, sd)
    result = None
    while result is None:
        result = cs.tick()
        pygame.display.flip()
        await __import__("asyncio").sleep(0)

    if result == "menu":
        return

    if isinstance(result, MultiplayerClient):
        client = result
        if not client.connect():
            # Show error and wait for ESC
            while True:
                for ev in pygame.event.get():
                    if ev.type == pygame.QUIT: pygame.quit(); return
                    if ev.type == pygame.KEYDOWN and ev.key == pygame.K_ESCAPE: return
                client._draw_error()
                pygame.display.flip()
                await __import__("asyncio").sleep(0)
            return

        ret = None
        while ret is None:
            dt = client.clock.tick(60) / 1000.0
            recv_result = client._recv_network()
            if recv_result == "disconnect":
                client.state     = CS_ERROR
                client.error_msg = "Disconnected from server."
            ret = client._handle_events(dt)
            client._update(dt)
            client._draw()
            pygame.display.flip()
            await __import__("asyncio").sleep(0)