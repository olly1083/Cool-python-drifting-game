"""
network.py  –  Drift Master Multiplayer
Shared message protocol, constants, and helpers used by server and client.
All messages are newline-delimited JSON sent over TCP.
"""
import json, socket, threading

# ── Constants ─────────────────────────────────────────────────────────────────
DEFAULT_PORT    = 7777
MAX_PLAYERS     = 16
TICK_RATE       = 20        # server state-broadcast Hz
VOTE_DURATION   = 20.0      # seconds to vote
COUNTDOWN_SECS  = 5.0       # pre-race countdown
BUMPER_DURATION = 120.0     # bumper cars time limit (seconds)
RACE_TIMEOUT    = 300.0     # force-end race after this many seconds

# ── Game modes ────────────────────────────────────────────────────────────────
MODE_RACE   = "race"
MODE_BUMPER = "bumper"
MODES       = [MODE_RACE, MODE_BUMPER]
MODE_LABELS = {MODE_RACE: "RACE", MODE_BUMPER: "BUMPER CARS"}
MODE_DESCS  = {
    MODE_RACE:   "Complete laps as fast as possible",
    MODE_BUMPER: "Score the most hits in 2 minutes",
}

# ── Server → Client ───────────────────────────────────────────────────────────
S_WELCOME      = "welcome"       # {pid, level_list:[{key,name,laps}]}
S_LEVEL_DATA   = "level_data"    # {key, data:<full lev dict>}
S_PLAYER_JOIN  = "player_join"   # {pid, name, color}
S_PLAYER_LEAVE = "player_leave"  # {pid}
S_LOBBY        = "lobby"         # {players:[{pid,name,color,ready}]}
S_VOTE_START   = "vote_start"    # {levels:[{key,name}], modes:[{id,label,desc}], duration}
S_VOTE_UPDATE  = "vote_update"   # {level_votes:{key:n}, mode_votes:{mode:n}}
S_COUNTDOWN    = "countdown"     # {seconds, level_key, level_name, mode}
S_GAME_START   = "game_start"    # {level_key, mode, players:[{pid,name,color,x,y,angle}]}
S_STATE        = "state"         # {players:{pid:{x,y,angle,speed,lat,drifting,boost,hits,lap,next_cp,finished}}}
S_LAP          = "lap"           # {pid, lap, lap_time}
S_FINISH       = "finish"        # {pid, total_time}
S_GAME_OVER    = "game_over"     # {results:[{pid,name,color,laps,best_lap,total_time,hits,drift_score}]}
S_CHAT         = "chat"          # {pid, name, text}
S_PING         = "ping"

# ── Client → Server ───────────────────────────────────────────────────────────
C_JOIN         = "join"          # {name, color:[r,g,b]}
C_READY        = "ready"
C_VOTE         = "vote"          # {level_key, mode}
C_INPUT        = "input"         # {gas,brake,left,right,hb, seq}
C_CHAT         = "chat"          # {text}
C_PONG         = "pong"


# ── Wire helpers ──────────────────────────────────────────────────────────────

def encode(msg: dict) -> bytes:
    return (json.dumps(msg, separators=(",", ":")) + "\n").encode()

def decode(raw: bytes) -> dict:
    return json.loads(raw.decode().strip())


class MsgBuffer:
    """Non-blocking recv buffer that emits complete newline-delimited messages."""

    def __init__(self, sock: socket.socket):
        self.sock = sock
        self._buf  = b""
        self._lock = threading.Lock()

    def send(self, msg: dict) -> bool:
        with self._lock:
            try:
                self.sock.sendall(encode(msg))
                return True
            except OSError:
                return False

    def recv_all(self):
        """
        Returns list of decoded dicts, or None if the connection was closed.
        Call repeatedly each frame (non-blocking).
        """
        try:
            data = self.sock.recv(65536)
            if not data:
                return None
            self._buf += data
        except BlockingIOError:
            pass
        except OSError:
            return None

        out = []
        while b"\n" in self._buf:
            line, self._buf = self._buf.split(b"\n", 1)
            line = line.strip()
            if line:
                try:
                    out.append(decode(line))
                except Exception:
                    pass
        return out