"""
main.py  –  Da Drifting Game   python main.py
"""
import pygame, sys, json, math, os, random
from carcontroller import CarController
from settings import SaveData, RESOLUTIONS, PARTICLE_QUALITIES, FPS_OPTIONS
import os.path

LEVELS_DIR = "levels"


# ── helpers ───────────────────────────────────────────────────────────────────

def w2s(wx, wy, cam_x, cam_y, zoom, sw, sh):
    return (wx-cam_x)*zoom + sw*0.5, (wy-cam_y)*zoom + sh*0.5

def load_level(path):
    with open(path) as f:
        return json.load(f)

def list_levels():
    out = []
    if not os.path.isdir(LEVELS_DIR):
        return out
    for fn in sorted(os.listdir(LEVELS_DIR)):
        if fn.endswith(".lev"):
            p = os.path.join(LEVELS_DIR, fn)
            try:
                d = load_level(p)
                out.append({"path": p, "key": fn,
                             "name": d.get("name", fn),
                             "laps": d.get("lap_count", 3),
                             "target": d.get("target_score", 0)})
            except Exception:
                pass
    return out


# ── track objects ─────────────────────────────────────────────────────────────

class Wall:
    def __init__(self, d):
        self.rect     = pygame.Rect(int(d["x"]), int(d["y"]),
                                     int(d["w"]), int(d["h"]))
        self.is_outer = d.get("is_outer", True)

    def collide(self, car):
        return car.push_out_of_rect(self.rect, self.is_outer)


class BoostPad:
    def __init__(self, d):
        self.rect = pygame.Rect(int(d["x"]),int(d["y"]),int(d["w"]),int(d["h"]))
        self.cd   = 0.0

    def update(self, car, dt):
        if self.cd > 0:
            self.cd -= dt
            return
        for cx,cy in car.get_corners():
            if self.rect.collidepoint(cx, cy):
                car.boost = max(car.boost, 3.0)
                self.cd   = 4.0
                return

    def draw(self, surf, cam_x, cam_y, zoom):
        sw,sh = surf.get_size()
        sx,sy = w2s(self.rect.x,self.rect.y,cam_x,cam_y,zoom,sw,sh)
        pw = max(1,int(self.rect.w*zoom)); ph = max(1,int(self.rect.h*zoom))
        t  = pygame.time.get_ticks()
        a  = int(135+90*abs(math.sin(t*0.005)))
        s  = pygame.Surface((pw+4,ph+4),pygame.SRCALPHA)
        col = (255,215,0,a) if self.cd<=0 else (95,95,95,75)
        pygame.draw.rect(s,col,(2,2,pw,ph),border_radius=4)
        pygame.draw.rect(s,(255,255,155,195),(2,2,pw,ph),2,border_radius=4)
        if self.cd<=0:
            cx2,cy2=pw//2+2,ph//2+2
            aw,ah=max(4,pw//3),max(3,ph//3)
            pygame.draw.polygon(s,(255,255,75,228),
                [(cx2,cy2-ah),(cx2+aw,cy2+ah),(cx2-aw,cy2+ah)])
        surf.blit(s,(int(sx)-2,int(sy)-2))


# ── TriggerZone ──────────────────────────────────────────────────────────────

# Trigger kind metadata (label + color only — actual values stored per-trigger)
TRIGGER_KINDS  = ["speed","accel","steer","drift"]
TRIGGER_META   = {
    "speed": {"label":"SPEED",  "color":(80,220,255)},
    "accel": {"label":"ACCEL",  "color":(120,255,120)},
    "steer": {"label":"TURN",   "color":(220,160,255)},
    "drift": {"label":"DRIFT",  "color":(255,80,160)},
}
# All trigger values are MULTIPLIERS (1.0 = no change).
# speed: 2.0 = double top speed, 0.5 = half top speed
# accel: 2.0 = double acceleration
# steer: 2.0 = double turn rate
# drift: 0.1 = very slidey, 3.0 = very grippy
TRIGGER_DEFAULTS = {"speed": 1.5, "accel": 1.5, "steer": 1.5, "drift": 0.3}


class TriggerZone:
    """
    Toggle trigger: first car pass ENABLES, second DISABLES (toggles).
    Multiple active triggers STACK (multiply together).
    All trigger values are multipliers stored by the level designer.

    IMPORTANT: apply_to_car() must be called BEFORE CarController.update()
    each frame so the multipliers are live when the physics runs.
    """
    def __init__(self, d):
        self.rect    = pygame.Rect(int(d["x"]),int(d["y"]),int(d["w"]),int(d["h"]))
        self.kind    = d.get("kind","speed")   # "speed","accel","steer","drift"
        # Per-trigger value — always a multiplier.
        # Legacy levels that stored speed as absolute px/s (e.g. 300.0) are
        # clamped to a sane multiplier range so they don't break physics.
        raw_value = float(d.get("value", TRIGGER_DEFAULTS.get(self.kind, 1.0)))
        self.value = self._sanitise_value(self.kind, raw_value)
        self.active  = False   # toggled each pass
        self._was_touching = False   # edge-detect

    @staticmethod
    def _sanitise_value(kind, v):
        """
        Clamp value to a sensible multiplier range.
        Old level files stored speed as absolute px/s (e.g. 300.0); clamp
        those down so they don't multiply SPEED_MAX by 300.
        """
        if kind == "speed":
            # Multiplier range: 0.1 – 10
            # If someone saved an absolute value like 300, treat it as 1.0
            if v > 10.0:
                return 1.0
            return max(0.1, min(10.0, v))
        elif kind == "accel":
            return max(0.1, min(10.0, v))
        elif kind == "steer":
            return max(0.1, min(10.0, v))
        elif kind == "drift":
            return max(0.05, min(10.0, v))
        return v

    def update(self, car):
        touching = self.rect.collidepoint(car.x, car.y)
        if not touching:
            for cx,cy in car.get_corners():
                if self.rect.collidepoint(cx,cy):
                    touching=True; break
        # Edge: entered zone → toggle
        if touching and not self._was_touching:
            self.active = not self.active
        self._was_touching = touching

    def apply_to_car(self, car):
        """
        Stack this trigger's multiplier onto the car's trig_* fields.
        Must be called BEFORE car.update() so the physics sees the values.
        CarController.update() resets them at the end of each frame.
        """
        if not self.active:
            return
        if self.kind == "speed":
            car.trig_speed_mult *= self.value
            car._trig_active = f"SPEED ×{self.value:.1f}"
        elif self.kind == "accel":
            car.trig_accel_mult *= self.value
            car._trig_active = f"ACCEL ×{self.value:.1f}"
        elif self.kind == "steer":
            car.trig_steer_mult *= self.value
            car._trig_active = f"TURN ×{self.value:.1f}"
        elif self.kind == "drift":
            car.trig_grip_mult *= self.value
            car._trig_active = f"DRIFT ×{self.value:.1f}"

    def draw(self, surf, cam_x, cam_y, zoom):
        sw,sh = surf.get_size()
        sx,sy = w2s(self.rect.x, self.rect.y, cam_x, cam_y, zoom, sw, sh)
        pw = max(2, int(self.rect.w*zoom)); ph = max(2, int(self.rect.h*zoom))
        t  = pygame.time.get_ticks()
        meta = TRIGGER_META.get(self.kind, {"label":"?","color":(200,200,200)})
        r,g,b = meta["color"]
        s = pygame.Surface((pw+4,ph+4), pygame.SRCALPHA)
        if self.active:
            a = int(140+80*abs(math.sin(t*0.006)))
            pygame.draw.rect(s,(r,g,b,a),   (2,2,pw,ph), border_radius=5)
            pygame.draw.rect(s,(r,g,b,255), (2,2,pw,ph), 3, border_radius=5)
        else:
            pygame.draw.rect(s,(r,g,b,55),  (2,2,pw,ph), border_radius=5)
            pygame.draw.rect(s,(r,g,b,140), (2,2,pw,ph), 2, border_radius=5)
        surf.blit(s, (int(sx)-2, int(sy)-2))
        if pw > 24 and ph > 14:
            font = pygame.font.SysFont("consolas", max(9, int(11*zoom)), bold=True)
            lbl_str = f"{meta['label']} ×{self.value:.1f}"
            lbl = font.render(lbl_str, True, (255,255,255) if self.active else (180,180,180))
            surf.blit(lbl, (int(sx)+pw//2-lbl.get_width()//2,
                             int(sy)+ph//2-lbl.get_height()//2))
            # ON/OFF badge
            badge_f = pygame.font.SysFont("consolas", max(7,int(9*zoom)), bold=True)
            badge = badge_f.render("ON" if self.active else "OFF", True,
                                    (100,255,100) if self.active else (200,100,100))
            surf.blit(badge, (int(sx)+2, int(sy)+2))


# ── LevelText ─────────────────────────────────────────────────────────────────

class LevelText:
    def __init__(self, d):
        self.x    = float(d["x"])
        self.y    = float(d["y"])
        self.text = d.get("text","Text")
        self.size = int(d.get("size",24))
        self.color= tuple(d.get("color",[255,255,255]))
        self._font_cache = {}

    def _font(self, zoom):
        sz = max(8, int(self.size * zoom))
        if sz not in self._font_cache:
            self._font_cache[sz] = pygame.font.SysFont("consolas", sz, bold=True)
        return self._font_cache[sz]

    def draw(self, surf, cam_x, cam_y, zoom):
        sw,sh = surf.get_size()
        sx,sy = w2s(self.x, self.y, cam_x, cam_y, zoom, sw, sh)
        font  = self._font(zoom)
        # Shadow
        shadow = font.render(self.text, True, (0,0,0))
        surf.blit(shadow, (int(sx)-shadow.get_width()//2+2, int(sy)+2))
        img = font.render(self.text, True, self.color)
        surf.blit(img, (int(sx)-img.get_width()//2, int(sy)))


class Checkpoint:
    DEFAULT_W = 120
    DEFAULT_H = 120

    def __init__(self, data, idx):
        # data can be [x,y] (legacy) or [x,y,w,h]
        if len(data) == 2:
            cx, cy = data
            self.x = float(cx - self.DEFAULT_W // 2)
            self.y = float(cy - self.DEFAULT_H // 2)
            self.w = float(self.DEFAULT_W)
            self.h = float(self.DEFAULT_H)
        else:
            self.x, self.y, self.w, self.h = (float(v) for v in data[:4])
        self.idx = idx

    @property
    def cx(self): return self.x + self.w * 0.5
    @property
    def cy(self): return self.y + self.h * 0.5

    def hit(self, car):
        # Any car corner inside the checkpoint rect triggers it
        r = pygame.Rect(int(self.x), int(self.y), int(self.w), int(self.h))
        for cx, cy in car.get_corners():
            if r.collidepoint(cx, cy):
                return True
        # Also check car centre for small CPs
        return r.collidepoint(car.x, car.y)

    def draw(self, surf, cam_x, cam_y, zoom, active):
        sw, sh = surf.get_size()
        sx, sy = w2s(self.x, self.y, cam_x, cam_y, zoom, sw, sh)
        pw = max(4, int(self.w * zoom))
        ph = max(4, int(self.h * zoom))
        t  = pygame.time.get_ticks()
        s  = pygame.Surface((pw + 8, ph + 8), pygame.SRCALPHA)
        if active:
            pulse = int(60 + 90 * abs(math.sin(t * 0.007)))
            pygame.draw.rect(s, (88, 255, 88, pulse), (4, 4, pw, ph), border_radius=4)
            pygame.draw.rect(s, (58, 218, 58, 255),   (4, 4, pw, ph), 3, border_radius=4)
            # Animated inner fill
            inner = int(3 + 2 * abs(math.sin(t * 0.007)))
            pygame.draw.rect(s, (88, 255, 88, pulse // 2),
                             (4 + inner, 4 + inner, pw - inner*2, ph - inner*2),
                             border_radius=3)
        else:
            pygame.draw.rect(s, (175, 175, 175, 30), (4, 4, pw, ph), border_radius=4)
            pygame.draw.rect(s, (148, 148, 148, 80),  (4, 4, pw, ph), 2, border_radius=4)
        surf.blit(s, (int(sx) - 4, int(sy) - 4))


class Popup:
    def __init__(self, text, x, y, color=(255,215,48)):
        self.text,self.x,self.y=text,float(x),float(y)
        self.color=color; self.life=self.max_life=1.8

    def update(self,dt):
        self.y-=24*dt; self.life-=dt
        return self.life>0

    def draw(self,surf,cam_x,cam_y,zoom,font):
        sw,sh=surf.get_size()
        sx,sy=w2s(self.x,self.y,cam_x,cam_y,zoom,sw,sh)
        a=int(255*min(1.0,self.life/self.max_life))
        img=font.render(self.text,True,self.color)
        img.set_alpha(a)
        surf.blit(img,(int(sx)-img.get_width()//2,int(sy)))


# ── background ────────────────────────────────────────────────────────────────

def build_bg(ld):
    """
    Build a world-space background surface that covers all level content
    plus a large grass border so there is never a bare bg_color gap.

    The surface origin is stored as (bg_ox, bg_oy) inside the returned
    surface's own attribute so _draw() knows where to position it.
    We achieve this by returning a (surface, origin_x, origin_y) tuple.
    """
    gc = tuple(ld.get("grass_color", [38, 88, 48]))
    tc = tuple(ld.get("track_color", [72, 76, 82]))
    cc = tuple(ld.get("curb_color",  [210, 50, 50]))

    walls = ld.get("walls", [])
    decs  = ld.get("decorations", [])

    # ── Work out the bounding box of all level content ────────────────────
    PADDING = 1200   # grass border beyond the outermost wall
    if walls:
        xs = [w["x"] for w in walls] + [w["x"] + w["w"] for w in walls]
        ys = [w["y"] for w in walls] + [w["y"] + w["h"] for w in walls]
    else:
        # No walls — centre on start position
        sx0 = ld.get("start_x", 500)
        sy0 = ld.get("start_y", 500)
        xs  = [sx0]
        ys  = [sy0]

    # Also include decorations in the bounds
    for d in decs:
        r = d.get("r", 30)
        xs += [d["x"] - r, d["x"] + r]
        ys += [d["y"] - r, d["y"] + r]

    ox = int(min(xs)) - PADDING
    oy = int(min(ys)) - PADDING
    W  = int(max(xs)) - int(min(xs)) + PADDING * 2
    H  = int(max(ys)) - int(min(ys)) + PADDING * 2

    bg = pygame.Surface((W, H))
    bg.fill(gc)   # the whole surface is grass — track is painted on top

    def r(obj):
        """Translate a level-space rect to surface-local coords."""
        return (int(obj["x"]) - ox, int(obj["y"]) - oy,
                int(obj["w"]), int(obj["h"]))

    # Outer wall bodies (track surface)
    for w in walls:
        if w.get("is_outer", True):
            pygame.draw.rect(bg, tc, r(w))

    # Inner wall bodies cut back out to grass
    for w in walls:
        if not w.get("is_outer", True):
            pygame.draw.rect(bg, gc, r(w))

    # Decorations
    for d in decs:
        col = tuple(d.get("color", [40, 80, 50]))
        lx  = int(d["x"]) - ox
        ly  = int(d["y"]) - oy
        if d["type"] == "rect":
            pygame.draw.rect(bg, col, (lx, ly, int(d["w"]), int(d["h"])))
        elif d["type"] == "circle":
            pygame.draw.circle(bg, col, (lx, ly), int(d.get("r", 30)))

    # Curb borders on all walls (drawn last so they sit on top)
    for w in walls:
        pygame.draw.rect(bg, cc, r(w), 6)

    return bg, ox, oy


# ── GameSession ───────────────────────────────────────────────────────────────

class GameSession:
    def __init__(self, screen, level_path, level_key, car_color, sd: SaveData):
        self.screen    = screen
        self.clock     = pygame.time.Clock()
        self.sd        = sd
        self.level_key = level_key
        self.sw,self.sh= screen.get_size()
        self.level     = load_level(level_path)

        self.fB=pygame.font.SysFont("consolas",44,bold=True)
        self.fM=pygame.font.SysFont("consolas",26,bold=True)
        self.fS=pygame.font.SysFont("consolas",16,bold=True)
        self.ft=pygame.font.SysFont("consolas",13)

        sx0=self.level["start_x"]; sy0=self.level["start_y"]
        sa =self.level.get("start_angle",0)
        self.car=CarController(sx0,sy0,sa,car_color)
        self.car.particle_quality=sd.settings["particle_quality"]
        self.car.skidmarks_on    =sd.settings["skidmarks"]

        self.walls      =[Wall(w)     for w in self.level.get("walls",[])]
        self.boost_pads =[BoostPad(b) for b in self.level.get("boost_pads",[])]
        self.checkpoints=[Checkpoint(c,i)
                          for i,c in enumerate(self.level.get("checkpoints",[]))]
        self.triggers   =[TriggerZone(t) for t in self.level.get("triggers",[])]
        self.level_texts=[LevelText(t)   for t in self.level.get("texts",[])]

        self.max_laps  =self.level.get("lap_count",3)
        self.lap       =0; self.next_cp=0
        self.lap_times =[]; self.best_lap=None
        self.race_start=pygame.time.get_ticks()
        self.lap_start =self.race_start
        self.finished  =False; self.fin_t=0.0
        self.paused    =False

        self.cam_x=float(sx0); self.cam_y=float(sy0)
        self.zoom=1.0; self.tz=1.0
        self.popups=[]; self.shake=0.0

        self.bg_surf, self.bg_ox, self.bg_oy = build_bg(self.level)
        self.fps_fnt=pygame.font.SysFont("consolas",14)

    # ── loop ──────────────────────────────────────────────────────────────────

    def run(self):
        fps=self.sd.settings["fps_limit"] or 0
        while True:
            dt=self.clock.tick(fps)/1000.0 if fps else self.clock.tick()/1000.0
            dt=min(dt,0.05)
            res=self._events()
            if res: return res

            if not self.paused and not self.finished:
                keys=pygame.key.get_pressed()

                # ── Apply triggers BEFORE car.update() ────────────────────────
                # TriggerZone.update() detects enter/exit and toggles active.
                # TriggerZone.apply_to_car() writes trig_*_mult onto the car.
                # CarController.update() reads those mults during physics, then
                # resets them at the end of the frame ready for the next pass.
                for tz in self.triggers:
                    tz.update(self.car)
                    tz.apply_to_car(self.car)

                # ── Now run car physics (reads the mults we just set) ──────────
                self.car.update(keys, dt)

                # Collision with all walls
                for w in self.walls:
                    if w.collide(self.car):
                        if self.sd.settings["camera_shake"]:
                            self.shake=max(self.shake,6.0)

                self._checkpoints()
                self._camera(dt)
                for bp in self.boost_pads:
                    bp.update(self.car,dt)
                self.popups=[p for p in self.popups if p.update(dt)]
                if self.shake>0:
                    self.shake=max(0.0,self.shake-dt*55)

            if self.finished:
                self.fin_t+=dt
                if self.fin_t>5.0:
                    return "menu"

            self._draw()
            pygame.display.flip()

    # ── private ───────────────────────────────────────────────────────────────

    def _events(self):
        for ev in pygame.event.get():
            if ev.type==pygame.QUIT: pygame.quit();sys.exit()
            if ev.type==pygame.KEYDOWN:
                if ev.key==pygame.K_ESCAPE: return "menu"
                if ev.key==pygame.K_p:      self.paused=not self.paused
                if ev.key==pygame.K_r:      self._reset()
        return None

    def _reset(self):
        sx0=self.level["start_x"]; sy0=self.level["start_y"]
        self.car.reset(sx0,sy0,self.level.get("start_angle",0))
        self.next_cp=0;self.lap=0;self.lap_times=[];self.best_lap=None
        self.race_start=self.lap_start=pygame.time.get_ticks()
        self.finished=False;self.fin_t=0.0

    def _checkpoints(self):
        if self.next_cp>=len(self.checkpoints): return
        if self.checkpoints[self.next_cp].hit(self.car):
            self.next_cp+=1
            if self.next_cp>=len(self.checkpoints):
                self.lap+=1
                now=pygame.time.get_ticks()
                lt=(now-self.lap_start)/1000.0
                self.lap_times.append(lt)
                if self.best_lap is None or lt<self.best_lap:
                    self.best_lap=lt
                self.lap_start=now; self.next_cp=0
                col=(88,255,88) if self.lap<self.max_laps else (255,215,48)
                self.popups.append(Popup(f"LAP {self.lap}  {lt:.2f}s",
                                          self.car.x,self.car.y-60,col))
                if self.lap>=self.max_laps:
                    self.finished=True
                    # Save stats
                    self.sd.record_race(self.level_key,
                                        self.lap_times,
                                        self.car.drift_score)
            else:
                self.popups.append(Popup("CP ✓",self.car.x,self.car.y-50,(175,255,175)))

    def _camera(self,dt):
        tx=self.car.x+self.car.vx*0.15
        ty=self.car.y+self.car.vy*0.15
        self.cam_x+=(tx-self.cam_x)*min(1.0,dt*9)
        self.cam_y+=(ty-self.cam_y)*min(1.0,dt*9)
        self.tz=max(0.58,1.05-(self.car.speed/self.car.SPEED_MAX)*0.42)
        self.zoom+=(self.tz-self.zoom)*min(1.0,dt*3)

    def _draw(self):
        sw,sh=self.sw,self.sh
        shx=random.uniform(-self.shake,self.shake) if self.shake else 0
        shy=random.uniform(-self.shake,self.shake) if self.shake else 0
        cx=self.cam_x+shx/self.zoom; cy=self.cam_y+shy/self.zoom

        # Fill with grass colour — covers any screen area outside the bg surface.
        self.screen.fill(tuple(self.level.get("grass_color", [38, 88, 48])))
        bw = int(self.bg_surf.get_width()  * self.zoom)
        bh = int(self.bg_surf.get_height() * self.zoom)
        if bw > 0 and bh > 0:
            sc  = pygame.transform.scale(self.bg_surf, (bw, bh))
            # bg_ox/oy is the world-space top-left of the surface;
            # convert to screen space exactly like any other world object.
            bsx = int((self.bg_ox - cx) * self.zoom + sw * 0.5)
            bsy = int((self.bg_oy - cy) * self.zoom + sh * 0.5)
            self.screen.blit(sc, (bsx, bsy))

        for bp in self.boost_pads: bp.draw(self.screen,cx,cy,self.zoom)
        for tz in self.triggers:      tz.draw(self.screen,cx,cy,self.zoom)
        for lt in self.level_texts:   lt.draw(self.screen,cx,cy,self.zoom)
        for i,cp in enumerate(self.checkpoints):
            cp.draw(self.screen,cx,cy,self.zoom,i==self.next_cp)
        self.car.draw(self.screen,cx,cy,self.zoom)
        for p in self.popups: p.draw(self.screen,cx,cy,self.zoom,self.fM)

        self._hud()

        if self.paused:
            ov=pygame.Surface((sw,sh),pygame.SRCALPHA);ov.fill((0,0,0,148))
            self.screen.blit(ov,(0,0))
            pt=self.fB.render("PAUSED",True,(255,255,255))
            self.screen.blit(pt,(sw//2-pt.get_width()//2,sh//2-50))
            ht=self.fS.render("P = resume    R = reset    ESC = menu",True,(198,198,198))
            self.screen.blit(ht,(sw//2-ht.get_width()//2,sh//2+22))

        if self.finished and self.fin_t<5.0:
            a=min(188,int(self.fin_t*75))
            ov=pygame.Surface((sw,sh),pygame.SRCALPHA);ov.fill((0,0,0,a))
            self.screen.blit(ov,(0,0))
            if self.fin_t>0.5:
                t1=self.fB.render("RACE COMPLETE!",True,(88,255,88))
                self.screen.blit(t1,(sw//2-t1.get_width()//2,sh//2-90))
                total=sum(self.lap_times)
                t2=self.fM.render(f"Total  {total:.2f}s      Best Lap  {self.best_lap:.2f}s",
                                   True,(255,238,178))
                self.screen.blit(t2,(sw//2-t2.get_width()//2,sh//2))
                t3=self.fM.render(f"Drift Score  {self.car.drift_score:,}",True,(255,215,48))
                self.screen.blit(t3,(sw//2-t3.get_width()//2,sh//2+48))
                # Show PBs
                st=self.sd.get_level_stats(self.level_key)
                t4=self.fS.render(
                    f"PB Lap {st['best_lap']:.2f}s   PB Total {st['best_total']:.2f}s   "
                    f"Best Score {st['best_score']:,}   Races {st['races']}",
                    True,(145,175,145))
                self.screen.blit(t4,(sw//2-t4.get_width()//2,sh//2+95))

    def _hud(self):
        sw,sh=self.sw,self.sh
        now=pygame.time.get_ticks()

        panel=pygame.Surface((282,175),pygame.SRCALPHA)
        panel.fill((0,0,0,158));pygame.draw.rect(panel,(70,76,93,198),(0,0,282,175),2,border_radius=8)
        self.screen.blit(panel,(10,10))

        self.screen.blit(self.ft.render(self.level.get("name",""),True,(148,156,178)),(18,15))
        self.screen.blit(self.fM.render(f"Lap  {min(self.lap+1,self.max_laps)} / {self.max_laps}",True,(238,238,238)),(18,32))
        self.screen.blit(self.ft.render(f"Checkpoint  {self.next_cp} / {len(self.checkpoints)}",True,(148,190,148)),(18,62))
        elapsed=(now-self.race_start)/1000.0
        self.screen.blit(self.fM.render(f"Time  {elapsed:.2f}s",True,(218,218,118)),(18,80))
        if self.best_lap:
            self.screen.blit(self.ft.render(f"Best Lap  {self.best_lap:.2f}s",True,(85,215,85)),(18,112))

        # PB from save
        st=self.sd.get_level_stats(self.level_key)
        if st["best_lap"]:
            self.screen.blit(self.ft.render(f"PB  {st['best_lap']:.2f}s",True,(95,175,215)),(18,128))

        km_h=self.car.speed*(300/self.car.SPEED_MAX)
        eff_max=self.car.SPEED_MAX*self.car.trig_speed_mult
        max_km_h=eff_max*(300/self.car.SPEED_MAX)
        bw=int(min(km_h,max_km_h)/max(max_km_h,1)*248)
        pygame.draw.rect(self.screen,(30,30,40),(18,137,248,11),border_radius=5)
        bc=(255,92,32) if km_h>max_km_h*0.85 else (46,186,255)
        if bw>0: pygame.draw.rect(self.screen,bc,(18,137,min(248,bw),11),border_radius=5)
        self.screen.blit(self.ft.render(f"{km_h:.0f} km/h",True,(185,185,185)),(18,152))

        # ── Top-right speed indicator ─────────────────────────────────────────
        spd_panel=pygame.Surface((175,52),pygame.SRCALPHA)
        spd_panel.fill((0,0,0,148))
        pygame.draw.rect(spd_panel,(60,68,88,200),(0,0,175,52),2,border_radius=8)
        self.screen.blit(spd_panel,(sw-185,10))
        # Max speed label
        self.screen.blit(self.ft.render("MAX SPEED",True,(128,138,165)),(sw-178,13))
        max_spd_txt=self.fS.render(f"{max_km_h:.0f} km/h",True,(255,215,48))
        self.screen.blit(max_spd_txt,(sw-178,26))
        # Active trigger badge
        if self.car._trig_active:
            trig_col=(200,200,200)
            for kind,meta in TRIGGER_META.items():
                if meta["label"] in self.car._trig_active:
                    trig_col=meta["color"]; break
            badge_txt=self.ft.render(self.car._trig_active,True,trig_col)
            bx=sw-178+max_spd_txt.get_width()+8
            pygame.draw.rect(self.screen,(*trig_col,60),(bx-2,27,badge_txt.get_width()+8,17),border_radius=4)
            self.screen.blit(badge_txt,(bx+2,28))

        self.car.draw_score_hud(self.screen,self.fB,self.fM,self.fS,sw,sh)
        self._minimap()

        hint="WASD = Drive   SPACE = Handbrake   P = Pause   R = Reset   ESC = Menu"
        ht=self.ft.render(hint,True,(80,84,98))
        self.screen.blit(ht,(sw//2-ht.get_width()//2,sh-16))

        if self.sd.settings.get("show_fps"):
            fps=self.ft.render(f"FPS {self.clock.get_fps():.0f}",True,(175,175,55))
            self.screen.blit(fps,(sw-248,sh-18))

    def _minimap(self):
        sw,sh=self.sw,self.sh
        mm=148;mx2,my2=sw-mm-10,sh-mm-10
        s=pygame.Surface((mm,mm),pygame.SRCALPHA)
        s.fill((0,0,0,162));pygame.draw.rect(s,(70,76,93,198),(0,0,mm,mm),2,border_radius=6)
        walls=self.level.get("walls",[])
        if not walls: self.screen.blit(s,(mx2,my2));return
        ax=[w["x"] for w in walls]+[w["x"]+w["w"] for w in walls]
        ay=[w["y"] for w in walls]+[w["y"]+w["h"] for w in walls]
        wx0,wx1=min(ax),max(ax);wy0,wy1=min(ay),max(ay)
        span=max(wx1-wx0,wy1-wy0,1);sc=(mm-12)/span
        def wts(x,y): return int((x-wx0)*sc+6),int((y-wy0)*sc+6)
        for w in walls:
            x1,y1=wts(w["x"],w["y"]);x2,y2=wts(w["x"]+w["w"],w["y"]+w["h"])
            col=(90,90,103) if w.get("is_outer",True) else (42,78,42)
            pygame.draw.rect(s,col,(x1,y1,max(1,x2-x1),max(1,y2-y1)))
        for cp in self.checkpoints:
            cx2,cy2=wts(cp.cx,cp.cy);pygame.draw.circle(s,(60,140,60),(cx2,cy2),3)
        cx2,cy2=wts(self.car.x,self.car.y);pygame.draw.circle(s,(232,50,50),(cx2,cy2),4)
        self.screen.blit(s,(mx2,my2))


# ── Settings screen ───────────────────────────────────────────────────────────

class SettingsScreen:
    def __init__(self, screen, sd: SaveData, make_screen_fn):
        self.screen=screen; self.sd=sd
        self.make_screen=make_screen_fn
        self.sw,self.sh=screen.get_size()
        self.work=dict(sd.settings)   # editable copy
        self.clock=pygame.time.Clock()
        self.fT=pygame.font.SysFont("consolas",30,bold=True)
        self.fB=pygame.font.SysFont("consolas",20,bold=True)
        self.fS=pygame.font.SysFont("consolas",15,bold=True)
        self.ft=pygame.font.SysFont("consolas",13)
        self._build()

    def _build(self):
        cx=self.sw//2
        # Fit rows within available height so nothing clips
        n_rows=8; header=90; footer=72
        avail=self.sh-header-footer
        lh=max(34, min(52, avail//n_rows))
        y=header; self.lh=lh; self.y0=y
        self.rows=[
            ("Fullscreen",       "fullscreen",       "bool", None),
            ("Resolution",       "resolution",       "list", [(w,h,l) for w,h,l in RESOLUTIONS]),
            ("FPS Limit",        "fps_limit",        "list", [(v, str(v) if v else "Unlimited") for v in FPS_OPTIONS]),
            ("Particle Quality", "particle_quality", "list", [(v,v) for v in PARTICLE_QUALITIES]),
            ("Skid Marks",       "skidmarks",        "bool", None),
            ("Camera Shake",     "camera_shake",     "bool", None),
            ("VSync",            "vsync",            "bool", None),
            ("Show FPS Counter", "show_fps",         "bool", None),
        ]
        bh=min(34, lh-6)
        self.rects=[]
        for i,(label,key,typ,opts) in enumerate(self.rows):
            ry=y+i*lh
            mid=(lh-bh)//2
            if typ=="bool":
                th=min(30,bh); tm=(lh-th)//2
                self.rects.append((None,None,pygame.Rect(cx+65,ry+tm,80,th)))
            else:
                self.rects.append((pygame.Rect(cx+60,ry+mid,32,bh),
                                    pygame.Rect(cx+312,ry+mid,32,bh),
                                    None))
        bot=y+n_rows*lh+10
        self.apply_r =pygame.Rect(cx-185,bot,175,42)
        self.cancel_r=pygame.Rect(cx+10, bot,175,42)

    def _disp(self,key,opts):
        v=self.work[key]
        if key=="resolution":
            w,h=v
            for rw,rh,lbl in opts:
                if rw==w and rh==h: return lbl
            return f"{w}×{h}"
        if key=="fps_limit": return str(v) if v else "Unlimited"
        for ov,ol in opts:
            if ov==v: return ol
        return str(v)

    def _cycle(self,key,opts,d):
        v=self.work[key]
        if key=="resolution":
            vals=[(w,h) for w,h,_ in opts]; v=tuple(v)
        else:
            vals=[o[0] for o in opts]
        try: idx=vals.index(v)
        except ValueError: idx=0
        self.work[key]=list(vals[(idx+d)%len(vals)]) if key=="resolution" \
                        else vals[(idx+d)%len(vals)]

    def run(self):
        while True:
            dt=self.clock.tick(60)/1000.0
            evs=pygame.event.get(); mouse=pygame.mouse.get_pos()
            click=any(e.type==pygame.MOUSEBUTTONDOWN and e.button==1 for e in evs)
            for ev in evs:
                if ev.type==pygame.QUIT: pygame.quit();sys.exit()
                if ev.type==pygame.KEYDOWN and ev.key==pygame.K_ESCAPE:
                    return self.screen, None
            if click:
                if self.apply_r.collidepoint(mouse):
                    self.sd.settings.update(self.work)
                    self.sd.save()
                    new_screen=self.make_screen(self.sd)
                    return new_screen, self.sd
                if self.cancel_r.collidepoint(mouse):
                    return self.screen, None
                for i,(_,key,typ,opts) in enumerate(self.rows):
                    la,ra,tog=self.rects[i]
                    if typ=="bool" and tog and tog.collidepoint(mouse):
                        self.work[key]=not self.work[key]
                    elif typ!="bool":
                        if la and la.collidepoint(mouse): self._cycle(key,opts,-1)
                        if ra and ra.collidepoint(mouse): self._cycle(key,opts,+1)
            self._draw(mouse)
            pygame.display.flip()

    def _draw(self,mouse):
        sw,sh=self.sw,self.sh; cx=sw//2
        self.screen.fill((13,16,26))
        t=self.fT.render("SETTINGS",True,(205,192,92))
        self.screen.blit(t,(cx-t.get_width()//2,14))
        sep_y=self.y0-8
        pygame.draw.line(self.screen,(78,83,102),(cx-285,sep_y),(cx+285,sep_y),2)

        y0=self.y0; lh=self.lh
        for i,(label,key,typ,opts) in enumerate(self.rows):
            ry=y0+i*lh; la,ra,tog=self.rects[i]
            rr=pygame.Rect(cx-285,ry+2,570,lh-3)
            hv=rr.collidepoint(mouse)
            pygame.draw.rect(self.screen,(23,28,42) if not hv else (30,37,55),rr,border_radius=7)
            pygame.draw.rect(self.screen,(44,50,68),rr,1,border_radius=7)
            self.screen.blit(self.fS.render(label,True,(208,208,208)),(cx-275,ry+14))

            if typ=="bool":
                v=self.work[key]
                col=(50,158,50) if v else (118,38,38)
                hcol=(70,205,70) if v else (168,56,56)
                th=tog.collidepoint(mouse)
                pygame.draw.rect(self.screen,hcol if th else col,tog,border_radius=8)
                pygame.draw.rect(self.screen,(175,198,175) if v else (178,118,118),tog,2,border_radius=8)
                vt=self.fS.render("ON" if v else "OFF",True,(238,238,238))
                self.screen.blit(vt,vt.get_rect(center=tog.center))
            else:
                for arr,d in [(la,-1),(ra,+1)]:
                    ah=arr.collidepoint(mouse)
                    pygame.draw.rect(self.screen,(52,62,88) if not ah else (78,92,138),arr,border_radius=6)
                    pygame.draw.rect(self.screen,(88,98,132),arr,1,border_radius=6)
                    at=self.fB.render("◄" if d==-1 else "►",True,(218,218,218))
                    self.screen.blit(at,at.get_rect(center=arr.center))
                vr=pygame.Rect(la.right+3,ry+7,ra.left-la.right-6,34)
                pygame.draw.rect(self.screen,(18,22,34),vr,border_radius=5)
                pygame.draw.rect(self.screen,(58,66,92),vr,1,border_radius=5)
                vt=self.fS.render(self._disp(key,opts),True,(238,232,178))
                self.screen.blit(vt,vt.get_rect(center=vr.center))

        for btn,txt,col,hcol,bc in [
            (self.apply_r, "APPLY",  (48,108,48),(70,162,70),(152,212,152)),
            (self.cancel_r,"CANCEL", (92,38,38), (145,58,58),(212,118,118)),
        ]:
            bh=btn.collidepoint(mouse)
            pygame.draw.rect(self.screen,hcol if bh else col,btn,border_radius=9)
            pygame.draw.rect(self.screen,bc,btn,2,border_radius=9)
            bt=self.fB.render(txt,True,(238,238,238))
            self.screen.blit(bt,bt.get_rect(center=btn.center))

        note=self.ft.render(
            "Resolution, Fullscreen, and VSync apply when you click APPLY.",
            True,(102,106,125))
        self.screen.blit(note,(cx-note.get_width()//2,sh-26))


# ── entry point ───────────────────────────────────────────────────────────────

def make_screen(sd: SaveData):
    flags=pygame.FULLSCREEN if sd.settings["fullscreen"] else 0
    vsync=1 if sd.settings["vsync"] else 0
    w,h=sd.settings["resolution"]
    screen=pygame.display.set_mode((w,h),flags,vsync=vsync)
    pygame.display.set_caption("Da Drifting Game")
    return screen


def main():
    pygame.init()
    sd=SaveData()
    screen=make_screen(sd)

    from mainmenu import MainMenu
    while True:
        result=MainMenu(screen,sd).run()
        if result is None: break
        action=result[0]

        if action=="settings":
            screen2,new_sd=SettingsScreen(screen,sd,make_screen).run()
            screen=screen2
            if new_sd: sd=new_sd
            continue

        if action=="race":
            _,level_path,level_key,car_color=result
            GameSession(screen,level_path,level_key,car_color,sd).run()

        elif action=="creator":
            from level_creator import LevelCreator
            LevelCreator(screen).run()

        elif action=="multiplayer":
            from multiplayer_client import run_multiplayer
            run_multiplayer(screen, sd)


if __name__=="__main__":
    main()